package net.homeplus.offline.sr.proc.dao;

import net.homeplus.offline.common.dao.CommonDAO;
import net.homeplus.offline.sr.view.vo.SRViewVO;

import org.springframework.stereotype.Repository;

@Repository("ProcDAO")
public class ProcDAO extends CommonDAO {

    public void insertSRDetail(SRViewVO vo) {
        getSqlSession().insert("SRProc.insertSRDetail", vo);

    }

    public long selectSRSeq() {

        return getSqlSession().selectOne("SRProc.selectSRSeq");
    }


    public int updateSRStatus(SRViewVO vo) {
        return getSqlSession().update("SRProc.updateSRStatus", vo);
    }


}
