package net.homeplus.offline.sr.proc.service;

import net.homeplus.offline.sr.approval.vo.ApprovalHistVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;

public interface ProcService {

    public String selectSRId();

    public SRViewVO insertSR(SRViewVO vo);

    public SRViewVO cancelSR(SRViewVO vo);

    public SRViewVO updateSR(SRViewVO vo);

    public ApprovalHistVO approveSR(ApprovalHistVO vo);

    public ApprovalHistVO disapproveSR(ApprovalHistVO vo);
    // public SRListVO removeSRDetail(SRIDetailVO vo);
}
