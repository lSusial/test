package net.homeplus.offline.sr.approval.service;

import java.util.List;

import net.homeplus.offline.sr.approval.vo.ApprovalHistVO;
import net.homeplus.offline.sr.approval.vo.ApprovalRuleVO;
import net.homeplus.offline.sr.proc.vo.SRDetailVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;

public interface ApprovalService {

    public SRViewVO approveSR(SRDetailVO vo);

    public SRViewVO rejectSR(SRDetailVO vo);

    public List<ApprovalRuleVO> selectSRApprovalRule(ApprovalRuleVO vo);

    public List<ApprovalHistVO> selectSRApprovalHistListBySRId(String srId);

    public ApprovalHistVO approveSR(ApprovalHistVO vo);

    public ApprovalHistVO disapproveSR(ApprovalHistVO vo);



}
