package net.homeplus.offline.sr.approval.service.impl;

import java.util.List;

import net.homeplus.offline.sr.approval.dao.ApprovalDAO;
import net.homeplus.offline.sr.approval.service.ApprovalService;
import net.homeplus.offline.sr.approval.vo.ApprovalHistVO;
import net.homeplus.offline.sr.approval.vo.ApprovalRuleVO;
import net.homeplus.offline.sr.proc.vo.SRDetailVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("ApprovalService")
public class ApprovalServiceImpl implements ApprovalService {

    @Autowired
    private ApprovalDAO approvalDAO;


    @Override
    public SRViewVO approveSR(SRDetailVO vo) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public SRViewVO rejectSR(SRDetailVO vo) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<ApprovalHistVO> selectSRApprovalHistListBySRId(String srId) {
        return approvalDAO.selectSRApprovalHistListBySRId(srId);
    }

    @Override
    public List<ApprovalRuleVO> selectSRApprovalRule(ApprovalRuleVO vo) {
        return approvalDAO.selectSRApprovalRule(vo);
    }

    @Override
    public ApprovalHistVO approveSR(ApprovalHistVO vo) {
        updateApprovalHist(vo);
        return null;
    }



    @Override
    public ApprovalHistVO disapproveSR(ApprovalHistVO vo) {
        updateApprovalHist(vo);
        return null;
    }

    private void updateApprovalHist(ApprovalHistVO vo) {
        approvalDAO.updateApprovalHistStatus(vo);
    }


}
