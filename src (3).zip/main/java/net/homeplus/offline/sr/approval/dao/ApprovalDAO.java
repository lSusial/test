package net.homeplus.offline.sr.approval.dao;

import java.util.List;

import net.homeplus.offline.common.dao.CommonDAO;
import net.homeplus.offline.sr.approval.vo.ApprovalHistVO;
import net.homeplus.offline.sr.approval.vo.ApprovalRuleVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;

import org.springframework.stereotype.Repository;

@Repository("ApprovalDAO")
public class ApprovalDAO extends CommonDAO {

    public List<SRViewVO> test() {

        return null;
        /*return getSqlSession().selectList("CommonCode.selectCommonCodecListByGrpId");*/

    }

    public List<ApprovalRuleVO> selectSRApprovalRule(ApprovalRuleVO vo) {
        return getSqlSession().selectList("Approval.selectSRApprovalRule", vo);
    }

    public void insertAprovalHist(ApprovalHistVO vo) {

        getSqlSession().insert("Approval.insertAprovalHist", vo);
    }

    public ApprovalHistVO selectNextApprovalInfo(String srId) {
        return getSqlSession().selectOne("Approval.selectNextApprovalInfo", srId);
    }

    public int updateApprovalHistStatus(ApprovalHistVO vo) {
        return getSqlSession().update("Approval.updateApprovalHistStatus", vo);
    }

    public List<ApprovalHistVO> selectSRApprovalHistListBySRId(String srId) {
        return getSqlSession().selectList("Approval.selectSRApprovalHistListBySRId", srId);
    }

    public int updateApprovalHist(ApprovalHistVO vo) {
        return getSqlSession().update("Approval.updateApprovalHist", vo);
    }



}
