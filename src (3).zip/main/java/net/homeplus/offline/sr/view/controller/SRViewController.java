package net.homeplus.offline.sr.view.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import net.homeplus.offline.common.code.service.CommonCodeService;
import net.homeplus.offline.common.code.vo.CodeVO;
import net.homeplus.offline.common.constant.Constants;
import net.homeplus.offline.common.vo.UserVO;
import net.homeplus.offline.sr.approval.service.ApprovalService;
import net.homeplus.offline.sr.approval.vo.ApprovalHistVO;
import net.homeplus.offline.sr.approval.vo.ApprovalRuleVO;
import net.homeplus.offline.sr.proc.service.ProcService;
import net.homeplus.offline.sr.view.service.ViewService;
import net.homeplus.offline.sr.view.vo.SRViewVO;
import net.homeplus.offline.sr.view.vo.SystemVO;
import net.homeplus.offline.sr.view.vo.TypeVO;

@Controller
public class SRViewController {

    @Autowired
    private ViewService viewService;
    @Autowired
    private ApprovalService approvalService;
    @Autowired
    private CommonCodeService commonCodeService;
    @Autowired
    private ProcService procService;


    // @Autowired
    // private EmailSender emailSender;



    @RequestMapping("/sr/list.do")
    public ModelAndView getSRList(SRViewVO conditionVO, ModelAndView mav) {


        List<TypeVO> typeList = viewService.selectTypeList(Constants.SRType.SOFTWARE);
        List<CodeVO> statusList = commonCodeService.selectCommonCodeListByGroupId(Constants.Code.SR_STATUS);

        SRViewVO testVO = new SRViewVO();
        testVO.setEtc1("TEST");
        List<SRViewVO> srList = viewService.selectSRList(testVO);


        mav.addObject("srList", srList);
        mav.addObject("typeList", typeList);
        mav.addObject("statusList", statusList);

        mav.setViewName("sr/list");
        return mav;

    }

    @RequestMapping("/sr/detail.do")
    public ModelAndView selectSRDetail(@RequestParam String srNo, ModelAndView mav) {

        SRViewVO detail = viewService.selectSRDetail(srNo);
        System.out.println(detail);


        List<ApprovalHistVO> approvalList = approvalService.selectSRApprovalHistListBySRId(detail.getSrId());

        mav.addObject("detail", detail);
        mav.addObject("approvalList", approvalList);

        // 첨부 파일

        mav.setViewName("sr/detail");

        return mav;

        // 파일 서비스 파일 권한 관련은 어떻게 하나

    }

    @RequestMapping(value = "/sr/regist.do", method = RequestMethod.GET)
    public ModelAndView registView(ModelAndView mav) {

        // SR 구분

        List<TypeVO> typeList = viewService.selectTypeList(Constants.SRType.SOFTWARE);
        List<SystemVO> systemList = viewService.selectSystemList(Constants.SRType.SOFTWARE);

        mav.addObject("typeList", typeList);
        mav.addObject("systemList", systemList);

        mav.setViewName("sr/regist");

        return mav;
    }

    @RequestMapping(value = "/sr/registHW.do", method = RequestMethod.GET)
    public ModelAndView registViewHW(ModelAndView mav) {

        // SR 구분

        List<TypeVO> typeList = viewService.selectTypeList(Constants.SRType.HARDWARE);
        List<SystemVO> systemList = viewService.selectSystemList(Constants.SRType.HARDWARE);

        mav.addObject("typeList", typeList);
        mav.addObject("systemList", systemList);

        mav.setViewName("sr/registHW");

        return mav;
    }

    @RequestMapping(value = "/sr/registSR.do", method = RequestMethod.POST)
    public String registSR(HttpServletRequest req, SRViewVO vo) throws Exception {

        System.out.println(vo.getTgtDt());

        HttpSession session = req.getSession(false);
        UserVO loginInfo = (UserVO) session.getAttribute("userInfo");

        if (loginInfo == null || loginInfo.getUserId() == null) {
            return "/error/";
        }

        vo.setReqEmpId(loginInfo.getUserId());
        vo.setReqEmpDeptId(loginInfo.getDeptId());

        vo.setCrtId(loginInfo.getUserId());
        // vo.setLastModId(loginInfo.getUserId());

        if (vo.getApprovalITListJson() != null && vo.getApprovalITListJson().length() > 10) {
            ObjectMapper mapper = new ObjectMapper();
            List<ApprovalHistVO> approvalList = mapper.readValue(vo.getApprovalListJson(), new TypeReference<List<ApprovalHistVO>>() {});
            List<ApprovalHistVO> approvalITList = mapper.readValue(vo.getApprovalITListJson(), new TypeReference<List<ApprovalHistVO>>() {});

            vo.setApprovalList(approvalList);
            vo.setApprovalITList(approvalITList);
        }

        String srId = procService.selectSRId();
        vo.setSrId(srId);


        procService.insertSR(vo);


        return "redirect:/sr/list.do";

    }


    @RequestMapping(value = "/sr/modifyApprvInfo.do", method = RequestMethod.POST)
    public String modifyApprvInfo(String srNo, ApprovalHistVO vo) throws Exception {
        System.out.println("dddddddddddddddddddddd");
        System.out.println(srNo);
        System.out.println(vo);

        if (vo.getAprvStatus().equals("COMPLETE")) {
            procService.approveSR(vo);
        } else if (vo.getAprvStatus().equals("REJECT")) {
            procService.disapproveSR(vo);
        }


        return "redirect:/sr/detail.do?srNo=" + srNo;

    }

    @RequestMapping(value = "/sr/cancelSR.do", method = RequestMethod.POST)
    public String cancelSR(String srNo, SRViewVO vo) throws Exception {

        // sesssion 값 획듯
        System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
        procService.cancelSR(vo);

        return "redirect:/sr/detail.do?srNo=" + srNo;

    }



    @RequestMapping(value = "/json/searchEmp.json")
    @ResponseBody
    public List<UserVO> selectEmpList(@RequestParam String searchWord) {
        List<UserVO> empList = viewService.selectEmpList(searchWord);
        return empList;
    }


    @RequestMapping(value = "/json/searchITApprovalRule.json")
    @ResponseBody
    public List<ApprovalRuleVO> selectApprovalLine(ApprovalRuleVO ruleVO) {
        System.out.println(ruleVO);
        List<ApprovalRuleVO> approvalLine = approvalService.selectSRApprovalRule(ruleVO);
        return approvalLine;

    }

    @RequestMapping(value = "/sr/getSystemList.json")
    @ResponseBody
    public List<SystemVO> selectSystemListByType(ModelAndView mav) {
        List<SystemVO> systemList = viewService.selectSystemList(Constants.SRType.SOFTWARE);
        return systemList;

    }

    @RequestMapping(value = "/json/test.json")
    @ResponseBody
    public List<TypeVO> selectTypeList(ModelAndView mav) {
        List<TypeVO> systemList = viewService.selectTypeList("SW");
        return systemList;

    }


    @RequestMapping("/getSRList.do")
    @ResponseBody
    public List<SRViewVO> getSRList() {

        // TODO SR 목록 보여주는 거

        // 자신이 올린거
        // 결제 목록이 온거 조인이 필요

        return null;
    }


    @RequestMapping("/getSRListJson.do")
    @ResponseBody
    public List<SRViewVO> getSRListJson() {

        // TODO SR 목록 보여주는 거


        return null;
    }

}
