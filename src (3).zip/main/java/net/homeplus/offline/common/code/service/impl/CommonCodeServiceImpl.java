package net.homeplus.offline.common.code.service.impl;

import java.util.List;

import net.homeplus.offline.common.code.dao.CommonCodeDAO;
import net.homeplus.offline.common.code.service.CommonCodeService;
import net.homeplus.offline.common.code.vo.CodeVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("CommonCodeService")
public class CommonCodeServiceImpl implements CommonCodeService {


    @Autowired
    private CommonCodeDAO commonCodeDAO;

    @Override
    public List<CodeVO> selectCommonCodeListByGroupId(String cdGrpId) {
        return commonCodeDAO.selectCommonCodeListByGroupId(cdGrpId);
    }


}
