package net.homeplus.offline.common.code.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import net.homeplus.offline.common.code.vo.CodeVO;
import net.homeplus.offline.common.dao.CommonDAO;

@Repository("CommonCodeDAO")
public class CommonCodeDAO extends CommonDAO {


    public List<CodeVO> selectCommonCodeListByGroupId(String cdGrpId) {
        return getSqlSession().selectList("Code.selectCommonCodeListByGroupId", cdGrpId);
    }


}
