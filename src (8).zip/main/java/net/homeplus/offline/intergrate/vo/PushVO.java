package net.homeplus.offline.intergrate.vo;


public class PushVO {

    private String srId;
    private String reqType;
    private String reqNm;
    private String reqTel;
    private String reqEmail;
    private String sysCat;
    private String sysNm;
    private String sysMod;
    private String reqTitle;
    private String reqDesc;
    private String expDate;
    private String dataWktype;
    private String piYn;
    private String recDate; // FORMAT : YYYYMMDD
    private String workNm;
    private String attachNum;
    private String srRcv; // default : R
    private String srRcvDate; // FORMAT : YYYYMMDDHHMISS

    public String getSrId() {
        return srId;
    }

    public void setSrId(String srId) {
        this.srId = srId;
    }

    public String getReqType() {
        return reqType;
    }

    public void setReqType(String reqType) {
        this.reqType = reqType;
    }

    public String getReqNm() {
        return reqNm;
    }

    public void setReqNm(String reqNm) {
        this.reqNm = reqNm;
    }

    public String getReqTel() {
        return reqTel;
    }

    public void setReqTel(String reqTel) {
        this.reqTel = reqTel;
    }

    public String getReqEmail() {
        return reqEmail;
    }

    public void setReqEmail(String reqEmail) {
        this.reqEmail = reqEmail;
    }

    public String getSysCat() {
        return sysCat;
    }

    public void setSysCat(String sysCat) {
        this.sysCat = sysCat;
    }

    public String getSysNm() {
        return sysNm;
    }

    public void setSysNm(String sysNm) {
        this.sysNm = sysNm;
    }

    public String getReqTitle() {
        return reqTitle;
    }

    public void setReqTitle(String reqTitle) {
        this.reqTitle = reqTitle;
    }

    public String getReqDesc() {
        return reqDesc;
    }

    public void setReqDesc(String reqDesc) {
        this.reqDesc = reqDesc;
    }


    public String getDataWktype() {
        return dataWktype;
    }

    public void setDataWktype(String dataWktype) {
        this.dataWktype = dataWktype;
    }

    public String getPiYn() {
        return piYn;
    }

    public void setPiYn(String piYn) {
        this.piYn = piYn;
    }

    public String getRecDate() {
        return recDate;
    }

    public void setRecDate(String recDate) {
        this.recDate = recDate;
    }

    public String getWorkNm() {
        return workNm;
    }

    public void setWorkNm(String workNm) {
        this.workNm = workNm;
    }

    public String getAttachNum() {
        return attachNum;
    }

    public void setAttachNum(String attachNum) {
        this.attachNum = attachNum;
    }

    public String getSrRcv() {
        return srRcv;
    }

    public void setSrRcv(String srRcv) {
        this.srRcv = srRcv;
    }

    public String getSrRcvDate() {
        return srRcvDate;
    }

    public void setSrRcvDate(String srRcvDate) {
        this.srRcvDate = srRcvDate;
    }

    public String getExpDate() {
        return expDate;
    }

    public void setExpDate(String expDate) {
        this.expDate = expDate;
    }

    public String getSysMod() {
        return sysMod;
    }

    public void setSysMod(String sysMod) {
        this.sysMod = sysMod;
    }



}
