package net.homeplus.offline.sr.account.dao;

import java.util.List;

import net.homeplus.offline.common.dao.CommonDAO;
import net.homeplus.offline.common.vo.UserVO;

import org.springframework.stereotype.Repository;

@Repository("AccountDAO")
public class AccountDAO extends CommonDAO {

    public UserVO selectUserInfo(String userId) {
        return getSqlSession().selectOne("Account.selectUserInfo", userId);
    }

    public List<UserVO> selectAllUserInfo() {
        return getSqlSession().selectList("Account.selectAllUserInfo");
    }

}
