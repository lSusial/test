SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_ATTACH (
  SR_ID	VARCHAR(11)	NOT NULL,
  FILE_NM	VARCHAR(241)	NOT NULL,
  ORG_FILE_NM	VARCHAR(250),
  CRT_ID	VARCHAR(10),
  CRT_DTTM	TIMESTAMP,
  LAST_MOD_ID	VARCHAR(10),
  LAST_MOD_DTTM	TIMESTAMP,
  FILE_DIR	VARCHAR(50)
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_ATTACH
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_ATTACH
  ADD PRIMARY KEY
    (SR_ID, FILE_NM)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_ATTACH
	ALLOW WRITE ACCESS;



insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000089','LGPL02010033.TXT','LGPL.TXT',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000089','license02010033.txt','license.txt',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','시스템_변경_요청서','시스템_변경_요청서',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','RPM_요청서','RPM_요청서',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','GMIS_쿼리문_수정/신청_요청서','GMIS_쿼리문_수정/신청_요청서',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','GMIS_Ad-hos_Report_요청서','GMIS_Ad-hos_Report_요청서',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','IP_Address_신청서_개인','IP_Address_신청서_개인',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','LGPL02010033.TXT','LGPL.TXT',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000121','02060225.','',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000161','02060805.','',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000162','02060809.','',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000307','mobile_event02141145.jpg','mobile_event.jpg',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000307','mobile_event_전문보기202141145.jpg','mobile_event_전문보기2.jpg',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000311','popup302141151.jpg','popup3.jpg',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000313','popup102141153.jpg','popup1.jpg',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000316','mobile_event02141230.jpg','mobile_event.jpg',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000317','popup102141242.jpg','popup1.jpg',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000319','popup102141245.jpg','popup1.jpg',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000320','web_event02141250.jpg','web_event.jpg',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000361','license02160448.txt','license.txt',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000380','license02160722.txt','license.txt',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000383','license02160726.txt','license.txt',null,null,null,null,'2017\02\00000000383\');
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000414','update02200407.txt','update.txt',null,null,null,null,'2017\02\00000000414\');
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000416','update02200414.txt','update.txt',null,null,null,null,'2017\02\00000000416\');
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000417','license02200416.txt','license.txt',null,null,null,null,'2017\02\00000000417\');
