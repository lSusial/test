SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_SYSTEM (
  SYS_ID	VARCHAR(20)	NOT NULL,
  SYS_NM	VARCHAR(30)	NOT NULL,
  SYS_TP_CD	VARCHAR(10)	NOT NULL,
  SYS_DESC	VARCHAR(300),
  SYS_DEPT_ID	VARCHAR(10),
  SYS_CHRG_EMP_ID	VARCHAR(10),
  SYS_SUB_EMP_ID	VARGRAPHIC(10),
  DISP_ORD	DECIMAL(5, 0),
  USE_YN	VARCHAR(1),
  CRT_ID	VARCHAR(14),
  CRT_DTTM	TIMESTAMP,
  LAST_MOD_ID	VARCHAR(10),
  LAST_MOD_DTTM	TIMESTAMP,
  SYS_CATE_ID	VARCHAR(15),
  SYS_CATE_NM	VARCHAR(50)
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_SYSTEM
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_SYSTEM
  ADD PRIMARY KEY
    (SYS_ID, SYS_TP_CD)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_SYSTEM
	ALLOW WRITE ACCESS;



insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('SYS001','시스템1','SW','샘플1','DEPT_001','test1','test2',10,'Y','system',null,'system','2017-01-12-15.26.27.000000',null,null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('SYS002','시스템2','SW','샘플2','DEPT_002','test3','test4',20,'Y','system',null,'system','2017-01-12-15.27.07.000000',null,null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('SYS003','시스템3','SW','샘플3','DEPT_003','test1','test2',30,'Y','system',null,'system','2017-01-12-15.26.27.000000',null,null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('SYS004','시스템4','SW','샘플4','DEPT_004','test1','test2',40,'Y','system',null,'system','2017-01-12-15.26.27.000000',null,null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('SYS005','시스템5','HW','샘플5','DEPT_005','test1','test2',50,'Y','system',null,'system','2017-01-12-15.26.27.000000',null,null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('SYS006','POS 운영','HW','샘플',null,null,null,null,null,null,null,null,null,null,null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H100010','키등록/수정','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-00.50.29.894000','H100',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H100020','POS 이동/설치','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.17.660000','H100',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H100030','기타변경','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.17.691000','H100',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H110010','일렬, 별도 POS','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.17.707000','H110',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H110020','무인 POS(SSC)','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.17.722000','H110',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H110030','Mobile POS','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.17.738000','H110',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H110040','식권자판기','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.17.832000','H110',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H120010','재고용PDA','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.17.847000','H120',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H130010','전자저울','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.17.894000','H130',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H140010','유선(고정형)RtoC','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.17.910000','H140',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H140020','무선(이동형)RtoC','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.17.925000','H140',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H150010','HW','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.17.941000','H150',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H150020','SW','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.17.972000','H150',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H160010','AP 이동설치','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.17.988000','H160',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H160020','AP 추가설치','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.18.019000','H160',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H170010','FMC','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.18.034000','H170',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H170020','wine','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.18.050000','H170',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H170030','source','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.18.081000','H170',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('H170040','축산','HW','','DEPT_006',null,null,10,'Y','system',null,'SYSTEM','2017-02-14-01.01.18.097000','H170',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('100010','RMS','SW',null,null,null,null,null,'Y',null,null,null,null,'100',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('100020','FSS','SW',null,null,null,null,null,'Y',null,null,null,null,'100',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('110010','RMS','SW',null,null,null,null,null,'Y',null,null,null,null,'110',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('110020','RDF','SW',null,null,null,null,null,'Y',null,null,null,null,'110',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('120010','RIB','SW',null,null,null,null,null,'Y',null,null,null,null,'120',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('130010','IKB','SW',null,null,null,null,null,'Y',null,null,null,null,'130',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('150010','EIS','SW',null,null,null,null,null,'Y',null,null,null,null,'150',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('160010','F3','SW',null,null,null,null,null,'Y',null,null,null,null,'160',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('170010','POS SW','SW',null,null,null,null,null,'Y',null,null,null,null,'170',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('170020','HBO','SW',null,null,null,null,null,'Y',null,null,null,null,'170',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('140010','OF(Oracle Financial)','SW',null,null,null,null,null,'Y',null,null,null,null,'140',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('140020','RMS','SW',null,null,null,null,null,'Y',null,null,null,null,'140',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('180010','NGC','SW',null,null,null,null,null,'Y',null,null,null,null,'180',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('180020','FMC 고객관리시스템','SW',null,null,null,null,null,'Y',null,null,null,null,'180',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('190010','HR-HUB/HR-Partner(PDSS)','SW',null,null,null,null,null,'Y',null,null,null,null,'190',null);
insert into "TB_SYSTEM"("SYS_ID","SYS_NM","SYS_TP_CD","SYS_DESC","SYS_DEPT_ID","SYS_CHRG_EMP_ID","SYS_SUB_EMP_ID","DISP_ORD","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","SYS_CATE_ID","SYS_CATE_NM") values ('200010','Plusmobile','SW',null,null,null,null,null,'Y',null,null,null,null,'200',null);
