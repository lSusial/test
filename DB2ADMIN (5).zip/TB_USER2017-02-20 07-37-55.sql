SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_USER (
  USER_ID	VARCHAR(100)	NOT NULL,
  USER_NM	VARCHAR(30),
  DEPT_ID	VARCHAR(10),
  LEVEL_CD	VARCHAR(10),
  GUBUN	VARCHAR(10),
  EMAIL	VARCHAR(100),
  CREATE_DATE	VARCHAR(10),
  JOB_TITLE	VARCHAR(30)
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_USER
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_USER
  ADD PRIMARY KEY
    (USER_ID)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_USER
	ALLOW WRITE ACCESS;



insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('hardware','하드웨어결제자','TEMP_006',null,null,'hardware@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('hoonyyoon','윤영훈','TEMP_001',null,null,'hoonyyoon@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('yl.kim','김예린','TEMP_001',null,null,'yl.kim@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('dahchoi','최다현','TEMP_002',null,null,'dahchoi@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('rk.park','박로경','TEMP_003',null,null,'rk.park@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('nick','김연익','TEMP_001','',null,'nick@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('kjkim','김기종','TEMP_002',null,null,'kjkim@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('superiork','김용찬','TEMP_003',null,null,'superiork@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('sangminl','이상민','TEMP_004',null,null,'sangminl@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('parksm','박시몬','TEMP_004',null,null,'parksm@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('test1','사용자1','TEMP_005',null,null,'test1@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('alter1','대결자1','TEMP_001',null,null,'alter1@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('alter2','대결자2','TEMP_002',null,null,'alter2@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('test2','사용자2','TEMP_005',null,null,'test2@homeplus.co.kr',null,'직급');
