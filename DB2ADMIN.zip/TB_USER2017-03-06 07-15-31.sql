SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_USER (
  USER_ID	VARCHAR(100)	NOT NULL,
  USER_NM	VARCHAR(30),
  DEPT_ID	VARCHAR(10),
  LEVEL_CD	VARCHAR(10),
  GUBUN	VARCHAR(10),
  EMAIL	VARCHAR(100),
  CREATE_DATE	VARCHAR(10),
  JOB_TITLE	VARCHAR(30)
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_USER
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_USER
  ADD PRIMARY KEY
    (USER_ID)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_USER
	ALLOW WRITE ACCESS;



insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('hardware','하드웨어결제자','TEMP_006',null,null,'hardware@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('nick','김연익','offline',null,null,'nick@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('yoonhj','윤형주','offline',null,null,'yoonhj@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('masuni','김미순','offline',null,null,'masuni@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('jang7203','장종혁','offline',null,null,'jang7203@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('test3','문화센터결재자','TEMP_003',null,null,'test3@homeplus.com.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('eunjungko','고은정','offline',null,null,'eunjungko@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('leeplus','이양수','offline',null,null,'leeplus@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('bongkyu.kim','김봉규','offline',null,null,'bongkyu.kim@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('kjkim','김기종','offline',null,null,'kjkim@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('MYUNGHWAN.KIM','김명환','offline',null,null,'MYUNGHWAN.KIM@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('sodoh','도선옥','offline',null,null,'sodoh@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('kimyt','김율태','offline',null,null,'kimyt@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('angela','한은선','offline',null,null,'angela@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('shbae','배성희','offline',null,null,'shbae@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('superiork','김용찬','offline',null,null,'superiork@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('tndh1109','안수오','offline',null,null,'tndh1109@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('sangminl','이상민','TEMP_004',null,null,'sangminl@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('parksm','박시몬','TEMP_004',null,null,'parksm@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('test1','사용자1','TEMP_005',null,null,'test1@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('alter1','대결자1','TEMP_001',null,null,'alter1@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('alter2','대결자2','TEMP_002',null,null,'alter2@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('test2','사용자2','TEMP_005',null,null,'test2@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('TEMPHQOP','HQ OP','offline',null,null,'TEMPHQOP@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('meamy','조성호','offline',null,null,'meamy@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('delnull','이재훈','offline',null,null,'delnull@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('dahchoi','최다현','offline',null,null,'dahchoi@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('caiser97','김진년','offline',null,null,'caiser97@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('yhlee04','이용한','offline',null,null,'yhlee04@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('kjm7307','김종민','offline',null,null,'kjm7307@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('jwcha','차재원','offline',null,null,'jwcha@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('base_004','공석우','offline',null,null,'base_004@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('satinkim','김지태','offline',null,null,'satinkim@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('whitepaper117','지준희','offline',null,null,'whitepaper117@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('ipas71','박철순','offline',null,null,'ipas71@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('yl.kim','김예린','offline',null,null,'yl.kim@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('lyh','이연호','offline',null,null,'lyh@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('daewoo','김대우','offline',null,null,'daewoo@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('soko','고상옥','offline',null,null,'soko@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('sjcjju','장종의','offline',null,null,'sjcjju@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('suntae','김선태','offline',null,null,'suntae@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('5stones','오승석','offline',null,null,'5stones@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('krkim','김경륜','offline',null,null,'krkim@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('tenknight','이효열','offline',null,null,'tenknight@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('cw1022','조완','offline',null,null,'cw1022@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('kichul.yoon','윤기철','offline',null,null,'kichul.yoon@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('kimjunghoon','김정훈','offline',null,null,'kimjunghoon@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('sukhoi37','손민우','offline',null,null,'sukhoi37@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('taeseong','이태성','offline',null,null,'taeseong@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('jiny','진대욱','offline',null,null,'jiny@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('woojeong.lee','이우정','offline',null,null,'woojeong.lee@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('bokhyejin','복혜진','offline',null,null,'bokhyejin@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('rosemose','김동조','offline',null,null,'rosemose@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('parting2','김대윤','offline',null,null,'parting2@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('jgs0819','정관수','offline',null,null,'jgs0819@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('jang.jaemin','장재민','offline',null,null,'jang.jaemin@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('gozio','이희정','offline',null,null,'gozio@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('mskimhome','김명수','offline',null,null,'mskimhome@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('kimhj','김희준','offline',null,null,'kimhj@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('nyloper','이대호','offline',null,null,'nyloper@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('friendy','김정민','offline',null,null,'friendy@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('daegil001','유철희','offline',null,null,'daegil001@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('jaebumjeon','전재범','offline',null,null,'jaebumjeon@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('yeonsu.kim','김연수','offline',null,null,'yeonsu.kim@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('vision3920','이상국','offline',null,null,'vision3920@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('yeonok','오연옥','offline',null,null,'yeonok@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('TEMP최학규','최학규','offline',null,null,'TEMP최학규@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('stargate','김봉숙','offline',null,null,'stargate@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('dongsock','정동석','offline',null,null,'dongsock@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('jwjang','장재원','offline',null,null,'jwjang@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('attractiveSU','박수영','offline',null,null,'attractiveSU@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('nojungki','이중기','offline',null,null,'nojungki@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('leesp','이성풍','offline',null,null,'leesp@homeplus.co.kr',null,'직급');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE","JOB_TITLE") values ('bangko','정홍렬','offline',null,null,'bangko@homeplus.co.kr',null,'직급');
