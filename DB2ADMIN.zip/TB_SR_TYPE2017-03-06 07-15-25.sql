SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_SR_TYPE (
  SR_TYPE_ID	VARCHAR(4)	NOT NULL,
  SR_TYPE_NM	VARCHAR(50)	NOT NULL,
  TGR_TP_CD	CHARACTER(2)	NOT NULL,
  APPR_REQ_YN	CHARACTER(1)	NOT NULL,
  USE_YN	VARCHAR(10),
  CRT_ID	VARCHAR(10),
  CRT_DTTM	TIMESTAMP,
  LAST_MOD_ID	VARCHAR(10),
  LAST_MOD_DTTM	TIMESTAMP
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_SR_TYPE
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_SR_TYPE
  ADD PRIMARY KEY
    (SR_TYPE_ID)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_SR_TYPE
	ALLOW WRITE ACCESS;



insert into "TB_SR_TYPE"("SR_TYPE_ID","SR_TYPE_NM","TGR_TP_CD","APPR_REQ_YN","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('US','문의','SW','N','Y',null,null,null,null);
insert into "TB_SR_TYPE"("SR_TYPE_ID","SR_TYPE_NM","TGR_TP_CD","APPR_REQ_YN","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('UA','권한 요청','SW','Y','Y',null,null,null,null);
insert into "TB_SR_TYPE"("SR_TYPE_ID","SR_TYPE_NM","TGR_TP_CD","APPR_REQ_YN","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('UD','데이터 추출 변경','SW','Y','Y',null,null,null,null);
insert into "TB_SR_TYPE"("SR_TYPE_ID","SR_TYPE_NM","TGR_TP_CD","APPR_REQ_YN","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SR','프로그램 변경','SW','Y','Y',null,null,null,null);
insert into "TB_SR_TYPE"("SR_TYPE_ID","SR_TYPE_NM","TGR_TP_CD","APPR_REQ_YN","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('RP','점검 / 수리','HW','N','Y',null,null,null,null);
insert into "TB_SR_TYPE"("SR_TYPE_ID","SR_TYPE_NM","TGR_TP_CD","APPR_REQ_YN","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('PS','구입','HW','Y','Y',null,null,null,null);
insert into "TB_SR_TYPE"("SR_TYPE_ID","SR_TYPE_NM","TGR_TP_CD","APPR_REQ_YN","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('ES','견적요청','HW','N','Y',null,null,null,null);
