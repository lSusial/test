SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_MODULE (
  MOD_ID	VARCHAR(15)	NOT NULL,
  SYS_ID	VARCHAR(20)	NOT NULL,
  MOD_NM	VARCHAR(100),
  MOD_DESC	VARCHAR(300),
  MOD_CHRG_EMP_ID	VARCHAR(100),
  MOD_CHRG_DEPT_ID	VARGRAPHIC(50),
  CRT_ID	VARCHAR(14),
  CRT_DTTM	TIMESTAMP,
  LAST_MOD_ID	VARCHAR(10),
  LAST_MOD_DTTM	TIMESTAMP
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_MODULE
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_MODULE
  ADD PRIMARY KEY
    (MOD_ID, SYS_ID)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_MODULE
	ALLOW WRITE ACCESS;



insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('MOD001','MSYS001','모듈1-1',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('MOD002','MSYS001','모듈1-2',null,'test12@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('MOD003','MSYS001','모듈1-3',null,'test13@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('MOD004','MSYS002','모듈2-1',null,'test14@homeplus.co.kr','DEPT_002',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('MOD005','MSYS002','모듈2-2',null,'test15@homeplus.co.kr','DEPT_002',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010010','H110010','본체',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010020','H110010','체커용모니터',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010030','H110010','고객용모니터',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010040','H110010','키보드',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010050','H110010','사인패드',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010060','H110010','건스캐너',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010070','H110010','고정스캐너',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010080','H110010','금전함',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010090','H110010','프린터',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010100','H110010','Program Error (S/W)',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110020010','H110020','본체',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110020020','H110020','건스캐너',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110020030','H110020','고정스캐너',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110020040','H110020','사인패드',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110020050','H110020','금전함',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110020060','H110020','Program Error (S/W)',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110030010','H110030','NMPOS',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110030020','H110030','UMPOS',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110030030','H110030','UMPOS2',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110030040','H110030','UMPOS3',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110040010','H110040','H/W',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110040020','H110040','S/W',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('150010010','H150010','본체',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('150010020','H150010','모니터',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('150010030','H150010','노트북',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('150010040','H150010','프린터',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('150020010','H150020','Window 설정, Program Error',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('A','100010','가격/행사',null,'tndh1109',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('B','100010','마스터관련',null,'tndh1109',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('C','100010','사용자관리',null,'TEMPHQOP',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('D','100010','재고/재고조사',null,'tndh1109',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('E','100010','기타',null,'tndh1109',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','100020','N/A',null,'tndh1109',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','100030','N/A',null,'tndh1109',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','100040','N/A',null,'meamy',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','100050','N/A',null,'delnull',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','100060','N/A',null,'dahchoi',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','100080','N/A',null,'meamy',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','100090','N/A',null,'caiser97',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('A','110010','대출입/반품',null,'yhlee04',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('B','110010','발주/매입',null,'yhlee04',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('C','110010','재고조정/자가소비',null,'yhlee04',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('A','110020','Hyper RDF',null,'yhlee04',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('B','110020','Small Format RDF',null,'meamy',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','110030','N/A',null,'kjm7307',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','110040','N/A',null,'kjm7307',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','110050','N/A',null,'delnull',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','120010','N/A',null,'jwcha',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','120020','N/A',null,'base_004',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','120030','N/A',null,'satinkim',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','120040','N/A',null,'whitepaper117',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','120050','N/A',null,'ipas71',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','120060','N/A',null,'delnull',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','120070','N/A',null,'base_004',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','120080','N/A',null,'base_004',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','120090','N/A',null,'base_004',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','130010','N/A',null,'yl.kim',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','130020','N/A',null,'yl.kim',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','130030','N/A',null,'yl.kim',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','130040','N/A',null,'yl.kim',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','130050','N/A',null,'yl.kim',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','130060','N/A',null,'whitepaper117',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','130070','N/A',null,'whitepaper117',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('A','140010','ReSA',null,'yhlee04',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('B','140020','Stock ledger',null,'lyh',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','150010','N/A',null,'lyh',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','150020','N/A',null,'caiser97',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','150030','N/A',null,'delnull',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','150040','N/A',null,'caiser97',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','160010','N/A',null,'whitepaper117',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','160020','N/A',null,'whitepaper117',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180010','N/A',null,'daewoo',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180020','N/A',null,'daewoo',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180030','N/A',null,'daewoo',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180040','N/A',null,'daewoo',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180050','N/A',null,'daewoo',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180060','N/A',null,'daewoo',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180070','N/A',null,'daewoo',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180080','N/A',null,'soko',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180090','N/A',null,'daewoo',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180100','N/A',null,'sjcjju',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180110','N/A',null,'sjcjju',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180120','N/A',null,'sjcjju',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180130','N/A',null,'sjcjju',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180140','N/A',null,'sjcjju',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180150','N/A',null,'sjcjju',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180160','N/A',null,'sjcjju',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180170','N/A',null,'sjcjju',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180180','N/A',null,'sjcjju',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180190','N/A',null,'sjcjju',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180200','N/A',null,'sjcjju',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180210','N/A',null,'sjcjju',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180220','N/A',null,'suntae',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180230','N/A',null,'suntae',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180240','N/A',null,'suntae',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180250','N/A',null,'suntae',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('A','180260','재고',null,'5stones',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('B','180260','웹',null,'krkim',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('C','180260','매출/매가변경',null,'tenknight',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('A','180270','재고/웹',null,'cw1022',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('B','180270','매출/매가변경',null,'tenknight',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('A','180280','재고/웹',null,'kichul.yoon',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('B','180280','매출/매가변경',null,'tenknight',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180290','N/A',null,'tenknight',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180300','N/A',null,'krkim',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180310','N/A',null,'kimjunghoon',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180320','N/A',null,'kimjunghoon',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180330','N/A',null,'kimjunghoon',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180340','N/A',null,'kimjunghoon',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180350','N/A',null,'kimjunghoon',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180360','N/A',null,'kimjunghoon',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180370','N/A',null,'kimjunghoon',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180380','N/A',null,'sukhoi37',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180390','N/A',null,'kichul.yoon',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180400','N/A',null,'yhlee04',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180410','N/A',null,'kjm7307',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180420','N/A',null,'kjm7307',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180430','N/A',null,'taeseong',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180440','N/A',null,'taeseong',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180450','N/A',null,'taeseong',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('A','180460','배치',null,'sukhoi37',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('B','180460','웹',null,'cw1022',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180470','N/A',null,'suntae',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180480','N/A',null,'suntae',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180490','N/A',null,'suntae',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180500','N/A',null,'jiny',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180510','N/A',null,'jiny',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180520','N/A',null,'jiny',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180530','N/A',null,'dahchoi',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','180540','N/A',null,'sjcjju',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190010','N/A',null,'woojeong.lee',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190020','N/A',null,'woojeong.lee',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190030','N/A',null,'woojeong.lee',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190040','N/A',null,'woojeong.lee',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190050','N/A',null,'bokhyejin',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190060','N/A',null,'rosemose',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190070','N/A',null,'bokhyejin',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190080','N/A',null,'parting2',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190090','N/A',null,'bokhyejin',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190100','N/A',null,'parting2',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190110','N/A',null,'parting2',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190120','N/A',null,'parting2',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190130','N/A',null,'jgs0819',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190140','N/A',null,'satinkim',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190150','N/A',null,'woojeong.lee',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','190160','N/A',null,'jang.jaemin',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200010','N/A',null,'gozio',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200020','N/A',null,'mskimhome',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200030','N/A',null,'kimhj',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('A','200040','고객/카드/포인트 관리',null,'gozio',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('B','200040','클럽관리',null,'kimhj',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('C','200040','현금쿠폰관리',null,'nyloper',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('D','200040','메일링 관리',null,'kimhj',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('E','200040','탈퇴회원관리',null,'kimhj',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200050','N/A',null,'mskimhome',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200060','N/A',null,'kimhj',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200070','N/A',null,'mskimhome',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200080','N/A',null,'nyloper',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200090','N/A',null,'nyloper',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200100','N/A',null,'nyloper',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200110','N/A',null,'nyloper',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200120','N/A',null,'kimhj',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200130','N/A',null,'meamy',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200140','N/A',null,'ipas71',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200150','N/A',null,'ipas71',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200160','N/A',null,'mskimhome',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200170','N/A',null,'mskimhome',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200180','N/A',null,'gozio',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200190','N/A',null,'gozio',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200200','N/A',null,'mskimhome',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200210','N/A',null,'nyloper',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200220','N/A',null,'nyloper',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200230','N/A',null,'nyloper',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200240','N/A',null,'nyloper',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200250','N/A',null,'friendy',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200260','N/A',null,'daegil001',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200270','N/A',null,'jaebumjeon',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200280','N/A',null,'friendy',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200290','N/A',null,'yeonsu.kim',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('A','200300','Front(PC/mobile)',null,'vision3920',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('B','200310','Admin',null,'yeonok',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200320','N/A',null,'rosemose',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','200330','N/A',null,'rosemose',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','210010','N/A',null,'jgs0819',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','210020','N/A',null,'jgs0819',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','210030','N/A',null,'jgs0819',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','210040','N/A',null,'jgs0819',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','210050','N/A',null,'jwcha',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','210060','N/A',null,'TEMP최학규',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','210070','N/A',null,'jwcha',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','210080','N/A',null,'vision3920',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','210090','N/A',null,'yeonok',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','210100','N/A',null,'yeonok',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','210110','N/A',null,'stargate',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','210120','N/A',null,'stargate',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','210130','N/A',null,'stargate',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','220010','N/A',null,'jang.jaemin',null,null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('N','220020','N/A',null,'dongsock',null,null,null,null,null);
