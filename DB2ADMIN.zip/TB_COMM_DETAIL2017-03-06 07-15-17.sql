SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_COMM_DETAIL (
  CD_GRP_ID	VARCHAR(10)	NOT NULL,
  CD_ID	VARCHAR(10)	NOT NULL,
  CD_NM	VARCHAR(50),
  ATTR1	VARCHAR(10),
  ATTR2	VARCHAR(10),
  ATTR3	VARGRAPHIC(10),
  USE_YN	VARCHAR(10)	NOT NULL,
  CRT_ID	VARCHAR(10),
  CRT_DTTM	TIMESTAMP,
  LAST_MOD_ID	INTEGER,
  LAST_MOD_DTTM	TIMESTAMP,
  DISP_ORD	SMALLINT
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_COMM_DETAIL
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_COMM_DETAIL
  ADD PRIMARY KEY
    (CD_GRP_ID, CD_ID)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_COMM_DETAIL
	ALLOW WRITE ACCESS;



insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SRS','010','접수',null,null,null,'N',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SRS','APPROVING','결재중',null,null,null,'N',null,null,null,null,10);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SRS','WORKING','처리중',null,null,null,'Y',null,null,null,null,20);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SRS','COMPLETE','완료',null,null,null,'Y',null,null,null,null,30);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SRS','REJECT','반려',null,null,null,'Y',null,null,null,null,40);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('HWCAT','H100','POS 운영',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('HWCAT','H110','POS 장비',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('HWCAT','H120','RtoC',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('HWCAT','H130','OA PC',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('HWCAT','H140','재고용PDA',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('HWCAT','H150','전자저울',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('HWCAT','H160','네트워크',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('HWCAT','H170','KIOSK',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SWCAT','100','상품',null,null,null,'Y',null,null,null,null,100);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SWCAT','110','SCM',null,null,null,'Y',null,null,null,null,110);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SWCAT','120','물류',null,null,null,'Y',null,null,null,null,120);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SWCAT','130','SRD',null,null,null,'Y',null,null,null,null,130);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SWCAT','140','재무',null,null,null,'Y',null,null,null,null,140);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SWCAT','150','리포트',null,null,null,'Y',null,null,null,null,150);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SWCAT','160','Small Format',null,null,null,'Y',null,null,null,null,160);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SWCAT','180','점포',null,null,null,'Y',null,null,null,null,180);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SWCAT','190','재무',null,null,null,'Y',null,null,null,null,190);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SWCAT','200','마케팅',null,null,null,'Y',null,null,null,null,200);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SWCAT','210','인사',null,null,null,'Y',null,null,null,null,210);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SWCAT','220','서비스상품',null,null,null,'Y',null,null,null,null,220);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('DTYPE','D001','데이터 추출 종류',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('DTYPE','D002','CEO 보고용',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('DTYPE','D003','임원 보고용',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('DTYPE','D004','경영전략 수립용',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('DTYPE','D005','단순 참고용',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('DTYPE','D006','기타',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SRS','CANCEL','취소',null,null,null,'Y',null,null,null,null,50);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('APS','COMPLETE','승인',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('APS','INPROGRESS','진행중',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('APS','WAITING','대기중',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('APS','REJECT','반려',null,null,null,'Y',null,null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SRS','DCAPRV','부서장 결재중',null,null,null,'Y',null,null,null,null,10);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('SRS','ITAPRV','IT 결재중',null,null,null,'Y',null,null,null,null,15);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","DISP_ORD") values ('APS','CANCEL','취소',null,null,null,'Y',null,null,null,null,45);
