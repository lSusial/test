package net.homeplus.offline.sr.approval.vo;

import net.homeplus.offline.common.vo.BaseVO;

public class ApprovalHistVO extends BaseVO {

    private String aprvRuleId;
    private String aprvRuleSeq;
    private String srId;
    private String aprvDeptId;
    private String aprvEmpId;
    private String aprvStatus;
    private String mailSendYn;
    private String aprvDttm;

    public String getAprvRuleId() {
        return aprvRuleId;
    }

    public void setAprvRuleId(String aprvRuleId) {
        this.aprvRuleId = aprvRuleId;
    }

    public String getAprvRuleSeq() {
        return aprvRuleSeq;
    }

    public void setAprvRuleSeq(String aprvRuleSeq) {
        this.aprvRuleSeq = aprvRuleSeq;
    }

    public String getSrId() {
        return srId;
    }

    public void setSrId(String srId) {
        this.srId = srId;
    }

    public String getAprvDeptId() {
        return aprvDeptId;
    }

    public void setAprvDeptId(String aprvDeptId) {
        this.aprvDeptId = aprvDeptId;
    }

    public String getAprvEmpId() {
        return aprvEmpId;
    }

    public void setAprvEmpId(String aprvEmpId) {
        this.aprvEmpId = aprvEmpId;
    }

    public String getAprvStatus() {
        return aprvStatus;
    }

    public void setAprvStatus(String aprvStatus) {
        this.aprvStatus = aprvStatus;
    }

    public String getMailSendYn() {
        return mailSendYn;
    }

    public void setMailSendYn(String mailSendYn) {
        this.mailSendYn = mailSendYn;
    }

    public String getAprvDttm() {
        return aprvDttm;
    }

    public void setAprvDttm(String aprvDttm) {
        this.aprvDttm = aprvDttm;
    }



}
