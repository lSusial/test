package net.homeplus.offline.sr.view.service;

import java.util.List;
import java.util.Map;

import net.homeplus.offline.common.vo.UserVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;
import net.homeplus.offline.sr.view.vo.SystemVO;
import net.homeplus.offline.sr.view.vo.TypeVO;

public interface ViewService {
    public List<SRViewVO> selectSRList();

    public Map<String, Object> selectSRDetail();

    public List<TypeVO> selectTypeList(String type);

    public List<SystemVO> selectSystemList(String type);

    public List<UserVO> selectEmpList(String searchWord);

}
