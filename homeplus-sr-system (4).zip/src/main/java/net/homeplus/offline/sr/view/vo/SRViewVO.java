package net.homeplus.offline.sr.view.vo;

import java.util.List;

import net.homeplus.offline.sr.approval.vo.ApprovalRuleVO;

public class SRViewVO {

    private String srId;
    private String srTypeId;
    private String sysId;
    private String reqEmpId;
    private String reqEmpDeptId;
    private String reqEmpEmail;
    private String reqEmpTel;
    private String title;
    private String desc;
    private String confDataYn;
    private String tgtDt;
    private String status;
    private String chrgEmpId;
    private String chrgEmpDeptId;
    private String finalAprvDttm;
    private String closeDttm;
    private String etc1;
    private String etc2;
    private String etc3;
    private String crtId;
    private String crtDttm;
    private String lastModId;
    private String lastModDttm;

    private String approvalListJson;
    private String approvalITListJson;

    public String getApprovalListJson() {
        return approvalListJson;
    }

    public void setApprovalListJson(String approvalListJson) {
        this.approvalListJson = approvalListJson;
    }

    public String getApprovalITListJson() {
        return approvalITListJson;
    }

    public void setApprovalITListJson(String approvalITListJson) {
        this.approvalITListJson = approvalITListJson;
    }

    private List<ApprovalRuleVO> approvalList;
    private List<ApprovalRuleVO> approvalITList;


    public List<ApprovalRuleVO> getApprovalList() {
        return approvalList;
    }

    public void setApprovalList(List<ApprovalRuleVO> approvalList) {
        this.approvalList = approvalList;
    }

    public List<ApprovalRuleVO> getApprovalITList() {
        return approvalITList;
    }

    public void setApprovalITList(List<ApprovalRuleVO> approvalITList) {
        this.approvalITList = approvalITList;
    }

    public String getSrId() {
        return srId;
    }

    public void setSrId(String srId) {
        this.srId = srId;
    }

    public String getSrTypeId() {
        return srTypeId;
    }

    public void setSrTypeId(String srTypeId) {
        this.srTypeId = srTypeId;
    }

    public String getSysId() {
        return sysId;
    }

    public void setSysId(String sysId) {
        this.sysId = sysId;
    }

    public String getReqEmpId() {
        return reqEmpId;
    }

    public void setReqEmpId(String reqEmpId) {
        this.reqEmpId = reqEmpId;
    }

    public String getReqEmpDeptId() {
        return reqEmpDeptId;
    }

    public void setReqEmpDeptId(String reqEmpDeptId) {
        this.reqEmpDeptId = reqEmpDeptId;
    }

    public String getReqEmpEmail() {
        return reqEmpEmail;
    }

    public void setReqEmpEmail(String reqEmpEmail) {
        this.reqEmpEmail = reqEmpEmail;
    }

    public String getReqEmpTel() {
        return reqEmpTel;
    }

    public void setReqEmpTel(String reqEmpTel) {
        this.reqEmpTel = reqEmpTel;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getConfDataYn() {
        return confDataYn;
    }

    public void setConfDataYn(String confDataYn) {
        this.confDataYn = confDataYn;
    }

    public String getTgtDt() {
        return tgtDt;
    }

    public void setTgtDt(String tgtDt) {
        this.tgtDt = tgtDt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getChrgEmpId() {
        return chrgEmpId;
    }

    public void setChrgEmpId(String chrgEmpId) {
        this.chrgEmpId = chrgEmpId;
    }

    public String getChrgEmpDeptId() {
        return chrgEmpDeptId;
    }

    public void setChrgEmpDeptId(String chrgEmpDeptId) {
        this.chrgEmpDeptId = chrgEmpDeptId;
    }

    public String getFinalAprvDttm() {
        return finalAprvDttm;
    }

    public void setFinalAprvDttm(String finalAprvDttm) {
        this.finalAprvDttm = finalAprvDttm;
    }

    public String getCloseDttm() {
        return closeDttm;
    }

    public void setCloseDttm(String closeDttm) {
        this.closeDttm = closeDttm;
    }

    public String getEtc1() {
        return etc1;
    }

    public void setEtc1(String etc1) {
        this.etc1 = etc1;
    }

    public String getEtc2() {
        return etc2;
    }

    public void setEtc2(String etc2) {
        this.etc2 = etc2;
    }

    public String getEtc3() {
        return etc3;
    }

    public void setEtc3(String etc3) {
        this.etc3 = etc3;
    }

    public String getCrtId() {
        return crtId;
    }

    public void setCrtId(String crtId) {
        this.crtId = crtId;
    }

    public String getCrtDttm() {
        return crtDttm;
    }

    public void setCrtDttm(String crtDttm) {
        this.crtDttm = crtDttm;
    }

    public String getLastModId() {
        return lastModId;
    }

    public void setLastModId(String lastModId) {
        this.lastModId = lastModId;
    }

    public String getLastModDttm() {
        return lastModDttm;
    }

    public void setLastModDttm(String lastModDttm) {
        this.lastModDttm = lastModDttm;
    }

    @Override
    public String toString() {
        return "SRViewVO [srId=" + srId + ", srTypeId=" + srTypeId + ", sysId=" + sysId + ", reqEmpId=" + reqEmpId + ", reqEmpDeptId=" + reqEmpDeptId
                + ", reqEmpEmail=" + reqEmpEmail + ", reqEmpTel=" + reqEmpTel + ", title=" + title + ", desc=" + desc + ", confDataYn=" + confDataYn
                + ", tgtDt=" + tgtDt + ", status=" + status + ", chrgEmpId=" + chrgEmpId + ", chrgEmpDeptId=" + chrgEmpDeptId + ", finalAprvDttm="
                + finalAprvDttm + ", closeDttm=" + closeDttm + ", etc1=" + etc1 + ", etc2=" + etc2 + ", etc3=" + etc3 + ", crtId=" + crtId + ", crtDttm="
                + crtDttm + ", lastModId=" + lastModId + ", lastModDttm=" + lastModDttm + "]";
    }



}
