package net.homeplus.offline.sr.proc.service;

import net.homeplus.offline.sr.proc.vo.SRDetailVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;

public interface SRProcService {

    public SRViewVO registSR(SRDetailVO vo);

    public SRViewVO cancelSR(SRDetailVO vo);

    public SRViewVO updateSR(SRDetailVO vo);

    // public SRListVO removeSRDetail(SRIDetailVO vo);
}
