/**
 * Smart Desk Javascript
 * Gwroup-Ware 연동
 */


/**
 * 화면이 로드 완료 되었을시
 */
window.onload = function () {	
	
	$("#frmGw").submit();
}

