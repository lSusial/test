package net.homeplus.offline.common.intercepter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.homeplus.offline.common.vo.UserVO;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class LoginIntercepter extends HandlerInterceptorAdapter {

    @Value("#{config['url.login']}")
    private String loginURL;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {


        HttpSession session = request.getSession();
        UserVO loginInfo = new UserVO();

        try {
            loginInfo = (UserVO) session.getAttribute("userInfo");
        } catch (Exception e) {
        }

        if (session == null || loginInfo == null) {
            
            response.sendRedirect("/login/login.do");
            return false;

            // UserVO userVO = new UserVO();
            // userVO.setUserId("test1@homeplus.co.kr");
            // userVO.setUserNm("홍길동1");
            // userVO.setDeptId("DEPT_001");
            // userVO.setDeptNm("부서1");
            // userVO.setEmail("test1@homeplus.co.kr");
            // session.setAttribute("userInfo", userVO);
        }

        // 틀림

        // TODO 앞에 로그인 할 수 있는 로직을 추가 하자

        /*
         * try { HttpSession session = request.getSession(false);
         * 
         * if (session == null) { response.sendRedirect(loginURL); return false; } else {
         * 
         * UserVO userInfo = (UserVO) session.getAttribute("userInfo"); if (userInfo != null &&
         * userInfo.getUserId() != null) {
         * 
         * } else { response.sendRedirect(loginURL); return false; } } result = true; } catch
         * (Exception e) { e.printStackTrace(); return false; }
         */
        return true;
    }


}
