package net.homeplus.offline.common.vo;

public class BaseVO {
    private String crtId;
    private String crtDttm;
    private String lastModId;
    private String lastModDttm;

    public String getCrtId() {
        return crtId;
    }

    public void setCrtId(String crtId) {
        this.crtId = crtId;
    }

    public String getCrtDttm() {
        return crtDttm;
    }

    public void setCrtDttm(String crtDttm) {
        this.crtDttm = crtDttm;
    }

    public String getLastModId() {
        return lastModId;
    }

    public void setLastModId(String lastModId) {
        this.lastModId = lastModId;
    }

    public String getLastModDttm() {
        return lastModDttm;
    }

    public void setLastModDttm(String lastModDttm) {
        this.lastModDttm = lastModDttm;
    }


}
