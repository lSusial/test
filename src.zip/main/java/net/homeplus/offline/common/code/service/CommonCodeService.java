package net.homeplus.offline.common.code.service;

import java.util.List;

import net.homeplus.offline.common.code.vo.CodeVO;

public interface CommonCodeService {
    public List<CodeVO> selectCommonCodeListByGroupId(String cdGrpId);

}
