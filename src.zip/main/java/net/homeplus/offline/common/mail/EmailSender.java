package net.homeplus.offline.common.mail;

import java.io.File;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;

@Component("EmailSender")
public class EmailSender {

    @Autowired
    private JavaMailSender javaMailSender;

    public boolean send() {
        boolean retVal = false;
        final String emailTo = "4susia@gmail.com";
        final String emailFrom = "testmail0826@gmail.com";
        final String subject = "test subject";
        final String message = "test";

        javaMailSender.send(new MimeMessagePreparator() {

            @Override
            public void prepare(MimeMessage paramMimeMessage) throws Exception {
                MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(paramMimeMessage, true, "UTF-8");

                mimeMessageHelper.setTo(emailTo);
                mimeMessageHelper.setFrom(emailFrom);
                mimeMessageHelper.setSubject(subject);
                mimeMessageHelper.setText(message);

                final File file = new File("test filename");

                /*
                 * mimeMessageHelper.addAttachment( MimeUtility.encodeText("filename"), new
                 * InputStreamSource() {
                 * 
                 * @Override public InputStream getInputStream() throws IOException { // TODO
                 * Auto-generated method stub return new FileInputStream(file); } });
                 */
            };
        });

        retVal = true;
        return retVal;
    }
}
