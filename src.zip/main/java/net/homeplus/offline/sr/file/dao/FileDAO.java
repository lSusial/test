package net.homeplus.offline.sr.file.dao;

import java.util.List;

import net.homeplus.offline.common.dao.CommonDAO;
import net.homeplus.offline.sr.file.vo.FileVO;

import org.springframework.stereotype.Repository;

@Repository("FileDAO")
public class FileDAO extends CommonDAO {

    public void registFile(FileVO saveFile) {
        getSqlSession().insert("File.registFile", saveFile);
    }

    public List<FileVO> selectFileListBySrId(String srId) {
        return getSqlSession().selectList("File.selectFileListBySrId", srId);
    }

    public FileVO selectFile(FileVO vo) {
        return getSqlSession().selectOne("File.selectFile", vo);
    }

}
