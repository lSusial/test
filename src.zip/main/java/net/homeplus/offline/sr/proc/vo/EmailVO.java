package net.homeplus.offline.sr.proc.vo;

import net.homeplus.offline.common.vo.BaseVO;

public class EmailVO extends BaseVO {

    private String srId;
    private String srNo;
    private String srTypeNm;
    private String sysNm;
    private String reqEmpNm;
    private String reqEmpId;
    private String reqEmpDeptNm;
    private String reqEmpEmail;
    private String title;
    private String desc;
    private String confDataYn;
    private String tgtDttm;
    private String status;

    private String resourceUrl;
    // TODO property로 빼야됨

    private String toAddress;

    public EmailVO() {
        this.resourceUrl = "http://nsr.homeplusnet.co.kr/resources/";
    }

    public String getSrId() {
        return srId;
    }

    public void setSrId(String srId) {
        this.srId = srId;
    }

    public String getSrNo() {
        return srNo;
    }

    public void setSrNo(String srNo) {
        this.srNo = srNo;
    }

    public String getSrTypeNm() {
        return srTypeNm;
    }

    public void setSrTypeNm(String srTypeNm) {
        this.srTypeNm = srTypeNm;
    }

    public String getSysNm() {
        return sysNm;
    }

    public void setSysNm(String sysNm) {
        this.sysNm = sysNm;
    }

    public String getReqEmpNm() {
        return reqEmpNm;
    }

    public void setReqEmpNm(String reqEmpNm) {
        this.reqEmpNm = reqEmpNm;
    }

    public String getReqEmpDeptNm() {
        return reqEmpDeptNm;
    }

    public void setReqEmpDeptNm(String reqEmpDeptNm) {
        this.reqEmpDeptNm = reqEmpDeptNm;
    }

    public String getReqEmpEmail() {
        return reqEmpEmail;
    }

    public void setReqEmpEmail(String reqEmpEmail) {
        this.reqEmpEmail = reqEmpEmail;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getConfDataYn() {
        return confDataYn;
    }

    public void setConfDataYn(String confDataYn) {
        this.confDataYn = confDataYn;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getToAddress() {
        return toAddress;
    }

    public void setToAddress(String toAddress) {
        this.toAddress = toAddress;
    }

    public String getTgtDttm() {
        return tgtDttm;
    }

    public void setTgtDttm(String tgtDttm) {
        this.tgtDttm = tgtDttm;
    }

    public String getResourceUrl() {
        return "http://nsr.homeplusnet.co.kr/resources/";
    }

    public String getReqEmpId() {
        return reqEmpId;
    }

    public void setReqEmpId(String reqEmpId) {
        this.reqEmpId = reqEmpId;
    }



}
