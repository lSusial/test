package net.homeplus.offline.sr.proc.service;

import net.homeplus.offline.sr.view.vo.SRViewVO;

public interface SRProcService {

    public String selectSRId();

    public SRViewVO registSR(SRViewVO vo);

    public SRViewVO cancelSR(SRViewVO vo);

    public SRViewVO updateSR(SRViewVO vo);

    public SRViewVO registSRTest();


    // public SRListVO removeSRDetail(SRIDetailVO vo);
}
