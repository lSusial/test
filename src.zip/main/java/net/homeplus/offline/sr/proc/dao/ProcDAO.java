package net.homeplus.offline.sr.proc.dao;

import org.springframework.stereotype.Repository;

import net.homeplus.offline.common.dao.CommonDAO;
import net.homeplus.offline.sr.view.vo.SRViewVO;

@Repository("ProcDAO")
public class ProcDAO extends CommonDAO {

    public void insertSRDetail(SRViewVO vo) {
        getSqlSession().insert("SRProc.insertSRDetail", vo);

    }

    public long selectSRSeq() {
        // TODO Auto-generated method stub
        return 0;
    }

    public SRViewVO insertTest(SRViewVO vo) {

        getSqlSession().insert("SRProc.test", vo);

        return null;
    }


}
