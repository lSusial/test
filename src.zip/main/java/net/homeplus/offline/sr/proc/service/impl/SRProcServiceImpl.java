package net.homeplus.offline.sr.proc.service.impl;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.homeplus.offline.sr.proc.dao.ProcDAO;
import net.homeplus.offline.sr.proc.service.SRProcService;
import net.homeplus.offline.sr.view.vo.SRViewVO;


@Service("SRProcService")
public class SRProcServiceImpl implements SRProcService {

    @Autowired
    private ProcDAO procDAO;

    @Override
    public String selectSRId() {

        long seq = procDAO.selectSRSeq();
        String srId = StringUtils.leftPad(Long.toString(seq), 11);
        return srId;
    }



    @Override
    public SRViewVO registSR(SRViewVO vo) {
        // TODO Auto-generated method stub

        // SR Deatil 저장

        procDAO.insertSRDetail(vo);

        // 결제 히스토리 정보 저장
        // TYPE에 따라서 결제요청 메일, 또는 RTC로 연계


        return null;
    }

    @Override
    public SRViewVO cancelSR(SRViewVO vo) {
        // TODO Auto-generated method stub

        // SR Deatil 업데이트
        // 결제 히스토리 업데이트
        // 해당 정보가 취소 되었다는 메일인데.. 보낸 주체가 어떻게 되냐

        return null;
    }

    @Override
    public SRViewVO updateSR(SRViewVO vo) {
        // 단순한 내용 또는 파일 추가.
        // 내용이 다른 경우에는 다시 하는게 맞음

        return null;
    }



    @Override
    public SRViewVO registSRTest() {
        SRViewVO vo = new SRViewVO();

        vo.setSrTypeId("TST001");
        vo.setReqSvcTp("adfadsf");
        procDAO.insertTest(vo);

        System.out.println("FUCKDDDDDDDDDDDDDDDDDDDDDDDDddddddddddddddddddddddddddddddd");
        System.out.println(vo);

        return null;
    }


}
