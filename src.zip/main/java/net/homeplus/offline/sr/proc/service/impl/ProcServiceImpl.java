package net.homeplus.offline.sr.proc.service.impl;

import java.util.List;

import net.homeplus.offline.common.constant.Constants;
import net.homeplus.offline.common.mail.EmailSender;
import net.homeplus.offline.sr.approval.dao.ApprovalDAO;
import net.homeplus.offline.sr.approval.vo.ApprovalHistVO;
import net.homeplus.offline.sr.proc.dao.ProcDAO;
import net.homeplus.offline.sr.proc.service.ProcService;
import net.homeplus.offline.sr.proc.vo.EmailVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("ProcService")
public class ProcServiceImpl implements ProcService {

    @Autowired
    private ProcDAO procDAO;
    @Autowired
    private ApprovalDAO approvalDAO;
    @Autowired
    private EmailSender emailSender;


    @Override
    public String selectSRId() {

        long seq = procDAO.selectSRSeq();
        String srId = StringUtils.leftPad(Long.toString(seq), 11, "0");
        return srId;
    }


    @Override
    public SRViewVO insertSR(SRViewVO vo) {

        vo.setStatus("APPROVING");

        procDAO.insertSRDetail(vo);

        // 파일 정보
        // 기안
        registRequesterInfoToAprvHist(vo);

        // 결재 라인
        registSRApprovalHist(vo);

        ApprovalHistVO nextApproval = selectNextApprovalInfo(vo.getSrId());

        if (nextApproval == null) {
            // save RTC OR save TICKET
            SRViewVO srDetail = new SRViewVO();
            srDetail.setSrId(vo.getSrId());
            srDetail.setStatus("WORKING");
            procDAO.updateSRStatus(srDetail);
        } else {
            sendApprovalEmail(nextApproval);

            nextApproval.setMailSendYn("Y");
            nextApproval.setAprvStatus(Constants.ApproveStatus.IN_PROGRESS);
            approvalDAO.updateApprovalHistStatus(nextApproval);
        }
        // 결제 히스토리 정보 저장

        return vo;
    }

    @Override
    public SRViewVO cancelSR(SRViewVO vo) {


        // 본인 확인 및 권한 확인
        // SR Deatil 업데이트
        // 결제 히스토리 업데이트
        // 해당 정보가 취소 되었다는 메일인데.. 보낸 주체가 어떻게 되냐

        vo.setStatus("CANCEL");
        procDAO.updateSRStatus(vo);
        return null;
    }

    @Override
    public SRViewVO updateSR(SRViewVO vo) {
        procDAO.updateSR(vo);

        return null;
    }



    private void registRequesterInfoToAprvHist(SRViewVO vo) {

        ApprovalHistVO reqInfo = new ApprovalHistVO();
        reqInfo.setSrId(vo.getSrId());
        reqInfo.setAprvEmpId(vo.getReqEmpId());
        reqInfo.setAprvDeptId(vo.getReqEmpDeptId());

        reqInfo.setAprvTpCd("DRAFT");
        reqInfo.setAprvStatus("COMPLETE");

        approvalDAO.insertAprovalHist(reqInfo);
    }


    private void sendApprovalEmail(ApprovalHistVO nextApproval) {
        EmailVO emailVO = procDAO.getSRDetailForEmail(nextApproval.getSrId());
        String toAddress = nextApproval.getAprvEmpId();

        if (!StringUtils.contains(toAddress, "@homeplus.co.kr")) {
            // TODO 플러스넷에서 이메일 정보를 받아와야 함
            emailVO.setToAddress(toAddress + "@homeplus.co.kr");
        } else {

        }

        emailVO.setStatus("APPROVING");
        try {
            emailSender.send(emailVO);
        } catch (Exception e) {
        }


    }

    private void sendRejectEmail(String srId) {
        EmailVO emailVO = procDAO.getSRDetailForEmail(srId);
        String toAddress = emailVO.getReqEmpId();

        if (!StringUtils.contains(toAddress, "@homeplus.co.kr")) {
            // TODO 플러스넷에서 이메일 정보를 받아와야 함
            emailVO.setToAddress(toAddress + "@homeplus.co.kr");
        } else {

        }
        emailVO.setStatus("REJECT");
        try {
            emailSender.send(emailVO);
        } catch (Exception e) {
        }


    }



    private void registSRApprovalHist(SRViewVO vo) {
        if (vo.getApprovalITListJson() != null && vo.getApprovalITListJson().length() > 10) {
            insertSRApprovalData(vo.getApprovalList(), vo.getSrId(), Constants.ApproveType.COMMON_DEPT);
            insertSRApprovalData(vo.getApprovalITList(), vo.getSrId(), Constants.ApproveType.IT_DEPT);
        }
    }

    private void insertSRApprovalData(List<ApprovalHistVO> list, String srId, String apprvTpCd) {

        for (ApprovalHistVO insertVO : list) {
            insertVO.setSrId(srId);
            insertVO.setAprvTpCd(apprvTpCd);
            insertVO.setAprvStatus(Constants.ApproveStatus.WAITING);
            insertVO.setMailSendYn("N");
            approvalDAO.insertAprovalHist(insertVO);
        }
    };


    private ApprovalHistVO selectNextApprovalInfo(String srId) {
        return approvalDAO.selectNextApprovalInfo(srId);
    }

    @Override
    public ApprovalHistVO approveSR(ApprovalHistVO vo) {
        approvalDAO.updateApprovalHistStatus(vo);
        ApprovalHistVO nextApproval = selectNextApprovalInfo(vo.getSrId());
        if (nextApproval == null) {
            SRViewVO srDetail = new SRViewVO();
            srDetail.setSrId(vo.getSrId());
            srDetail.setStatus("WORKING");
            procDAO.updateSRStatus(srDetail);
        } else {
            sendApprovalEmail(nextApproval);

            nextApproval.setMailSendYn("Y");
            nextApproval.setAprvStatus(Constants.ApproveStatus.IN_PROGRESS);
            approvalDAO.updateApprovalHistStatus(nextApproval);


        }
        return null;
    }

    @Override
    public ApprovalHistVO disapproveSR(ApprovalHistVO vo) {
        approvalDAO.updateApprovalHistStatus(vo);
        approvalDAO.rejectAllApprovalHist(vo);

        SRViewVO srDetail = new SRViewVO();
        srDetail.setSrId(vo.getSrId());
        srDetail.setStatus("REJECT");
        procDAO.updateSRStatus(srDetail);

        sendRejectEmail(vo.getSrId());

        return null;
    }

    @Override
    public void updateSystem(SRViewVO vo) {
        // SR Detail 업데이트

        procDAO.updateSR(vo);
        // approval hist 삭제


        approvalDAO.deleteITApprovalLine(vo);
        // aproval hist 등록

        approvalDAO.insertITApprovalLine(vo);

        ApprovalHistVO nextApproval = selectNextApprovalInfo(vo.getSrId());

        if (nextApproval == null) {
            // save RTC OR save TICKET
            SRViewVO srDetail = new SRViewVO();
            srDetail.setSrId(vo.getSrId());
            srDetail.setStatus("WORKING");
            procDAO.updateSRStatus(srDetail);
        } else {
            sendApprovalEmail(nextApproval);

            nextApproval.setMailSendYn("Y");
            nextApproval.setAprvStatus(Constants.ApproveStatus.IN_PROGRESS);
            approvalDAO.updateApprovalHistStatus(nextApproval);
        }

    }


}
