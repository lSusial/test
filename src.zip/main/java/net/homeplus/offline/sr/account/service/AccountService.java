package net.homeplus.offline.sr.account.service;

import java.util.List;

import net.homeplus.offline.common.vo.UserVO;

public interface AccountService {

    public UserVO selectUserInfo(String userId);

    public List<UserVO> selectAllUserInfo();



}
