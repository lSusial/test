package net.homeplus.offline.sr.view.vo;

public class TypeVO {

    private String srTypeId;
    private String srTypeNm;
    private String tgrTpCd;
    private String apprReqYn;
    private String useYn;

    public String getUseYn() {
        return useYn;
    }

    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }

    public String getSrTypeId() {
        return srTypeId;
    }

    public void setSrTypeId(String srTypeId) {
        this.srTypeId = srTypeId;
    }

    public String getSrTypeNm() {
        return srTypeNm;
    }

    public void setSrTypeNm(String srTypeNm) {
        this.srTypeNm = srTypeNm;
    }

    public String getApprReqYn() {
        return apprReqYn;
    }

    public void setApprReqYn(String apprReqYn) {
        this.apprReqYn = apprReqYn;
    }


    public String getTgrTpCd() {
        return tgrTpCd;
    }

    public void setTgrTpCd(String tgrTpCd) {
        this.tgrTpCd = tgrTpCd;
    }



}
