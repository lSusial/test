package net.homeplus.offline.sr.view.vo;

import java.util.Date;
import java.util.List;

import net.homeplus.offline.common.vo.BaseVO;
import net.homeplus.offline.sr.approval.vo.ApprovalHistVO;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

public class SRViewVO extends BaseVO {

    private String srId;
    private String srNo;
    private String srTypeId;
    private String srTypeNm;
    private String sysId;
    private String sysNm;
    private String reqSvcTp;
    private String reqEmpId;
    private String reqEmpNm;
    private String reqEmpDeptId;
    private String reqEmpDeptNm;
    private String reqEmpEmail;
    private String reqEmpTel;
    private String title;
    private String desc;
    private String confDataYn;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date tgtDttm;
    private String status;
    private String statusNm;
    private String chrgEmpId;
    private String chrgEmpNm;
    private String chrgEmpDeptId;

    private Date finalAprvDttm;
    private Date closeDttm;
    private String etc1;
    private String etc2;

    private String dataType;

    private String modId;
    private String modNm;
    private String ifType;
    private String sysCateId;
    private String sysCateNm;

    private String resultDesc;

    private String userId;


    public String getModNm() {
        return modNm;
    }

    public void setModNm(String modNm) {
        this.modNm = modNm;
    }

    public String getSysCateNm() {
        return sysCateNm;
    }

    public void setSysCateNm(String sysCateNm) {
        this.sysCateNm = sysCateNm;
    }

    private String approvalListJson;
    private String approvalITListJson;

    private List<ApprovalHistVO> approvalList;
    private List<ApprovalHistVO> approvalITList;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date strDttm;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date endDttm;

    private String crtDt;
    private String tgtDt;
    private String closeDt;

    private List<MultipartFile> files;

    public void setFiles(List<MultipartFile> files) {
        this.files = files;
    }

    public List<MultipartFile> getFiles() {
        return files;
    }

    public String getSrId() {
        return srId;
    }

    public void setSrId(String srId) {
        this.srId = srId;
    }

    public String getSrTypeId() {
        return srTypeId;
    }

    public void setSrTypeId(String srTypeId) {
        this.srTypeId = srTypeId;
    }

    public String getSysId() {
        return sysId;
    }

    public void setSysId(String sysId) {
        this.sysId = sysId;
    }

    public String getReqSvcTp() {
        return reqSvcTp;
    }

    public void setReqSvcTp(String reqSvcTp) {
        this.reqSvcTp = reqSvcTp;
    }

    public String getReqEmpId() {
        return reqEmpId;
    }

    public void setReqEmpId(String reqEmpId) {
        this.reqEmpId = reqEmpId;
    }

    public String getReqEmpDeptId() {
        return reqEmpDeptId;
    }

    public void setReqEmpDeptId(String reqEmpDeptId) {
        this.reqEmpDeptId = reqEmpDeptId;
    }

    public String getReqEmpEmail() {
        return reqEmpEmail;
    }

    public void setReqEmpEmail(String reqEmpEmail) {
        this.reqEmpEmail = reqEmpEmail;
    }

    public String getReqEmpTel() {
        return reqEmpTel;
    }

    public void setReqEmpTel(String reqEmpTel) {
        this.reqEmpTel = reqEmpTel;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getConfDataYn() {
        return confDataYn;
    }

    public void setConfDataYn(String confDataYn) {
        this.confDataYn = confDataYn;
    }


    public Date getTgtDttm() {
        return tgtDttm;
    }

    public void setTgtDttm(Date tgtDttm) {
        this.tgtDttm = tgtDttm;
    }

    public Date getStrDttm() {
        return strDttm;
    }

    public void setStrDttm(Date strDttm) {
        this.strDttm = strDttm;
    }

    public Date getEndDttm() {
        return endDttm;
    }

    public void setEndDttm(Date endDttm) {
        this.endDttm = endDttm;
    }

    public String getCrtDt() {
        return crtDt;
    }

    public void setCrtDt(String crtDt) {
        this.crtDt = crtDt;
    }

    public String getTgtDt() {
        return tgtDt;
    }

    public void setTgtDt(String tgtDt) {
        this.tgtDt = tgtDt;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getChrgEmpId() {
        return chrgEmpId;
    }

    public void setChrgEmpId(String chrgEmpId) {
        this.chrgEmpId = chrgEmpId;
    }

    public String getChrgEmpDeptId() {
        return chrgEmpDeptId;
    }

    public void setChrgEmpDeptId(String chrgEmpDeptId) {
        this.chrgEmpDeptId = chrgEmpDeptId;
    }

    public Date getFinalAprvDttm() {
        return finalAprvDttm;
    }

    public void setFinalAprvDttm(Date finalAprvDttm) {
        this.finalAprvDttm = finalAprvDttm;
    }

    public Date getCloseDttm() {
        return closeDttm;
    }

    public void setCloseDttm(Date closeDttm) {
        this.closeDttm = closeDttm;
    }

    public String getEtc1() {
        return etc1;
    }

    public void setEtc1(String etc1) {
        this.etc1 = etc1;
    }

    public String getEtc2() {
        return etc2;
    }

    public void setEtc2(String etc2) {
        this.etc2 = etc2;
    }

    public String getApprovalListJson() {
        return approvalListJson;
    }

    public void setApprovalListJson(String approvalListJson) {
        this.approvalListJson = approvalListJson;
    }

    public String getApprovalITListJson() {
        return approvalITListJson;
    }

    public void setApprovalITListJson(String approvalITListJson) {
        this.approvalITListJson = approvalITListJson;
    }

    public List<ApprovalHistVO> getApprovalList() {
        return approvalList;
    }

    public void setApprovalList(List<ApprovalHistVO> approvalList) {
        this.approvalList = approvalList;
    }

    public List<ApprovalHistVO> getApprovalITList() {
        return approvalITList;
    }

    public void setApprovalITList(List<ApprovalHistVO> approvalITList) {
        this.approvalITList = approvalITList;
    }

    public String getReqEmpDeptNm() {
        return reqEmpDeptNm;
    }

    public void setReqEmpDeptNm(String reqEmpDeptNm) {
        this.reqEmpDeptNm = reqEmpDeptNm;
    }

    public String getReqEmpNm() {
        return reqEmpNm;
    }

    public void setReqEmpNm(String reqEmpNm) {
        this.reqEmpNm = reqEmpNm;
    }

    public String getSrNo() {
        return srNo;
    }

    public void setSrNo(String srNo) {
        this.srNo = srNo;
    }

    public String getSysNm() {
        return sysNm;
    }

    public void setSysNm(String sysNm) {
        this.sysNm = sysNm;
    }

    public String getDataType() {
        return dataType;
    }

    public void setDataType(String dataType) {
        this.dataType = dataType;
    }

    public String getModId() {
        return modId;
    }

    public void setModId(String modId) {
        this.modId = modId;
    }

    public String getIfType() {
        return ifType;
    }

    public void setIfType(String ifType) {
        this.ifType = ifType;
    }

    public String getSysCateId() {
        return sysCateId;
    }

    public void setSysCateId(String sysCateId) {
        this.sysCateId = sysCateId;
    }

    public String getChrgEmpNm() {
        return chrgEmpNm;
    }

    public void setChrgEmpNm(String chrgEmpNm) {
        this.chrgEmpNm = chrgEmpNm;
    }

    public String getSrTypeNm() {
        return srTypeNm;
    }

    public void setSrTypeNm(String srTypeNm) {
        this.srTypeNm = srTypeNm;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getStatusNm() {
        return statusNm;
    }

    public void setStatusNm(String statusNm) {
        this.statusNm = statusNm;
    }

    public String getResultDesc() {
        return resultDesc;
    }

    public void setResultDesc(String resultDesc) {
        this.resultDesc = resultDesc;
    }

    public String getCloseDt() {
        return closeDt;
    }

    public void setCloseDt(String closeDt) {
        this.closeDt = closeDt;
    }

}
