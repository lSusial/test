package net.homeplus.offline.sr.view.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.homeplus.offline.common.vo.UserVO;
import net.homeplus.offline.sr.view.dao.ViewDAO;
import net.homeplus.offline.sr.view.service.ViewService;
import net.homeplus.offline.sr.view.vo.SRViewVO;
import net.homeplus.offline.sr.view.vo.SystemVO;
import net.homeplus.offline.sr.view.vo.TypeVO;


@Service("ViewService")
public class SRViewServiceImpl implements ViewService {


    @Autowired
    private ViewDAO viewDAO;

    @Override
    public List<SRViewVO> selectSRList() {
        return null;
    }

    @Override
    public Map<String, Object> selectSRDetail() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<TypeVO> selectTypeList(String type) {
        return viewDAO.selectSRTypeList(type);
    }

    @Override
    public List<SystemVO> selectSystemList(String type) {
        return viewDAO.selectSystemList(type);
    }

    @Override
    public List<UserVO> selectEmpList(String searchWord) {
        
        return viewDAO.selectEmpList(searchWord);
    }



}
