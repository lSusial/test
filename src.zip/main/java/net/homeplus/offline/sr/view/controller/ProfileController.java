package net.homeplus.offline.sr.view.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import net.homeplus.offline.common.vo.UserVO;
import net.homeplus.offline.sr.approval.service.ApprovalService;
import net.homeplus.offline.sr.approval.vo.AlternativeVO;
import net.homeplus.offline.sr.approval.vo.IndividualApprovalLineVO;
import net.homeplus.offline.sr.file.service.FileService;
import net.homeplus.offline.sr.file.vo.FileVO;
import net.homeplus.offline.sr.view.service.ViewService;

import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class ProfileController {

    @Autowired
    private ViewService viewService;
    @Autowired
    private ApprovalService approvalService;

    @Autowired
    private FileService fileService;

    @RequestMapping(value = "/sr/profile.do", method = RequestMethod.GET)
    public ModelAndView registView(HttpServletRequest request, ModelAndView mav) {

        HttpSession session = request.getSession(false);
        UserVO loginInfo = (UserVO) session.getAttribute("userInfo");

        AlternativeVO alternative = approvalService.selectAlternative(loginInfo.getUserId());
        List<IndividualApprovalLineVO> approvalLine = approvalService.selectIndividualApprovalLine(loginInfo.getUserId());

        mav.addObject("alternative", alternative);
        mav.addObject("approvalLine", approvalLine);

        mav.setViewName("sr/profile");

        return mav;
    }


    @RequestMapping(value = "/profile/setAlternative.do")
    public @ResponseBody String setAlternative(HttpServletRequest request, @RequestParam(defaultValue = "") String alterEmpId) {

        String result = "success";

        HttpSession session = request.getSession(false);
        UserVO loginInfo = (UserVO) session.getAttribute("userInfo");

        AlternativeVO alterVO = new AlternativeVO();
        alterVO.setUserId(loginInfo.getUserId());
        alterVO.setAlterEmpId(alterEmpId);
        approvalService.updateAlternative(alterVO);

        return result;
    }

    @RequestMapping(value = "/profile/registApprovalLine.do")
    public @ResponseBody String registApprovalLine(HttpServletRequest request) throws Exception{

        HttpSession session = request.getSession(false);
        UserVO loginInfo = (UserVO) session.getAttribute("userInfo");


        String jsonValue = request.getParameter("list");
        ObjectMapper mapper = new ObjectMapper();
        List<IndividualApprovalLineVO> approvalITList = mapper.readValue(jsonValue, new TypeReference<List<IndividualApprovalLineVO>>() {});
        
        approvalService.updateIndividualApprovalLine(approvalITList, loginInfo.getUserId());

        String result = "success";

        return result;
    }


    @RequestMapping(value = "/json/getPDSFileList.json")
    @ResponseBody
    public List<FileVO> selecdPDSFileList() {
        List<FileVO> fileList = fileService.selectPDSFileList();
        return fileList;

    }

    @RequestMapping(value = "/test/temp.do")
    public String temp() {
        return "test/temp";

    }


}
