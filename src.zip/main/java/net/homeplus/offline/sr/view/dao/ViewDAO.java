package net.homeplus.offline.sr.view.dao;

import java.util.List;

import net.homeplus.offline.common.dao.CommonDAO;
import net.homeplus.offline.common.vo.UserVO;
import net.homeplus.offline.sr.view.vo.ModuleVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;
import net.homeplus.offline.sr.view.vo.SystemVO;
import net.homeplus.offline.sr.view.vo.TypeVO;

import org.springframework.stereotype.Repository;

@Repository("ViewDAO")
public class ViewDAO extends CommonDAO {

    public List<SRViewVO> test() {
        return null;
        // return getSqlSession().selectList("CommonCode.selectCommonCodecListByGrpId");

    }

    public List<TypeVO> selectSRTypeList(String type) {
        return getSqlSession().selectList("SRView.selectTypeList", type);
    }

    public List<SystemVO> selectSystemList(String type) {
        return getSqlSession().selectList("SRView.selectSystemList", type);
    }

    public List<UserVO> selectEmpList(String searchWord) {
        return getSqlSession().selectList("SRView.selectEmpList", searchWord);
    }

    public SRViewVO selectSRDetail(String srNo) {
        return getSqlSession().selectOne("SRView.selectSRDetail", srNo);
    }

    public List<SRViewVO> selectSRList(SRViewVO vo) {
        return getSqlSession().selectList("SRView.selectSRList", vo);
    }

    public List<ModuleVO> selectModuleList(String sysId) {
        return getSqlSession().selectList("SRView.selectModuleList", sysId);
    }

    public List<SystemVO> selectSystemListByCate(String sysCateId) {
        return getSqlSession().selectList("SRView.selectSystemListByCate", sysCateId);
    }


}
