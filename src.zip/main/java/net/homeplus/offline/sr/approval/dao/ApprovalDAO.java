package net.homeplus.offline.sr.approval.dao;

import java.util.List;

import net.homeplus.offline.common.dao.CommonDAO;
import net.homeplus.offline.sr.approval.vo.ApprovalRuleVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;

import org.springframework.stereotype.Repository;

@Repository("ApprovalDAO")
public class ApprovalDAO extends CommonDAO {

    public List<SRViewVO> test() {

        return null;
        /*return getSqlSession().selectList("CommonCode.selectCommonCodecListByGrpId");*/

    }

    public List<ApprovalRuleVO> selectSRApprovalRule(ApprovalRuleVO vo) {
        System.out.println("ddddddddddddd" + vo);
        return getSqlSession().selectList("Approval.selectSRApprovalRule", vo);
    }


}
