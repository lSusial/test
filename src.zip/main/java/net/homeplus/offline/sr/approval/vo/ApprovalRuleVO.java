package net.homeplus.offline.sr.approval.vo;

public class ApprovalRuleVO {

    private String aprvRuleId;
    private String aprvRuleSeq;
    private String srTypeId;
    private String sysId;
    private String aprvType;
    private String aprvDeptId;
    private String aprvDeptNm;
    private String aprvEmpId;
    private String aprvEmpNm;
    private String aprvEmpEmail;
    private String aprvEmpJobTitle;
    private String aprvDesc;
    private String useYn;
    private String crtId;
    private String crtDttm;
    private String lastModId;
    private String lastModDttm;

    public String getAprvDeptNm() {
        return aprvDeptNm;
    }

    public void setAprvDeptNm(String aprvDeptNm) {
        this.aprvDeptNm = aprvDeptNm;
    }

    public String getAprvEmpNm() {
        return aprvEmpNm;
    }

    public void setAprvEmpNm(String aprvEmpNm) {
        this.aprvEmpNm = aprvEmpNm;
    }

    public String getAprvEmpEmail() {
        return aprvEmpEmail;
    }

    public void setAprvEmpEmail(String aprvEmpEmail) {
        this.aprvEmpEmail = aprvEmpEmail;
    }

    public String getAprvRuleId() {
        return aprvRuleId;
    }

    public void setAprvRuleId(String aprvRuleId) {
        this.aprvRuleId = aprvRuleId;
    }

    public String getAprvRuleSeq() {
        return aprvRuleSeq;
    }

    public void setAprvRuleSeq(String aprvRuleSeq) {
        this.aprvRuleSeq = aprvRuleSeq;
    }

    public String getSrTypeId() {
        return srTypeId;
    }

    public void setSrTypeId(String srTypeId) {
        this.srTypeId = srTypeId;
    }

    public String getSysId() {
        return sysId;
    }

    public void setSysId(String sysId) {
        this.sysId = sysId;
    }

    public String getAprvType() {
        return aprvType;
    }

    public void setAprvType(String aprvType) {
        this.aprvType = aprvType;
    }

    public String getAprvDeptId() {
        return aprvDeptId;
    }

    public void setAprvDeptId(String aprvDeptId) {
        this.aprvDeptId = aprvDeptId;
    }

    public String getAprvEmpId() {
        return aprvEmpId;
    }

    public void setAprvEmpId(String aprvEmpId) {
        this.aprvEmpId = aprvEmpId;
    }

    public String getAprvDesc() {
        return aprvDesc;
    }

    public void setAprvDesc(String aprvDesc) {
        this.aprvDesc = aprvDesc;
    }

    public String getUseYn() {
        return useYn;
    }

    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }

    public String getCrtId() {
        return crtId;
    }

    public void setCrtId(String crtId) {
        this.crtId = crtId;
    }

    public String getCrtDttm() {
        return crtDttm;
    }

    public void setCrtDttm(String crtDttm) {
        this.crtDttm = crtDttm;
    }

    public String getLastModId() {
        return lastModId;
    }

    public void setLastModId(String lastModId) {
        this.lastModId = lastModId;
    }

    public String getLastModDttm() {
        return lastModDttm;
    }

    public void setLastModDttm(String lastModDttm) {
        this.lastModDttm = lastModDttm;
    }

    @Override
    public String toString() {
        return "ApprovalRuleVO [aprvRuleId=" + aprvRuleId + ", aprvRuleSeq=" + aprvRuleSeq + ", srTypeId=" + srTypeId + ", sysId=" + sysId + ", aprvType="
                + aprvType + ", aprvDeptId=" + aprvDeptId + ", aprvEmpId=" + aprvEmpId + ", aprvDesc=" + aprvDesc + ", useYn=" + useYn + ", crtId=" + crtId
                + ", crtDttm=" + crtDttm + ", lastModId=" + lastModId + ", lastModDttm=" + lastModDttm + "]";
    }

    public String getAprvEmpJobTitle() {
        return aprvEmpJobTitle;
    }

    public void setAprvEmpJobTitle(String aprvEmpJobTitle) {
        this.aprvEmpJobTitle = aprvEmpJobTitle;
    }



}
