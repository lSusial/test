package net.homeplus.offline.sr.approval.vo;

import java.util.Date;


public class ApprovalHistVO {

    private String srId;
    private String aprvSeq;
    private String aprvTpCd;
    private String aprvDeptId;
    private String aprvDeptNm;
    private String aprvEmpId;
    private String aprvEmpNm;
    private String aprvEmpJobTitle;
    private String aprvStatus;
    private String aprvStatusNm;
    private String mailSendYn;
    private Date aprvDttm;
    private String aprvDt;
    private String aprvCnts;
    private String orgAprvEmpId;


    private String chrgEmpId;
    private String modId;

    public String getChrgEmpId() {
        return chrgEmpId;
    }

    public void setChrgEmpId(String chrgEmpId) {
        this.chrgEmpId = chrgEmpId;
    }

    public String getModId() {
        return modId;
    }

    public void setModId(String modId) {
        this.modId = modId;
    }
    public String getSrId() {
        return srId;
    }
    public void setSrId(String srId) {
        this.srId = srId;
    }
    public String getAprvSeq() {
        return aprvSeq;
    }
    public void setAprvSeq(String aprvSeq) {
        this.aprvSeq = aprvSeq;
    }
    public String getAprvTpCd() {
        return aprvTpCd;
    }
    public void setAprvTpCd(String aprvTpCd) {
        this.aprvTpCd = aprvTpCd;
    }
    public String getAprvDeptId() {
        return aprvDeptId;
    }
    public void setAprvDeptId(String aprvDeptId) {
        this.aprvDeptId = aprvDeptId;
    }
    public String getAprvEmpId() {
        return aprvEmpId;
    }
    public void setAprvEmpId(String aprvEmpId) {
        this.aprvEmpId = aprvEmpId;
    }
    public String getAprvStatus() {
        return aprvStatus;
    }
    public void setAprvStatus(String aprvStatus) {
        this.aprvStatus = aprvStatus;
    }
    public String getMailSendYn() {
        return mailSendYn;
    }
    public void setMailSendYn(String mailSendYn) {
        this.mailSendYn = mailSendYn;
    }

    public String getAprvCnts() {
        return aprvCnts;
    }

    public void setAprvCnts(String aprvCnts) {
        this.aprvCnts = aprvCnts;
    }

    public String getAprvDeptNm() {
        return aprvDeptNm;
    }

    public void setAprvDeptNm(String aprvDeptNm) {
        this.aprvDeptNm = aprvDeptNm;
    }

    public String getAprvEmpNm() {
        return aprvEmpNm;
    }

    public void setAprvEmpNm(String aprvEmpNm) {
        this.aprvEmpNm = aprvEmpNm;
    }

    public String getOrgAprvEmpId() {
        return orgAprvEmpId;
    }

    public void setOrgAprvEmpId(String orgAprvEmpId) {
        this.orgAprvEmpId = orgAprvEmpId;
    }

    public String getAprvEmpJobTitle() {
        return aprvEmpJobTitle;
    }

    public void setAprvEmpJobTitle(String aprvEmpJobTitle) {
        this.aprvEmpJobTitle = aprvEmpJobTitle;
    }

    public String getAprvStatusNm() {
        return aprvStatusNm;
    }

    public void setAprvStatusNm(String aprvStatusNm) {
        this.aprvStatusNm = aprvStatusNm;
    }

    public String getAprvDt() {
        return aprvDt;
    }

    public void setAprvDt(String aprvDt) {
        this.aprvDt = aprvDt;
    }

    public Date getAprvDttm() {
        return aprvDttm;
    }

    public void setAprvDttm(Date aprvDttm) {
        this.aprvDttm = aprvDttm;
    }


}
