package net.homeplus.offline.sr.approval.vo;

import net.homeplus.offline.common.vo.BaseVO;

public class ApprovalHistVO extends BaseVO {

    private String srId;
    private String aprvSeq;
    private String aprvTpCd;
    private String aprvDeptId;
    private String aprvEmpId;
    private String aprvStatus;
    private String mailSendYn;


    public String getSrId() {
        return srId;
    }

    public void setSrId(String srId) {
        this.srId = srId;
    }

    public String getAprvSeq() {
        return aprvSeq;
    }

    public void setAprvSeq(String aprvSeq) {
        this.aprvSeq = aprvSeq;
    }

    public String getAprvTpCd() {
        return aprvTpCd;
    }

    public void setAprvTpCd(String aprvTpCd) {
        this.aprvTpCd = aprvTpCd;
    }
    public String getAprvDeptId() {
        return aprvDeptId;
    }
    public void setAprvDeptId(String aprvDeptId) {
        this.aprvDeptId = aprvDeptId;
    }
    public String getAprvEmpId() {
        return aprvEmpId;
    }
    public void setAprvEmpId(String aprvEmpId) {
        this.aprvEmpId = aprvEmpId;
    }
    public String getAprvStatus() {
        return aprvStatus;
    }
    public void setAprvStatus(String aprvStatus) {
        this.aprvStatus = aprvStatus;
    }
    public String getMailSendYn() {
        return mailSendYn;
    }
    public void setMailSendYn(String mailSendYn) {
        this.mailSendYn = mailSendYn;
    }


}
