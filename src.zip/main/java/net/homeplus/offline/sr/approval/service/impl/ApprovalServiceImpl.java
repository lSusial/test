package net.homeplus.offline.sr.approval.service.impl;

import java.util.List;

import net.homeplus.offline.common.util.CommonUtil;
import net.homeplus.offline.sr.approval.dao.ApprovalDAO;
import net.homeplus.offline.sr.approval.service.ApprovalService;
import net.homeplus.offline.sr.approval.vo.AlternativeVO;
import net.homeplus.offline.sr.approval.vo.ApprovalHistVO;
import net.homeplus.offline.sr.approval.vo.ApprovalRuleVO;
import net.homeplus.offline.sr.approval.vo.IndividualApprovalLineVO;
import net.homeplus.offline.sr.proc.vo.SRDetailVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("ApprovalService")
public class ApprovalServiceImpl implements ApprovalService {

    @Autowired
    private ApprovalDAO approvalDAO;


    @Override
    public SRViewVO approveSR(SRDetailVO vo) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public SRViewVO rejectSR(SRDetailVO vo) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<ApprovalHistVO> selectSRApprovalHistListBySRId(String srId) {
        List<ApprovalHistVO> approvalHist = approvalDAO.selectSRApprovalHistListBySRId(srId);
        for (ApprovalHistVO histVO : approvalHist) {
            histVO.setAprvDt(CommonUtil.dateToStr(histVO.getAprvDttm()));
        }
        return approvalHist;

    }

    @Override
    public List<ApprovalRuleVO> selectSRApprovalRule(ApprovalRuleVO vo) {
        return approvalDAO.selectSRApprovalRule(vo);
    }

    @Override
    public ApprovalHistVO approveSR(ApprovalHistVO vo) {
        updateApprovalHist(vo);
        return null;
    }

    @Override
    public ApprovalHistVO disapproveSR(ApprovalHistVO vo) {
        updateApprovalHist(vo);

        return null;
    }

    private void updateApprovalHist(ApprovalHistVO vo) {
        approvalDAO.updateApprovalHistStatus(vo);
    }

    @Override
    public void updateAlternative(AlternativeVO alterVO) {

        approvalDAO.deleteAlternative(alterVO);
        approvalDAO.restoreApprovalHistToOrgin(alterVO);

        if (StringUtils.isNotEmpty(alterVO.getAlterEmpId())) {
            approvalDAO.insertAlternative(alterVO);
            approvalDAO.updateApprovalHistToAlternative(alterVO);
        }
    }

    @Override
    public AlternativeVO selectAlternative(String userId) {
        return approvalDAO.selectAlternative(userId);
    }

    @Override
    public List<IndividualApprovalLineVO> selectIndividualApprovalLine(String userId) {
        return approvalDAO.selectIndividualApprovalLine(userId);
    }

    @Override
    public int updateIndividualApprovalLine(List<IndividualApprovalLineVO> list, String userId) {

        approvalDAO.deleteIndividualApprovalLine(userId);
        for (IndividualApprovalLineVO vo : list) {
            vo.setUserId(userId);
            approvalDAO.insertIndividualApprovalLine(vo);
        }
        return 0;
    }


}
