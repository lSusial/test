/**
 * Smart Desk Javascript
 */

/****************************************
 * 페이지 로딩 시 onload 함수 호출
 ****************************************/
window.onload = function () {
	// ID에 자동으로 포커스
	$("#inId").focus();
}

$(document).ready(function(){
    $("#logIn").click(function(){
    	loginInfoEncrypt();
    	$("#logInFrm").submit();
    });
});


function loginInfoEncrypt(){

	// Login 정보 암호화
	var encId=EncryptData($("#inId").val());
	var encPw=EncryptData($("#inPass").val());
	  
	//URL encoding
	var urlId=encodeURI(encId);	
	var urlPw=encodeURI(encPw);
	$("#wkId").val(urlId);
	$("#wkPassword").val(urlPw);
}

//암호화
function EncryptData(theText){ 
	
	output = new String; 
	Temp = new Array(); 
	Temp2 = new Array(); 
	TextSize = theText.length; 

	for (i = 0; i < TextSize; i++) {  
		rnd = Math.round(Math.random() * 122) + 68;  
		Temp[i] = theText.charCodeAt(i) + rnd;  
		Temp2[i] = rnd; 
	} 

	for (i = 0; i < TextSize; i++) {  
		output += String.fromCharCode(Temp[i], Temp2[i]); 
	} 
            
	return output;
 }
 
 
//url 인코딩
function encodeURL(str) {
	var s0, i, s, u;
	s0 = ""; // encoded str
	for (i = 0; i < str.length; i++) { // scan the source
		s = str.charAt(i);

		u = str.charCodeAt(i); // get unicode of the char
		if (s == " ") {
			s0 += "+";
		} // SP should be converted to "+"
		else {
			if (u == 0x2a || u == 0x2d || u == 0x2e || u == 0x5f
					|| ((u >= 0x30) && (u <= 0x39))
					|| ((u >= 0x41) && (u <= 0x5a))
					|| ((u >= 0x61) && (u <= 0x7a))) { // check for escape
				s0 = s0 + s; // don't escape
			} else { // escape
				if ((u >= 0x0) && (u <= 0x7f)) { // single byte format
					s = "0" + u.toString(16);
					s0 += "%" + s.substr(s.length - 2);
				} else if (u > 0x1fffff) { // quaternary byte format (extended)
					s0 += "%"
							+ (0xf0 + ((u & 0x1c0000) >> 18)).toString(16);
					s0 += "%" + (0x80 + ((u & 0x3f000) >> 12)).toString(16);
					s0 += "%" + (0x80 + ((u & 0xfc0) >> 6)).toString(16);
					s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
				} else if (u > 0x7ff) { // triple byte format
					s0 += "%" + (0xe0 + ((u & 0xf000) >> 12)).toString(16);
					s0 += "%" + (0x80 + ((u & 0xfc0) >> 6)).toString(16);
					s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
				} else { // double byte format
					s0 += "%" + (0xc0 + ((u & 0x7c0) >> 6)).toString(16);
					s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
				}
			}
		}
	}
	return s0;
}

// 탭키 또는 엔터키 입력시
function fnInputEnterKey(event) {
    event = event || window.event;
    var keyID = (event.which) ? event.which : event.keyCode;

    // 엔터키
    if( keyID == 13 )
    {
        loginInfoEncrypt();
		$("#logInFrm").submit();
    }
}
