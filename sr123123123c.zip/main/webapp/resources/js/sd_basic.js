/**
 * Smart Desk Javascript
 */

/****************************************
 * 글로벌 변수 선언
 ****************************************/
var G_INTERVAL_TIME = 1830000; // 30분 30초

/**
 * Debugger Process
 * Browser에서 사용하는 로깅 용도
 */
var Debugger = function(){};
Debugger.log = function(message){
	try{
		console.log(message);
	}catch(exception){
		return;
	}
}

/**
 * 입력된 문자열을 브라우저 콘솔에 출력
 * @param str
 */
function trace(str){
	Debugger.log(str);
}


/**
 * Edit Input 체크
 */
function fnCheckInput(event) {
    event = event || window.event;
    var keyID = (event.which) ? event.which : event.keyCode;
    var eventObject = (event.target) ? event.target:event.srcElement;
    
    // 입력가능한 특수문자
    // 8=Backspace, 35=End, 36=Home, 45=Insert, 46=Delete, 37=왼쪽 화살표, 38=위 화살표, 39=오른쪽 화살표, 40=아래 화살표
    if(keyID == 8 || keyID == 35 || keyID == 36 || keyID == 45 || keyID == 46 || ( keyID >=37 && keyID <= 40 ) ||
    		// 16=Shift, 20=CapsLock, 27=ESC, 9=다음 컴포넌트 선택(Tab), 116=F5(새로고침)
    		keyID == 16 || keyID == 20 || keyID == 27 || keyID == 9 || keyID == 116 )
    {
    	return true;
    }
    
    // 메일
    if(eventObject.id == "reqEmail"){
    	if(fnInputDash(keyID) || fnInputDot(keyID) || fnInputNumber(keyID) || fnInputLower(keyID) || fnInputUpper(keyID)) return true;
    	else return false;
    }
    
    // 전화, 완료희망일, 등록일From, 등록일To
    if(eventObject.id == "reqTelno" || eventObject.id == "reqTgtDate" || eventObject.id == "entDate" ){
    	if( fnInputDash(keyID) || fnInputNumber(keyID)) return true;
    	else return false;
    }
    
    // 요청번호
    if(eventObject.id == "sdId"){
    	if( fnInputNumber(keyID) || fnInputUpper(keyID)) return true;
    	else return false;
    }
    
    // 로그인 ID
    if(eventObject.id == "inId"){
    	if(fnInputLower(keyID) || fnInputUpper(keyID) || fnInputNumber(keyID) || fnInputDash(keyID)) return true;
    	else return false;
    }
}


/**
 * Input 체크 개별함수
 */
function fnInputDash(keyID){
	// 189=날짜 입력을 위한 특수문자(-)
	if( keyID == 189 ){
		return true;
	}
	else{
		return false;
	}
}

function fnInputDot(keyID){
	// 190=E-mail 입력시(.)
	if( keyID == 190 ){
		return true;
	}
	else{
		return false;
	}
}

function fnInputNumber(keyID){
	// 48~57은 일반 숫자키 0~, 96~105는 키보드의 숫자키패드의 숫자키 코드
	if( ( keyID >=48 && keyID <= 57 ) || ( keyID >=96 && keyID <= 105 ) )
	{
		return true;
	}
	else{
		return false;
	}
}

function fnInputLower(keyID){
	// 영어 소문자
	if( ( keyID >=97 && keyID <= 122 ) )
	{
		return true;
	}
	else{
		return false;
	}
}

function fnInputUpper(keyID){
	// 영어 대문자
	if( ( keyID >=65 && keyID <= 90 ) )
	{
		return true;
	}
	else{
		return false;
	}
}

/**
 * Javascript HashMap
 */
var HashMap = function(){
	var mapVal = {};		
	var pos = new Array();
	
	// Data get by key
	this.get = function(key){
		return mapVal[key];
	}
	
	// Data get by index
	this.getPos = function(n){
		return mapVal[pos[n]];
	}
	
	this.remove = function(n){
		var ary = new Array();
		
		for(var i=0; i<map.size(); i++){
			if(i != n){
				ary.push(pos[i]);
			}
		}
		pos = ary;
	}
	
	this.put = function(key, val){
		mapVal[key] = val;
		var flg = true;
		
		for(var i=0; i<pos.length; i++){
			if(key == pos[i]){
				flg = false;
			}
		}
		if(flg){
			pos.push(key);
		}
	}
	
	this.size = function(){
		return pos.length;
	}
}

/**
 * Javascript IsNull
 */
function isNull(obj){
	return (typeof obj != "undefined" && obj != null && obj != "" && obj != "null") ? false : true;
}

/**
 * Javascript 날짜 계산하기 (과거는 - )
 */
function getCalcDate(nextDateInt, standardDate){

	var oneDate = 1000 * 3600 * 24;	// 하루

	var nowDate;
	if( standardDate == undefined )				nowDate = new Date();
	else if( standardDate.getTime != undefined )	nowDate = standardDate;
	else if( standardDate.length == 8 )				nowDate = new Date(standardDate.substring(0, 4), parseInt(standardDate.substring(4, 6))-1, standardDate.substring(6, 8));
	
	return new Date(nowDate.getTime() + (oneDate * nextDateInt)).format("yyyy-MM-dd");
}

// date format 함수  : Date 내장 객체에 format함수 추가
Date.prototype.format = function(f) {    
    if (!this.valueOf()) return " ";     
    
    var d = this;         
    
    return f.replace(/(yyyy|MM|dd|a\/p)/gi, function($1) {        
    	switch ($1) {            
    		case "yyyy": return d.getFullYear();            
    		case "MM": return (d.getMonth() + 1).zf(2);            
    		case "dd": return d.getDate().zf(2);            
         
    		default: return $1;        
    	}    
    });
}; 

// 한자리일경우 앞에 0을 붙여준다.
String.prototype.string = function(len){
    var s = '', i = 0; 
    while (i++ < len) { s += this; } 
    return s;
};

String.prototype.zf = function(len){return "0".string(len - this.length) + this;};
Number.prototype.zf = function(len){return this.toString().zf(len);};
