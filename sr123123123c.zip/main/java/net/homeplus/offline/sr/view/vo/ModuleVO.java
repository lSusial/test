package net.homeplus.offline.sr.view.vo;

import net.homeplus.offline.common.vo.BaseVO;

public class ModuleVO extends BaseVO {

    private String sysId;
    private String modId;
    private String modNm;
    private String modDesc;
    private String modChrgEmpId;
    private String modChrgEmpNm;

    public String getModChrgEmpNm() {
        return modChrgEmpNm;
    }

    public void setModChrgEmpNm(String modChrgEmpNm) {
        this.modChrgEmpNm = modChrgEmpNm;
    }

    private String modChrgDeptId;


    public String getSysId() {
        return sysId;
    }
    public void setSysId(String sysId) {
        this.sysId = sysId;
    }

    public String getModId() {
        return modId;
    }

    public void setModId(String modId) {
        this.modId = modId;
    }

    public String getModNm() {
        return modNm;
    }

    public void setModNm(String modNm) {
        this.modNm = modNm;
    }

    public String getModDesc() {
        return modDesc;
    }

    public void setModDesc(String modDesc) {
        this.modDesc = modDesc;
    }

    public String getModChrgEmpId() {
        return modChrgEmpId;
    }

    public void setModChrgEmpId(String modChrgEmpId) {
        this.modChrgEmpId = modChrgEmpId;
    }

    public String getModChrgDeptId() {
        return modChrgDeptId;
    }

    public void setModChrgDeptId(String modChrgDeptId) {
        this.modChrgDeptId = modChrgDeptId;
    }



}
