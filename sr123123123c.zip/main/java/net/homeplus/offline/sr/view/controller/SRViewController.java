package net.homeplus.offline.sr.view.controller;

import java.io.File;
import java.util.Date;
import java.util.List;

import javax.activation.MimetypesFileTypeMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.homeplus.offline.common.code.service.CommonCodeService;
import net.homeplus.offline.common.code.vo.CodeVO;
import net.homeplus.offline.common.constant.Constants;
import net.homeplus.offline.common.vo.UserVO;
import net.homeplus.offline.sr.approval.service.ApprovalService;
import net.homeplus.offline.sr.approval.vo.ApprovalHistVO;
import net.homeplus.offline.sr.approval.vo.ApprovalRuleVO;
import net.homeplus.offline.sr.approval.vo.IndividualApprovalLineVO;
import net.homeplus.offline.sr.file.service.FileService;
import net.homeplus.offline.sr.file.vo.FileVO;
import net.homeplus.offline.sr.proc.service.ProcService;
import net.homeplus.offline.sr.view.service.ViewService;
import net.homeplus.offline.sr.view.vo.ModuleVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;
import net.homeplus.offline.sr.view.vo.SystemVO;
import net.homeplus.offline.sr.view.vo.TypeVO;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang.time.DateUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SRViewController {

    @Autowired
    private ViewService viewService;
    @Autowired
    private ApprovalService approvalService;
    @Autowired
    private CommonCodeService commonCodeService;
    @Autowired
    private ProcService procService;
    @Autowired
    private FileService fileService;

    // @Autowired
    // private EmailSender emailSender;



    @RequestMapping("/sr/list.do")
    public ModelAndView getSRList(HttpServletRequest requset, SRViewVO conditionVO, ModelAndView mav) {

        HttpSession session = requset.getSession(false);
        UserVO loginInfo = (UserVO) session.getAttribute("userInfo");


        List<TypeVO> typeList = viewService.selectTypeList(Constants.SRType.SOFTWARE);
        List<CodeVO> statusList = commonCodeService.selectCommonCodeListByGroupId(Constants.Code.SR_STATUS);

        if (conditionVO.getStrDttm() == null) {
            Date date = new Date();
            conditionVO.setEndDttm(DateUtils.addDays(date, 1));
            conditionVO.setStrDttm(DateUtils.addDays(date, -90));
        } else {
            conditionVO.setEndDttm(DateUtils.addDays(conditionVO.getEndDttm(), 1));
        }
        conditionVO.setUserId(loginInfo.getUserId());

        List<SRViewVO> srList = viewService.selectSRList(conditionVO);

        mav.addObject("srList", srList);
        mav.addObject("typeList", typeList);
        mav.addObject("statusList", statusList);
        mav.addObject("condition", conditionVO);

        mav.setViewName("sr/list");
        return mav;

    }

    @RequestMapping("/sr/detail.do")
    public ModelAndView selectSRDetail(@RequestParam String srNo, ModelAndView mav) {

        SRViewVO detail = viewService.selectSRDetail(srNo);
        List<ApprovalHistVO> approvalList = approvalService.selectSRApprovalHistListBySRId(detail.getSrId());
        List<FileVO> fileList = fileService.selectFileListBySrId(detail.getSrId());

        List<SystemVO> systemList = viewService.selectSystemListByCate(detail.getSysCateId());
        List<ModuleVO> moduleList = viewService.selectModuleList(detail.getSysId());

        List<CodeVO> sysCateList = commonCodeService.selectCommonCodeListByGroupId(Constants.SRCategory.SOFTWARE);


        mav.addObject("detail", detail);
        mav.addObject("approvalList", approvalList);
        mav.addObject("fileList", fileList);

        mav.addObject("sysCateList", sysCateList);
        mav.addObject("systemList", systemList);
        mav.addObject("moduleList", moduleList);


        mav.setViewName("sr/detail");

        return mav;

        // 파일 서비스 파일 권한 관련은 어떻게 하나

    }

    @RequestMapping(value = "/sr/regist.do", method = RequestMethod.GET)
    public ModelAndView registView(HttpServletRequest requset, ModelAndView mav) {

        HttpSession session = requset.getSession(false);
        UserVO loginInfo = (UserVO) session.getAttribute("userInfo");

        List<TypeVO> typeList = viewService.selectTypeList(Constants.SRType.SOFTWARE);
        List<CodeVO> dataTypeList = commonCodeService.selectCommonCodeListByGroupId(Constants.Code.DATA_TYPE);
        List<CodeVO> sysCateList = commonCodeService.selectCommonCodeListByGroupId(Constants.SRCategory.SOFTWARE);

        // List<SystemVO> systemList = viewService.selectSystemList(Constants.SRType.SOFTWARE);

        List<IndividualApprovalLineVO> approvalLine = approvalService.selectIndividualApprovalLine(loginInfo.getUserId());

        mav.addObject("typeList", typeList);
        mav.addObject("dataTypeList", dataTypeList);
        mav.addObject("sysCateList", sysCateList);
        // mav.addObject("systemList", systemList);
        mav.addObject("approvalLine", approvalLine);

        mav.setViewName("sr/regist");

        return mav;
    }

    @RequestMapping(value = "/sr/registHW.do", method = RequestMethod.GET)
    public ModelAndView registViewHW(HttpServletRequest requset, ModelAndView mav) {

        HttpSession session = requset.getSession(false);
        UserVO loginInfo = (UserVO) session.getAttribute("userInfo");

        List<TypeVO> typeList = viewService.selectTypeList(Constants.SRType.HARDWARE);
        // List<SystemVO> systemList = viewService.selectSystemList(Constants.SRType.HARDWARE);
        List<CodeVO> sysCateList = commonCodeService.selectCommonCodeListByGroupId(Constants.SRCategory.HARDWARE);
        List<IndividualApprovalLineVO> approvalLine = approvalService.selectIndividualApprovalLine(loginInfo.getUserId());

        mav.addObject("typeList", typeList);
        mav.addObject("sysCateList", sysCateList);
        // mav.addObject("systemList", systemList);
        mav.addObject("approvalLine", approvalLine);

        mav.setViewName("sr/registHW");

        return mav;
    }

    @RequestMapping(value = "/sr/registSR.do", method = RequestMethod.POST)
    public String registSR(HttpServletRequest req, SRViewVO vo) throws Exception {

        HttpSession session = req.getSession(false);
        UserVO loginInfo = (UserVO) session.getAttribute("userInfo");

        if (loginInfo == null || loginInfo.getUserId() == null) {
            return "/error/";
        }

        vo.setReqEmpId(loginInfo.getUserId());
        vo.setReqEmpDeptId(loginInfo.getDeptId());

        vo.setCrtId(loginInfo.getUserId()); // vo.setLastModId(loginInfo.getUserId());

        if (vo.getApprovalITListJson() != null && vo.getApprovalITListJson().length() > 10) {
            ObjectMapper mapper = new ObjectMapper();
            List<ApprovalHistVO> approvalList = mapper.readValue(vo.getApprovalListJson(), new TypeReference<List<ApprovalHistVO>>() {});
            List<ApprovalHistVO> approvalITList = mapper.readValue(vo.getApprovalITListJson(), new TypeReference<List<ApprovalHistVO>>() {});

            vo.setApprovalList(approvalList);
            vo.setApprovalITList(approvalITList);
        }

        String srId = procService.selectSRId();
        vo.setSrId(srId);
        procService.insertSR(vo);

        if (vo.getFiles() != null && vo.getFiles().size() > 0) {
            fileService.registFile(vo.getFiles(), srId);
        }



        return "redirect:/sr/list.do";

    }


    @RequestMapping(value = "/sr/modifyApprvInfo.do", method = RequestMethod.POST)
    public String modifyApprvInfo(String srNo, ApprovalHistVO vo) throws Exception {

        if (vo.getAprvStatus().equals("COMPLETE")) {
            procService.approveSR(vo);
        } else if (vo.getAprvStatus().equals("REJECT")) {
            procService.disapproveSR(vo);
        }

        if (StringUtils.defaultString(vo.getAprvTpCd()).equals("ITDEPT") && StringUtils.isNotBlank(vo.getChrgEmpId())) {
            SRViewVO srDetail = new SRViewVO();
            srDetail.setSrId(vo.getSrId());
            srDetail.setChrgEmpId(vo.getChrgEmpId());
            srDetail.setModId(vo.getModId());
            procService.updateSR(srDetail);
        }


        return "redirect:/sr/detail.do?srNo=" + srNo;

    }


    @RequestMapping(value = "/sr/changSystem.do", method = RequestMethod.POST)
    public String changeSystem(String srNo, SRViewVO vo) throws Exception {

        if (StringUtils.isBlank(vo.getSrId()) || StringUtils.isBlank(vo.getSrTypeId())) {
            return "redirect:/sr/detail.do?srNo=" + srNo;
        }

        procService.updateSystem(vo);


        return "redirect:/sr/detail.do?srNo=" + srNo;

    }



    @RequestMapping(value = "/sr/cancelSR.do", method = RequestMethod.POST)
    public String cancelSR(String srNo, SRViewVO vo) throws Exception {

        // sesssion 값 획듯
        procService.cancelSR(vo);

        return "redirect:/sr/detail.do?srNo=" + srNo;

    }

    @RequestMapping(value = "/sr/filedown.do", produces = MediaType.APPLICATION_OCTET_STREAM_VALUE)
    public @ResponseBody FileSystemResource download(HttpServletResponse res, FileVO vo) {

        FileVO fileVO = fileService.selectFileWithDir(vo);
        if (fileVO == null) {
            return null;
        }
        File file = new File(fileVO.getFileNm());

        res.setContentType(new MimetypesFileTypeMap().getContentType(file));
        res.setHeader("Content-Disposition", "inline; filename=" + fileVO.getOrgFileNm());
        res.setHeader("Content-Length", String.valueOf(file.length()));

        return new FileSystemResource(file);

    }


    @RequestMapping(value = "/json/searchEmp.json")
    @ResponseBody
    public List<UserVO> selectEmpList(@RequestParam String searchWord) {
        List<UserVO> empList = viewService.selectEmpList(searchWord);
        return empList;
    }


    @RequestMapping(value = "/json/searchITApprovalRule.json")
    @ResponseBody
    public List<ApprovalRuleVO> selectApprovalLine(ApprovalRuleVO ruleVO) {
        List<ApprovalRuleVO> approvalLine = approvalService.selectSRApprovalRule(ruleVO);
        return approvalLine;

    }

    @RequestMapping(value = "/sr/getSystemList.json")
    @ResponseBody
    public List<SystemVO> selectSystemListByCate(SystemVO vo) {
        List<SystemVO> systemList = viewService.selectSystemListByCate(vo.getSysCateId());
        return systemList;

    }

    @RequestMapping(value = "/sr/getModuleList.json")
    @ResponseBody
    public List<ModuleVO> selectModuleListByCate(String sysId) {
        List<ModuleVO> mouduleList = viewService.selectModuleList(sysId);
        return mouduleList;
    }


    @RequestMapping(value = "/json/test.json")
    @ResponseBody
    public List<TypeVO> selectTypeList(ModelAndView mav) {
        List<TypeVO> systemList = viewService.selectTypeList("SW");
        return systemList;

    }


    @RequestMapping("/getSRList.do")
    @ResponseBody
    public List<SRViewVO> getSRList() {

        // TODO SR 목록 보여주는 거

        // 자신이 올린거
        // 결제 목록이 온거 조인이 필요

        return null;
    }


    @RequestMapping("/getSRListJson.do")
    @ResponseBody
    public List<SRViewVO> getSRListJson() {

        // TODO SR 목록 보여주는 거


        return null;
    }

}
