package net.homeplus.offline.intergrate.dao;

import javax.annotation.Resource;

import net.homeplus.offline.intergrate.vo.PushVO;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.stereotype.Repository;

@Repository("IntergrateTicketDAO")
public class IntergrateTicketDAO extends SqlSessionDaoSupport {

    @Resource(name = "sqlSessionFactoryTicket")
    @Override
    public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
        super.setSqlSessionFactory(sqlSessionFactory);;

    }

    @Resource(name = "sqlSessionTemplateTicket")
    @Override
    public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
        super.setSqlSessionTemplate(sqlSessionTemplate);
    }

    public void insertSRtoTicketDB(PushVO vo) {
        getSqlSession().insert("Ticket.insertSRtoTicketDB", vo);
    }



}
