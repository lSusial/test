package conn_Test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class JDBCExample {
	public static void main(String[] argv) {
		
		System.out.println("-------- PostgreSQL "
				+ "JDBC Connection Testing ------------");

		try {

//			Class.forName("org.postgresql.Driver");
			
			Class.forName("com.ibm.db2.jcc.DB2Driver");

		} catch (ClassNotFoundException e) {

			System.out.println("Where is your PostgreSQL JDBC Driver? "
					+ "Include in your library path!");
			e.printStackTrace();
			return;

		}

		System.out.println("PostgreSQL JDBC Driver Registered!");

		Connection connection = null;

		try {

			/*connection = DriverManager.getConnection(
					"jdbc:postgresql://10.38.1.232:5432/t-motion", "postgres",
					"fcpass");*/	//TICKET
			/*connection = DriverManager.getConnection(
					"jdbc:postgresql://10.38.1.232:5432/INV_TEST", "postgres",
					"fcpass");*/		//TICKET TEST
			
			
			
			/*connection = DriverManager.getConnection(
					"jdbc:postgresql://10.10.64.102:5432/homeplus_if", "homeplus_if",
					"hp_if_123@#");*/		//ITSM
			
			
			
			connection = DriverManager.getConnection(
			"jdbc:db2://10.10.64.145:50000/db2admin", "db2admin",
			"future_01");		//NEWSR
			
			/*connection = DriverManager.getConnection(
					"jdbc:db2://10.10.64.143:50000/CCM_EXT", "db2admin",
					"future_01");*/		//DB2
			
			if (connection != null) {
				System.out.println("You made it, take control your database now!");
			} else {
				System.out.println("Failed to make connection!");
			}
			
			
			
			
			
			
			
			
			//ITSM SELECT
			/*String selSQL = "select * from if_na_rtc order by seq";
			PreparedStatement stmt = null;
			ResultSet rst = null;
			
			stmt = connection.prepareStatement(selSQL);
			rst = stmt.executeQuery();
			while (rst.next()) {
				System.out.println(rst.getString("SEQ")); 
				System.out.println(rst.getString("RTC_ID"));
				System.out.println(rst.getString("RCPTDT"));
				System.out.println(rst.getString("EMG_NM"));
				System.out.println(rst.getString("SYS_TYPE"));
				System.out.println(rst.getString("SYS_NM"));
				System.out.println(rst.getString("SYS_MODULE"));
				System.out.println(rst.getString("SYS_GROUP"));
				System.out.println(rst.getString("EMG_START_DATE"));
				System.out.println(rst.getString("EMG_END_DATE"));
				System.out.println(rst.getString("EMG_TIME"));
				System.out.println(rst.getString("EMG_LVL"));
				System.out.println(rst.getString("EMG_RESOLVE_YN"));
				System.out.println(rst.getString("EMG_TITLE"));
				System.out.println(rst.getString("EMG_DESC"));
				System.out.println(rst.getString("EMG_RESULT"));
				System.out.println(rst.getString("EMG_STATUS"));
				System.out.println(rst.getString("EMG_DEFENSE"));
				System.out.println(rst.getString("ITSM_RCV_DATE"));
				System.out.println("--------------------------------------------");
			}*/
			
			
			//ITSM DELETE
			/*String delSQL = "DELETE FROM if_na_rtc WHERE seq='6'";
			PreparedStatement stmt = null;
			
			stmt = connection.prepareStatement(delSQL);
			
			int success = stmt.executeUpdate();
			if (success > 0) {
				System.out.println("Delete Success");
			}
			else
			{
				System.out.println("Insert Fail");
			}*/
			
			
			//TICKET SELECT
			/*String selSQL = "select * from rtc_ticket order by rtc_recept_num";
			PreparedStatement stmt = null;
			ResultSet rst = null;
			
			stmt = connection.prepareStatement(selSQL);
			rst = stmt.executeQuery();
			while (rst.next()) {
				System.out.println(rst.getString("RTC_RECEPT_NUM")); 
				System.out.println(rst.getString("RTC_TRANS_DATETIME"));
				System.out.println(rst.getString("RTC_AGENT_ID"));
				System.out.println(rst.getString("RTC_SYS_CODE"));
				System.out.println(rst.getString("RTC_COMPLETE_DATE"));
				System.out.println(rst.getString("RTC_MA_WORKING_DESCR"));
				System.out.println(rst.getString("RTC_USER_ID"));
				System.out.println(rst.getString("RTC_USER_NM"));
				System.out.println(rst.getString("RTC_RCV"));
				System.out.println(rst.getString("RTC_RCV_DATE"));
				System.out.println("--------------------------------------------");
			}*/
			
			
			//TICKET DELETE
			/*String delSQL = "DELETE FROM rtc_ticket";
			PreparedStatement stmt = null;
			
			stmt = connection.prepareStatement(delSQL);
			
			int success = stmt.executeUpdate();
			if (success > 0) {
				System.out.println("Delete Success");
			}
			else
			{
				System.out.println("Insert Fail");
			}*/
			
			
			//NEWSR SELECT
			String selSQL = "select * from TB_RTCRESULT order by seq";
			PreparedStatement stmt = null;
			ResultSet rst = null;
			
			stmt = connection.prepareStatement(selSQL);
			rst = stmt.executeQuery();
			while (rst.next()) {
				System.out.println(rst.getString("SEQ")); 
				System.out.println(rst.getString("SR_ID"));
				System.out.println(rst.getString("RTC_ID"));
				System.out.println(rst.getString("STATUS_CD"));
				System.out.println(rst.getString("WORK_NM"));
				System.out.println(rst.getString("WORK_MAIL"));
				System.out.println(rst.getString("WORK_DATE"));
				System.out.println(rst.getString("RESULT_DESC"));
				System.out.println(rst.getString("EST_END_DATE"));
				System.out.println(rst.getString("RTC_RCV"));
				System.out.println(rst.getString("RTC_RCV_DATE"));
				System.out.println(rst.getString("SR_UPD_DATE"));
				System.out.println("--------------------------------------------");
			}
			
			
			
			
			connection.close();
			
		} catch (SQLException e) {

			System.out.println("Connection Failed! Check output console");
			e.printStackTrace();
			return;

		}
		
	}

}
