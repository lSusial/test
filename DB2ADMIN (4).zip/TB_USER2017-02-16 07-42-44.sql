SET CURRENT SCHEMA DB2ADMIN;

insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('hardware','하드웨어결제자','TEMP_006',null,null,'hardware@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('hoonyyoon','윤영훈','TEMP_001',null,null,'hoonyyoon@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('yl.kim','김예린','TEMP_001',null,null,'yl.kim@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('dahchoi','최다현','TEMP_002',null,null,'dahchoi@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('rk.park','박로경','TEMP_003',null,null,'rk.park@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('nick','김연익','TEMP_001','',null,'nick@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('kjkim','김기종','TEMP_002',null,null,'kjkim@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('superiork','김용찬','TEMP_003',null,null,'superiork@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('sangminl','이상민','TEMP_004',null,null,'sangminl@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('parksm','박시몬','TEMP_004',null,null,'parksm@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test1','사용자1','TEMP_005',null,null,'test1@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('alter1','대결자1','TEMP_001',null,null,'alter1@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('alter2','대결자2','TEMP_002',null,null,'alter2@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test2','사용자2','TEMP_005',null,null,'test2@homeplus.co.kr',null);
