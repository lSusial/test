SET CURRENT SCHEMA DB2ADMIN;

insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_001','부서1','DEPT_000',null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_002','부서2','DEPT_000',null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_003','부서3','DEPT_000',null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_004','부서4','DEPT_000',null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_005','부서5','DEPT_000',null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_006','부서6','DEPT_000',null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_007','부서7','DEPT_000',null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('TEMP_001','영업시스템',null,null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('TEMP_002','통합운송센터, 운영지원',null,null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('TEMP_003','지원시스템',null,null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('TEMP_004','강서점',null,null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('TEMP_005','잠실점',null,null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('TEMP_006','하드웨어 구매부',null,null,null);
