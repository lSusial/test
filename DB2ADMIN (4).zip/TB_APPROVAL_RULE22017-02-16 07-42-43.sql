SET CURRENT SCHEMA DB2ADMIN;

insert into "TB_APPROVAL_RULE2"("APRV_RULE_ID","APRV_RULE_SEQ","SR_TYPE_ID","SYS_ID","APRV_TYPE","APRV_DEPT_ID","APRV_EMP_ID","APRV_DESC","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('RULE1',1,'UD','SYS001','SW','DEPT_002','test4@homeplus.co.kr',null,'Y',null,null,null,null);
insert into "TB_APPROVAL_RULE2"("APRV_RULE_ID","APRV_RULE_SEQ","SR_TYPE_ID","SYS_ID","APRV_TYPE","APRV_DEPT_ID","APRV_EMP_ID","APRV_DESC","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('RULE2',2,'UD','SYS001','SW','DEPT_002','test5@homeplus.co.kr',null,'Y',null,null,null,null);
insert into "TB_APPROVAL_RULE2"("APRV_RULE_ID","APRV_RULE_SEQ","SR_TYPE_ID","SYS_ID","APRV_TYPE","APRV_DEPT_ID","APRV_EMP_ID","APRV_DESC","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('RULE3',1,'UD','SYS002','SW','DEPT_001','test1@homeplus.co.kr',null,'Y',null,null,null,null);
