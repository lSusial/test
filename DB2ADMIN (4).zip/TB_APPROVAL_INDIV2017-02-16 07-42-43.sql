SET CURRENT SCHEMA DB2ADMIN;

insert into "TB_APPROVAL_INDIV"("USER_ID","APRV_INDIV_SEQ","APRV_DEPT_ID","APRV_EMP_ID","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('test1@homeplus.co.kr',1,'DEPT_003','test6@homeplus.co.kr',null,null,null,null,null);
insert into "TB_APPROVAL_INDIV"("USER_ID","APRV_INDIV_SEQ","APRV_DEPT_ID","APRV_EMP_ID","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('sangminl',1,'TEMP_004','parksm',null,null,null,null,null);
