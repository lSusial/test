SET CURRENT SCHEMA DB2ADMIN;

insert into "TB_ALTERNATE"("USER_ID","ALTER_EMP_ID","ALTER_EMP_NM","EMAIL","CRT_ID","CRT_DTTM") values ('test1@homeplus.co.kr','test2@homeplus.co.kr',null,null,null,'2017-02-12-21.28.34.481000');
insert into "TB_ALTERNATE"("USER_ID","ALTER_EMP_ID","ALTER_EMP_NM","EMAIL","CRT_ID","CRT_DTTM") values ('test5@homeplus.co.kr','test7@homeplus.co.kr',null,null,null,'2017-02-06-07.06.36.150000');
insert into "TB_ALTERNATE"("USER_ID","ALTER_EMP_ID","ALTER_EMP_NM","EMAIL","CRT_ID","CRT_DTTM") values ('nick','alter1',null,null,null,'2017-02-16-07.06.02.272000');
