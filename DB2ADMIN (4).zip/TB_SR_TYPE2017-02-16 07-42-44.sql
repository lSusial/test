SET CURRENT SCHEMA DB2ADMIN;

insert into "TB_SR_TYPE"("SR_TYPE_ID","SR_TYPE_NM","TGR_TP_CD","APPR_REQ_YN","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('US','문의','SW','N','Y',null,null,null,null);
insert into "TB_SR_TYPE"("SR_TYPE_ID","SR_TYPE_NM","TGR_TP_CD","APPR_REQ_YN","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('UD','권한 요청','SW','Y','Y',null,null,null,null);
insert into "TB_SR_TYPE"("SR_TYPE_ID","SR_TYPE_NM","TGR_TP_CD","APPR_REQ_YN","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('UA','데이터 추출 변경','SW','Y','Y',null,null,null,null);
insert into "TB_SR_TYPE"("SR_TYPE_ID","SR_TYPE_NM","TGR_TP_CD","APPR_REQ_YN","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SR','프로그램 변경','SW','Y','Y',null,null,null,null);
insert into "TB_SR_TYPE"("SR_TYPE_ID","SR_TYPE_NM","TGR_TP_CD","APPR_REQ_YN","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('RP','점검 / 수리','HW','N','Y',null,null,null,null);
insert into "TB_SR_TYPE"("SR_TYPE_ID","SR_TYPE_NM","TGR_TP_CD","APPR_REQ_YN","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('PS','구입','HW','Y','Y',null,null,null,null);
