package com.homeplus.batch.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.homeplus.batch.model.UserVO;


public class UserVORowMapper implements RowMapper<UserVO> {

    @Override
    public UserVO mapRow(ResultSet rs, int rowNum) throws SQLException {

        UserVO user = new UserVO();

        user.setUserId(rs.getString("PERSON_CODE"));
        user.setUserNm(rs.getString("DISPLAY_NAME"));
        user.setDeptId(rs.getString("UNIT_CODE"));
        user.setJobTitle(rs.getString("jobtitle"));

        return user;
    }

}
