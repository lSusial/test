package net.homeplus.offline.common.intercepter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.homeplus.offline.common.vo.UserVO;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class LoginIntercepter extends HandlerInterceptorAdapter {

    @Value("#{config['url.login']}")
    private String loginURL;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {


        HttpSession session = request.getSession();
        UserVO loginInfo = new UserVO();

        try {
            loginInfo = (UserVO) session.getAttribute("userInfo");
        } catch (Exception e) {
        }

        if (session == null || loginInfo == null) {

            response.sendRedirect("/login/login.do");
            return false;

        }

        return true;
    }


}
