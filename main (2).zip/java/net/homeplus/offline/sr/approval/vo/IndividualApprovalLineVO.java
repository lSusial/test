package net.homeplus.offline.sr.approval.vo;

public class IndividualApprovalLineVO {

    private String userId;
    private String aprvIndivSeq;
    private String aprvDeptId;
    private String aprvDeptNm;
    private String aprvEmpId;
    private String aprvEmpNm;
    private String aprvEmpJobTitle;
    private String aprvEmpEmail;


    @Override
    public String toString() {
        return "IndividualApprovalLineVO [userId=" + userId + ", aprvIndivSeq=" + aprvIndivSeq + ", aprvDeptId=" + aprvDeptId + ", aprvDeptNm=" + aprvDeptNm
                + ", aprvEmpId=" + aprvEmpId + ", aprvEmpNm=" + aprvEmpNm + ", aprvEmpEmail=" + aprvEmpEmail + "]";
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAprvIndivSeq() {
        return aprvIndivSeq;
    }

    public void setAprvIndivSeq(String aprvIndivSeq) {
        this.aprvIndivSeq = aprvIndivSeq;
    }

    public String getAprvDeptId() {
        return aprvDeptId;
    }

    public void setAprvDeptId(String aprvDeptId) {
        this.aprvDeptId = aprvDeptId;
    }

    public String getAprvDeptNm() {
        return aprvDeptNm;
    }

    public void setAprvDeptNm(String aprvDeptNm) {
        this.aprvDeptNm = aprvDeptNm;
    }

    public String getAprvEmpId() {
        return aprvEmpId;
    }

    public void setAprvEmpId(String aprvEmpId) {
        this.aprvEmpId = aprvEmpId;
    }

    public String getAprvEmpNm() {
        return aprvEmpNm;
    }

    public void setAprvEmpNm(String aprvEmpNm) {
        this.aprvEmpNm = aprvEmpNm;
    }

    public String getAprvEmpEmail() {
        return aprvEmpEmail;
    }

    public void setAprvEmpEmail(String aprvEmpEmail) {
        this.aprvEmpEmail = aprvEmpEmail;
    }

    public String getAprvEmpJobTitle() {
        return aprvEmpJobTitle;
    }

    public void setAprvEmpJobTitle(String aprvEmpJobTitle) {
        this.aprvEmpJobTitle = aprvEmpJobTitle;
    }




}
