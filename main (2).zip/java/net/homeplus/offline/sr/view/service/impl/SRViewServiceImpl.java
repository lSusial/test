package net.homeplus.offline.sr.view.service.impl;

import java.util.List;

import net.homeplus.offline.common.util.CommonUtil;
import net.homeplus.offline.common.vo.UserVO;
import net.homeplus.offline.sr.view.dao.ViewDAO;
import net.homeplus.offline.sr.view.service.ViewService;
import net.homeplus.offline.sr.view.vo.ModuleVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;
import net.homeplus.offline.sr.view.vo.SystemVO;
import net.homeplus.offline.sr.view.vo.TypeVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("ViewService")
public class SRViewServiceImpl implements ViewService {

    @Autowired
    private ViewDAO viewDAO;

    @Override
    public List<SRViewVO> selectSRList(SRViewVO vo) {

        List<SRViewVO> list = viewDAO.selectSRList(vo);

        for (SRViewVO sr : list) {
            sr.setCrtDt(CommonUtil.dateToStr(sr.getCrtDttm()));
            sr.setTgtDt(CommonUtil.dateToStr(sr.getTgtDttm()));
        }

        return list;

    }

    @Override
    public SRViewVO selectSRDetail(String srNo) {
        SRViewVO returnVO = viewDAO.selectSRDetail(srNo);
        returnVO.setCrtDt(CommonUtil.dateToStr(returnVO.getCrtDttm()));
        returnVO.setTgtDt(CommonUtil.dateToStr(returnVO.getTgtDttm()));
        returnVO.setCloseDt(CommonUtil.dateToStr(returnVO.getCloseDttm()));
        return returnVO;
    }

    @Override
    public List<TypeVO> selectTypeList(String type) {
        return viewDAO.selectSRTypeList(type);
    }

    @Override
    public List<SystemVO> selectSystemList(String type) {
        return viewDAO.selectSystemList(type);
    }

    @Override
    public List<UserVO> selectEmpList(UserVO vo) {

        return viewDAO.selectEmpList(vo);
    }

    @Override
    public List<ModuleVO> selectModuleList(String sysId) {
        return viewDAO.selectModuleList(sysId);
    }

    @Override
    public List<SystemVO> selectSystemListByCate(String sysCateId) {
        return viewDAO.selectSystemListByCate(sysCateId);
    }



}
