package net.homeplus.offline.intergrate.vo;


public class RTCResultVO {

    private String seq;
    private String srId;
    private String rtcId;
    private String statusCd;
    private String workNm;
    private String workDate;
    private String resultDesc;
    private String rtcRcv;
    private String rtcRcvDate;
    private String srUpdDate;

    private String status;


    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public String getSrId() {
        return srId;
    }

    public void setSrId(String srId) {
        this.srId = srId;
    }

    public String getRtcId() {
        return rtcId;
    }

    public void setRtcId(String rtcId) {
        this.rtcId = rtcId;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    public String getWorkNm() {
        return workNm;
    }

    public void setWorkNm(String workNm) {
        this.workNm = workNm;
    }

    public String getWorkDate() {
        return workDate;
    }

    public void setWorkDate(String workDate) {
        this.workDate = workDate;
    }

    public String getResultDesc() {
        return resultDesc;
    }

    public void setResultDesc(String resultDesc) {
        this.resultDesc = resultDesc;
    }

    public String getRtcRcv() {
        return rtcRcv;
    }

    public void setRtcRcv(String rtcRcv) {
        this.rtcRcv = rtcRcv;
    }

    public String getSrUpdDate() {
        return srUpdDate;
    }

    public void setSrUpdDate(String srUpdDate) {
        this.srUpdDate = srUpdDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRtcRcvDate() {
        return rtcRcvDate;
    }

    public void setRtcRcvDate(String rtcRcvDate) {
        this.rtcRcvDate = rtcRcvDate;
    }



}
