SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_ATTACH (
  SR_ID	VARCHAR(11)	NOT NULL,
  FILE_NM	VARCHAR(241)	NOT NULL,
  ORG_FILE_NM	VARCHAR(250),
  CRT_ID	VARCHAR(10),
  CRT_DTTM	TIMESTAMP,
  LAST_MOD_ID	VARCHAR(10),
  LAST_MOD_DTTM	TIMESTAMP,
  FILE_DIR	VARCHAR(50)
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_ATTACH
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_ATTACH
  ADD PRIMARY KEY
    (SR_ID, FILE_NM)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_ATTACH
	ALLOW WRITE ACCESS;



insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000089','LGPL02010033.TXT','LGPL.TXT',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000089','license02010033.txt','license.txt',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','�ý���_����_��û��','�ý���_����_��û��',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','RPM_��û��','RPM_��û��',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','GMIS_������_����/��û_��û��','GMIS_������_����/��û_��û��',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','GMIS_Ad-hos_Report_��û��','GMIS_Ad-hos_Report_��û��',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','IP_Address_��û��_����','IP_Address_��û��_����',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','LGPL02010033.TXT','LGPL.TXT',null,null,null,null,null);
