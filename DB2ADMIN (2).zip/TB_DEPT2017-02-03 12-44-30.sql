SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_DEPT (
  DEPT_ID	VARCHAR(15)	NOT NULL,
  DEPT_NM	VARCHAR(50),
  P_DEPT_ID	VARCHAR(15),
  GUBUN	VARCHAR(10),
  CREATE_DATE	VARCHAR(10)
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_DEPT
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_DEPT
  ADD PRIMARY KEY
    (DEPT_ID)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_DEPT
	ALLOW WRITE ACCESS;



insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_001','�μ�1','DEPT_000',null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_002','�μ�2','DEPT_000',null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_003','�μ�3','DEPT_000',null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_004','�μ�4','DEPT_000',null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_005','�μ�5','DEPT_000',null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_006','�μ�6','DEPT_000',null,null);
insert into "TB_DEPT"("DEPT_ID","DEPT_NM","P_DEPT_ID","GUBUN","CREATE_DATE") values ('DEPT_007','�μ�7','DEPT_000',null,null);
