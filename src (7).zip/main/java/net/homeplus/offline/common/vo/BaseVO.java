package net.homeplus.offline.common.vo;

import java.util.Date;

public class BaseVO {
    private String crtId;
    private Date crtDttm;
    private String lastModId;
    private Date lastModDttm;


    public String getCrtId() {
        return crtId;
    }
    public void setCrtId(String crtId) {
        this.crtId = crtId;
    }

    public Date getCrtDttm() {
        return crtDttm;
    }

    public void setCrtDttm(Date crtDttm) {
        this.crtDttm = crtDttm;
    }
    public String getLastModId() {
        return lastModId;
    }
    public void setLastModId(String lastModId) {
        this.lastModId = lastModId;
    }

    public Date getLastModDttm() {
        return lastModDttm;
    }

    public void setLastModDttm(Date lastModDttm) {
        this.lastModDttm = lastModDttm;
    }



}
