package net.homeplus.offline.common.constant;

public final class Constants {

    private Constants() {};

    public final class SRType {
        public static final String HARDWARE = "HW";
        public static final String SOFTWARE = "SW";

        private SRType() {};
    }
    
    public final class SRCategory {
        public static final String HARDWARE = "HWCAT";
        public static final String SOFTWARE = "SWCAT";

        private SRCategory() {};
    }


    public final class Code {
        
        public static final String SR_STATUS = "SRS";

        private Code() {};
    }

    public final class ApproveType {

        public static final String DRATE = "DRATE";
        public static final String COMMON_DEPT = "COMMDEPT";
        public static final String IT_DEPT = "ITDEPT";

        private ApproveType() {};
    }

    public final class ApproveStatus {

        public static final String COMPLETE = "COMPLETE";
        public static final String IN_PROGRESS = "INPROGRESS";
        public static final String WAITING = "WAITING";

        private ApproveStatus() {};
    }

}
