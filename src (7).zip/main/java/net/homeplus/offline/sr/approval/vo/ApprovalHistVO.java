package net.homeplus.offline.sr.approval.vo;


public class ApprovalHistVO {

    private String srId;
    private String aprvSeq;
    private String aprvTpCd;
    private String aprvDeptId;
    private String aprvDeptNm;
    private String aprvEmpId;
    private String aprvEmpNm;
    private String aprvStatus;
    private String mailSendYn;
    private String aprvDttm;
    private String aprvCnts;
    private String orgAprvEmpId;


    private String chrgEmpId;
    private String modId;

    public String getChrgEmpId() {
        return chrgEmpId;
    }

    public void setChrgEmpId(String chrgEmpId) {
        this.chrgEmpId = chrgEmpId;
    }

    public String getModId() {
        return modId;
    }

    public void setModId(String modId) {
        this.modId = modId;
    }
    public String getSrId() {
        return srId;
    }
    public void setSrId(String srId) {
        this.srId = srId;
    }
    public String getAprvSeq() {
        return aprvSeq;
    }
    public void setAprvSeq(String aprvSeq) {
        this.aprvSeq = aprvSeq;
    }
    public String getAprvTpCd() {
        return aprvTpCd;
    }
    public void setAprvTpCd(String aprvTpCd) {
        this.aprvTpCd = aprvTpCd;
    }
    public String getAprvDeptId() {
        return aprvDeptId;
    }
    public void setAprvDeptId(String aprvDeptId) {
        this.aprvDeptId = aprvDeptId;
    }
    public String getAprvEmpId() {
        return aprvEmpId;
    }
    public void setAprvEmpId(String aprvEmpId) {
        this.aprvEmpId = aprvEmpId;
    }
    public String getAprvStatus() {
        return aprvStatus;
    }
    public void setAprvStatus(String aprvStatus) {
        this.aprvStatus = aprvStatus;
    }
    public String getMailSendYn() {
        return mailSendYn;
    }
    public void setMailSendYn(String mailSendYn) {
        this.mailSendYn = mailSendYn;
    }
    public String getAprvDttm() {
        return aprvDttm;
    }
    public void setAprvDttm(String aprvDttm) {
        this.aprvDttm = aprvDttm;
    }

    public String getAprvCnts() {
        return aprvCnts;
    }

    public void setAprvCnts(String aprvCnts) {
        this.aprvCnts = aprvCnts;
    }

    public String getAprvDeptNm() {
        return aprvDeptNm;
    }

    public void setAprvDeptNm(String aprvDeptNm) {
        this.aprvDeptNm = aprvDeptNm;
    }

    public String getAprvEmpNm() {
        return aprvEmpNm;
    }

    public void setAprvEmpNm(String aprvEmpNm) {
        this.aprvEmpNm = aprvEmpNm;
    }

    public String getOrgAprvEmpId() {
        return orgAprvEmpId;
    }

    public void setOrgAprvEmpId(String orgAprvEmpId) {
        this.orgAprvEmpId = orgAprvEmpId;
    }

    @Override
    public String toString() {
        return "ApprovalHistVO [srId=" + srId + ", aprvSeq=" + aprvSeq + ", aprvTpCd=" + aprvTpCd + ", aprvDeptId=" + aprvDeptId + ", aprvDeptNm=" + aprvDeptNm
                + ", aprvEmpId=" + aprvEmpId + ", aprvEmpNm=" + aprvEmpNm + ", aprvStatus=" + aprvStatus + ", mailSendYn=" + mailSendYn + ", aprvDttm="
                + aprvDttm + ", aprvCnts=" + aprvCnts + ", orgAprvEmpId=" + orgAprvEmpId + ", chrgEmpId=" + chrgEmpId + ", modId=" + modId + "]";
    }



}
