package net.homeplus.offline.sr.view.service.impl;

import java.util.List;

import net.homeplus.offline.common.util.CommonUtil;
import net.homeplus.offline.common.vo.UserVO;
import net.homeplus.offline.sr.view.dao.ViewDAO;
import net.homeplus.offline.sr.view.service.ViewService;
import net.homeplus.offline.sr.view.vo.ModuleVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;
import net.homeplus.offline.sr.view.vo.SystemVO;
import net.homeplus.offline.sr.view.vo.TypeVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("ViewService")
public class SRViewServiceImpl implements ViewService {

    @Autowired
    private ViewDAO viewDAO;

    @Override
    public List<SRViewVO> selectSRList(SRViewVO vo) {

        List<SRViewVO> list = viewDAO.selectSRList(vo);
        
        for(SRViewVO sr : list){
            sr.setCrtDt(CommonUtil.dateToStr(sr.getCrtDttm()));
            sr.setTgtDt(CommonUtil.dateToStr(sr.getTgtDttm()));
        }
        
        return list;

    }

    @Override
    public SRViewVO selectSRDetail(String srNo) {
        return viewDAO.selectSRDetail(srNo);
    }

    @Override
    public List<TypeVO> selectTypeList(String type) {
        return viewDAO.selectSRTypeList(type);
    }

    @Override
    public List<SystemVO> selectSystemList(String type) {
        return viewDAO.selectSystemList(type);
    }

    @Override
    public List<UserVO> selectEmpList(String searchWord) {

        return viewDAO.selectEmpList(searchWord);
    }

    @Override
    public List<ModuleVO> selectModuleList(String sysId) {
        return viewDAO.selectModuleList(sysId);
    }

    @Override
    public List<SystemVO> selectSystemListByCate(SystemVO vo) {
        return viewDAO.selectSystemListByCate(vo);
    }



}
