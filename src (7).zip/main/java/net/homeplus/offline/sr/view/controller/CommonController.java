package net.homeplus.offline.sr.view.controller;

import net.homeplus.offline.sr.approval.service.ApprovalService;
import net.homeplus.offline.sr.file.service.FileService;
import net.homeplus.offline.sr.view.service.ViewService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class CommonController {

    @Autowired
    private ViewService viewService;
    @Autowired
    private ApprovalService approvalService;

    @Autowired
    private FileService fileService;


}
