package net.homeplus.offline.sr.view.service;

import java.util.List;

import net.homeplus.offline.common.vo.UserVO;
import net.homeplus.offline.sr.view.vo.ModuleVO;
import net.homeplus.offline.sr.view.vo.SRViewVO;
import net.homeplus.offline.sr.view.vo.SystemVO;
import net.homeplus.offline.sr.view.vo.TypeVO;

public interface ViewService {

    public List<SRViewVO> selectSRList(SRViewVO vo);

    public SRViewVO selectSRDetail(String srNo);

    public List<TypeVO> selectTypeList(String type);

    public List<SystemVO> selectSystemList(String type);

    public List<UserVO> selectEmpList(String searchWord);

    public List<ModuleVO> selectModuleList(String sysId);

    public List<SystemVO> selectSystemListByCate(SystemVO vo);

}
