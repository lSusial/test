package net.homeplus.offline.sr.file.vo;


public class FileVO {

    private String srId;
    private String orgFileNm;
    private String fileNm;
    private String filedir;

    public FileVO() {}

    public FileVO(String srId, String orgFileNm, String fileNm) {
        super();
        this.srId = srId;
        this.orgFileNm = orgFileNm;
        this.fileNm = fileNm;
    }

    public String getSrId() {
        return srId;
    }

    public void setSrId(String srId) {
        this.srId = srId;
    }

    public String getFileNm() {
        return fileNm;
    }

    public void setFileNm(String fileNm) {
        this.fileNm = fileNm;
    }

    public String getOrgFileNm() {
        return orgFileNm;
    }

    public void setOrgFileNm(String orgFileNm) {
        this.orgFileNm = orgFileNm;
    }

    public String getFiledir() {
        return filedir;
    }

    public void setFiledir(String filedir) {
        this.filedir = filedir;
    }



}
