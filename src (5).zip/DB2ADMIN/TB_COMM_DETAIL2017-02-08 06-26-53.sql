SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_COMM_DETAIL (
  CD_GRP_ID	VARCHAR(10)	NOT NULL,
  CD_ID	VARCHAR(10)	NOT NULL,
  CD_NM	VARCHAR(10),
  ATTR1	VARCHAR(10),
  ATTR2	VARCHAR(10),
  ATTR3	VARGRAPHIC(10),
  USE_YN	VARCHAR(10)	NOT NULL,
  CRT_ID	VARCHAR(10),
  CRT_DTTM	TIMESTAMP,
  LAST_MOD_ID	INTEGER,
  LAST_MOD_DTTM	TIMESTAMP
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_COMM_DETAIL
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_COMM_DETAIL
  ADD PRIMARY KEY
    (CD_GRP_ID, CD_ID)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_COMM_DETAIL
	ALLOW WRITE ACCESS;



insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SRS','010','접수',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SRS','020','결재중',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SRS','030','처리중',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SRS','040','완료',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SRS','042','반려',null,null,null,'Y',null,null,null,null);
