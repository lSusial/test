SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_ATTACH (
  SR_ID	VARCHAR(11)	NOT NULL,
  FILE_NM	VARCHAR(241)	NOT NULL,
  ORG_FILE_NM	VARCHAR(250),
  CRT_ID	VARCHAR(10),
  CRT_DTTM	TIMESTAMP,
  LAST_MOD_ID	VARCHAR(10),
  LAST_MOD_DTTM	TIMESTAMP,
  FILE_DIR	VARCHAR(50)
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_ATTACH
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_ATTACH
  ADD PRIMARY KEY
    (SR_ID, FILE_NM)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_ATTACH
	ALLOW WRITE ACCESS;



insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000089','LGPL02010033.TXT','LGPL.TXT',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000089','license02010033.txt','license.txt',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','시스템_변경_요청서','시스템_변경_요청서',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','RPM_요청서','RPM_요청서',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','GMIS_쿼리문_수정/신청_요청서','GMIS_쿼리문_수정/신청_요청서',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','GMIS_Ad-hos_Report_요청서','GMIS_Ad-hos_Report_요청서',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','IP_Address_신청서_개인','IP_Address_신청서_개인',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('TEMPLATE','LGPL02010033.TXT','LGPL.TXT',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000121','02060225.','',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000161','02060805.','',null,null,null,null,null);
insert into "TB_ATTACH"("SR_ID","FILE_NM","ORG_FILE_NM","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM","FILE_DIR") values ('00000000162','02060809.','',null,null,null,null,null);
