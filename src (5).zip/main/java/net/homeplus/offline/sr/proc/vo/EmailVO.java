package net.homeplus.offline.sr.proc.vo;

import java.util.Date;

import net.homeplus.offline.common.vo.BaseVO;

import org.springframework.format.annotation.DateTimeFormat;

public class EmailVO extends BaseVO {

    private String srId;
    private String srNo;
    private String srTypeNm;
    private String sysNm;
    private String reqEmpNm;
    private String reqEmpDeptNm;
    private String reqEmpEmail;
    private String title;
    private String desc;
    private String confDataYn;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date tgtDttm;
    private String status;

    private String toAddress;

    public String getSrId() {
        return srId;
    }

    public void setSrId(String srId) {
        this.srId = srId;
    }

    public String getSrNo() {
        return srNo;
    }

    public void setSrNo(String srNo) {
        this.srNo = srNo;
    }

    public String getSrTypeNm() {
        return srTypeNm;
    }

    public void setSrTypeNm(String srTypeNm) {
        this.srTypeNm = srTypeNm;
    }

    public String getSysNm() {
        return sysNm;
    }

    public void setSysNm(String sysNm) {
        this.sysNm = sysNm;
    }

    public String getReqEmpNm() {
        return reqEmpNm;
    }

    public void setReqEmpNm(String reqEmpNm) {
        this.reqEmpNm = reqEmpNm;
    }

    public String getReqEmpDeptNm() {
        return reqEmpDeptNm;
    }

    public void setReqEmpDeptNm(String reqEmpDeptNm) {
        this.reqEmpDeptNm = reqEmpDeptNm;
    }

    public String getReqEmpEmail() {
        return reqEmpEmail;
    }

    public void setReqEmpEmail(String reqEmpEmail) {
        this.reqEmpEmail = reqEmpEmail;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getConfDataYn() {
        return confDataYn;
    }

    public void setConfDataYn(String confDataYn) {
        this.confDataYn = confDataYn;
    }

    public Date getTgtDttm() {
        return tgtDttm;
    }

    public void setTgtDttm(Date tgtDttm) {
        this.tgtDttm = tgtDttm;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getToAddress() {
        return toAddress;
    }

    public void setToAddress(String toAddress) {
        this.toAddress = toAddress;
    }



}
