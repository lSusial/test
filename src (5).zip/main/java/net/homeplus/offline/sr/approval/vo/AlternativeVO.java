package net.homeplus.offline.sr.approval.vo;


public class AlternativeVO {

    private String userId;
    private String alterEmpId;
    private String alterEmpNm;
    private String alterEmpEmail;

    private String alterDeptId;
    private String alterDeptNm;

    public String getAlterDeptId() {
        return alterDeptId;
    }

    public void setAlterDeptId(String alterDeptId) {
        this.alterDeptId = alterDeptId;
    }

    public String getAlterDeptNm() {
        return alterDeptNm;
    }

    public void setAlterDeptNm(String alterDeptNm) {
        this.alterDeptNm = alterDeptNm;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getAlterEmpId() {
        return alterEmpId;
    }

    public void setAlterEmpId(String alterEmpId) {
        this.alterEmpId = alterEmpId;
    }

    public String getAlterEmpNm() {
        return alterEmpNm;
    }

    public void setAlterEmpNm(String alterEmpNm) {
        this.alterEmpNm = alterEmpNm;
    }

    public String getAlterEmpEmail() {
        return alterEmpEmail;
    }

    public void setAlterEmpEmail(String alterEmpEmail) {
        this.alterEmpEmail = alterEmpEmail;
    }


}
