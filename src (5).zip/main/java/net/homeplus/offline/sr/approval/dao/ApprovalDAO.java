package net.homeplus.offline.sr.approval.dao;

import java.util.List;

import net.homeplus.offline.common.dao.CommonDAO;
import net.homeplus.offline.sr.approval.vo.AlternativeVO;
import net.homeplus.offline.sr.approval.vo.ApprovalHistVO;
import net.homeplus.offline.sr.approval.vo.ApprovalRuleVO;

import org.springframework.stereotype.Repository;

@Repository("ApprovalDAO")
public class ApprovalDAO extends CommonDAO {

    public List<ApprovalRuleVO> selectSRApprovalRule(ApprovalRuleVO vo) {
        return getSqlSession().selectList("Approval.selectSRApprovalRule", vo);
    }

    public void insertAprovalHist(ApprovalHistVO vo) {

        getSqlSession().insert("Approval.insertAprovalHist", vo);
    }

    public ApprovalHistVO selectNextApprovalInfo(String srId) {
        return getSqlSession().selectOne("Approval.selectNextApprovalInfo", srId);
    }

    public int updateApprovalHistStatus(ApprovalHistVO vo) {
        return getSqlSession().update("Approval.updateApprovalHistStatus", vo);
    }

    public List<ApprovalHistVO> selectSRApprovalHistListBySRId(String srId) {
        return getSqlSession().selectList("Approval.selectSRApprovalHistListBySRId", srId);
    }

    public int updateApprovalHist(ApprovalHistVO vo) {
        return getSqlSession().update("Approval.updateApprovalHist", vo);
    }

    public void insertAlternative(AlternativeVO vo) {
        getSqlSession().insert("Approval.insertAlternative", vo);
    }

    public void deleteAlternative(AlternativeVO vo) {
        getSqlSession().insert("Approval.deleteAlternative", vo);
    }

    public AlternativeVO selectAlternative(String userId) {
        return getSqlSession().selectOne("Approval.selectAlternative", userId);
    }

    public int updateApprovalHistToAlternative(AlternativeVO vo) {
        return getSqlSession().update("Approval.updateApprovalHistToAlternative", vo);
    }

    public int restoreApprovalHistToOrgin(AlternativeVO vo) {
        return getSqlSession().update("Approval.restoreApprovalHistToOrgin", vo);

    }

    public void rejectAllApprovalHist(ApprovalHistVO vo) {
        getSqlSession().update("Approval.rejectAllApprovalHist", vo);

    }



}
