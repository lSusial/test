package net.homeplus.offline.crontab.schedule;

import net.homeplus.offline.intergrate.service.IntergrateService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Scheduler {

    @Autowired
    private IntergrateService interfaceService;


    /** * 1. 오후 05:50:00에 호출이 되는 스케쥴러 */
    // @Scheduled(cron = "*/30 * * * * *")
    // public void cronTest1() {
    // interfaceService.getRTCList();
    // }

}
