package net.homeplus.offline.common.mail;

import javax.mail.internet.MimeMessage;

import net.homeplus.offline.sr.proc.vo.EmailVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import freemarker.template.Configuration;

@Component("EmailSender")
public class EmailSender {

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private Configuration freemarkerConfiguration;

    public boolean send(final EmailVO email) {
        boolean retVal = false;
        final String emailTo = "4susia@gmail.com";
        final String emailFrom = "testmail0826@gmail.com";
        final String subject = "test subject";
        final String message = "test";

        javaMailSender.send(new MimeMessagePreparator() {

            @Override
            public void prepare(MimeMessage paramMimeMessage) throws Exception {
                MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(paramMimeMessage, true, "UTF-8");

                mimeMessageHelper.setTo(emailTo);
                mimeMessageHelper.setFrom(emailFrom);
                mimeMessageHelper.setSubject(subject);

                String text = FreeMarkerTemplateUtils.processTemplateIntoString(freemarkerConfiguration.getTemplate("requestApproval.ftl", "UTF-8"), email);

                mimeMessageHelper.setText(text, true);


                /*
                 * mimeMessageHelper.addAttachment( MimeUtility.encodeText("filename"), new
                 * InputStreamSource() {
                 * 
                 * @Override public InputStream getInputStream() throws IOException { // TODO
                 * Auto-generated method stub return new FileInputStream(file); } });
                 */
            };
        });

        retVal = true;
        return retVal;
    }
}
