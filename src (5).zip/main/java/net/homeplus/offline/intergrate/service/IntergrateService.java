package net.homeplus.offline.intergrate.service;


public interface IntergrateService {

    public void getRTCList();

    public void getTicketList();


    public void insertSRInfoToRTC();

    public void updateSRInfoFromRTC();


}
