package net.homeplus.offline.intergrate.dao;

import javax.annotation.Resource;

import net.homeplus.offline.intergrate.vo.RTCPushVO;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.stereotype.Repository;

@Repository("IntergrateRTCDAO")
public class IntergrateRTCDAO extends SqlSessionDaoSupport {

    @Resource(name = "sqlSessionFactoryRTC")
    @Override
    public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
        super.setSqlSessionFactory(sqlSessionFactory);;

    }

    @Resource(name = "sqlSessionTemplateRTC")
    @Override
    public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
        super.setSqlSessionTemplate(sqlSessionTemplate);
    }

    public void insertSRtoRTCDB(RTCPushVO vo) {
        getSqlSession().insert("RTC.insertSRtoRTCDB", vo);
    }



}
