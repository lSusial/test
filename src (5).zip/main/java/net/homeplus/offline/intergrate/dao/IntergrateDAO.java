package net.homeplus.offline.intergrate.dao;

import java.util.List;

import net.homeplus.offline.common.dao.CommonDAO;
import net.homeplus.offline.intergrate.vo.RTCPushVO;
import net.homeplus.offline.intergrate.vo.RTCResultVO;

import org.springframework.stereotype.Repository;

@Repository("IntergrateDAO")
public class IntergrateDAO extends CommonDAO {

    public List<RTCPushVO> selectRTCSRList() {
        return getSqlSession().selectList("Intergrate.selectRTCSRList");
    }

    public void updateInterfaceYn(RTCPushVO vo) {
        getSqlSession().update("Intergrate.updateInterfaceYn", vo);
    }

    public List<RTCResultVO> selectRTCResult() {
        return getSqlSession().selectList("Intergrate.selectRTCResult");
    }

    public void updateSRWithRTCInfo(RTCResultVO vo) {
        getSqlSession().update("Intergrate.updateSRWithRTCInfo", vo);
    }

}
