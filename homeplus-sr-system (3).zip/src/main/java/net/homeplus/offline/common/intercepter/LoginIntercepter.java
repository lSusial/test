package net.homeplus.offline.common.intercepter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import net.homeplus.offline.common.vo.UserVO;

public class LoginIntercepter extends HandlerInterceptorAdapter {

    @Value("#{config['url.login']}")
    private String loginURL;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {


        HttpSession session = request.getSession(false);
        UserVO loginInfo = (UserVO) session.getAttribute("userInfo");

        if (session == null || loginInfo == null) {
            UserVO userVO = new UserVO();
            userVO.setUserId("test@homeplus.co.kr");
            userVO.setUserNm("테스터");
            userVO.setDeptId("9999");
            userVO.setDeptNm("시스템9");
            userVO.setEmail("test@homeplus.co.kr");
            session.setAttribute("userInfo", userVO);
        }

        // 틀림

        // TODO 앞에 로그인 할 수 있는 로직을 추가 하자
        boolean result = false;

        /*
         * try { HttpSession session = request.getSession(false);
         * 
         * if (session == null) { response.sendRedirect(loginURL); return false; } else {
         * 
         * UserVO userInfo = (UserVO) session.getAttribute("userInfo"); if (userInfo != null &&
         * userInfo.getUserId() != null) {
         * 
         * } else { response.sendRedirect(loginURL); return false; } } result = true; } catch
         * (Exception e) { e.printStackTrace(); return false; }
         */
        return true;
    }


}
