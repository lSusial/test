package net.homeplus.offline.common.constant;

public final class Constants {

    private Constants() {};

    public final class SRType {
        public static final String HARDWARE = "HW";
        public static final String SOFTWARE = "SW";

        private SRType() {};
    }
    
    public final class Code {
        
        public static final String SR_STATUS = "SRS";

        private Code() {};
    }

}
