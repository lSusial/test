package net.homeplus.offline.sr.view.vo;

import net.homeplus.offline.common.vo.BaseVO;

public class SystemVO extends BaseVO {

    private String sysId;
    private String sysNm;
    private String sysTpCd;
    private String sysDesc;
    private String sysDeptId;
    private String sysChrgEmpId;
    private String sysSubEmpId;
    private String dispOrd;
    private String useYn;


    public String getSysId() {
        return sysId;
    }

    public void setSysId(String sysId) {
        this.sysId = sysId;
    }

    public String getSysNm() {
        return sysNm;
    }

    public void setSysNm(String sysNm) {
        this.sysNm = sysNm;
    }

    public String getSysDesc() {
        return sysDesc;
    }

    public void setSysDesc(String sysDesc) {
        this.sysDesc = sysDesc;
    }

    public String getSysDeptId() {
        return sysDeptId;
    }

    public void setSysDeptId(String sysDeptId) {
        this.sysDeptId = sysDeptId;
    }

    public String getSysChrgEmpId() {
        return sysChrgEmpId;
    }

    public void setSysChrgEmpId(String sysChrgEmpId) {
        this.sysChrgEmpId = sysChrgEmpId;
    }

    public String getSysSubEmpId() {
        return sysSubEmpId;
    }

    public void setSysSubEmpId(String sysSubEmpId) {
        this.sysSubEmpId = sysSubEmpId;
    }

    public String getDispOrd() {
        return dispOrd;
    }

    public void setDispOrd(String dispOrd) {
        this.dispOrd = dispOrd;
    }

    public String getUseYn() {
        return useYn;
    }

    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }

    public String getSysTpCd() {
        return sysTpCd;
    }

    public void setSysTpCd(String sysTpCd) {
        this.sysTpCd = sysTpCd;
    }

    @Override
    public String toString() {
        return "SystemVO [sysId=" + sysId + ", sysNm=" + sysNm + ", sysTpCd=" + sysTpCd + ", sysDesc=" + sysDesc + ", sysDeptId=" + sysDeptId
                + ", sysChrgEmpId=" + sysChrgEmpId + ", sysSubEmpId=" + sysSubEmpId + ", dispOrd=" + dispOrd + ", useYn=" + useYn + "]";
    }



}
