package net.homeplus.offline.sr.view.controller;

import java.util.List;

import net.homeplus.offline.common.code.service.CommonCodeService;
import net.homeplus.offline.common.code.vo.CodeVO;
import net.homeplus.offline.common.constant.Constants;
import net.homeplus.offline.common.vo.UserVO;
import net.homeplus.offline.sr.approval.service.ApprovalService;
import net.homeplus.offline.sr.approval.vo.ApprovalRuleVO;
import net.homeplus.offline.sr.view.service.ViewService;
import net.homeplus.offline.sr.view.vo.SRViewVO;
import net.homeplus.offline.sr.view.vo.SystemVO;
import net.homeplus.offline.sr.view.vo.TypeVO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class SRViewController {

    @Autowired
    private ViewService viewService;
    @Autowired
    private ApprovalService approvalService;
    @Autowired
    private CommonCodeService commonCodeService;


    // @Autowired
    // private EmailSender emailSender;



    @RequestMapping("/sr/list.do")
    public ModelAndView getSRList(ModelAndView mav) {


        List<TypeVO> typeList = viewService.selectTypeList(Constants.SRType.SOFTWARE);
        List<CodeVO> statusList = commonCodeService.selectCommonCodeListByGroupId(Constants.Code.SR_STATUS);

        mav.addObject("typeList", typeList);
        mav.addObject("statusList", statusList);
        // mav.addObject(srList);
        //
        mav.setViewName("sr/list");
        return mav;

        // mav.setVie);
        /*
         * List<SRViewVO> list = srViewService.selectSRList();
         * 
         * for (SRViewVO vo : list) { System.out.println(vo.toString()); }
         */
        // emailSender.send();

    }

    @RequestMapping("/sr/detail.do")
    public ModelAndView selectSRDetail(String srId, ModelAndView mav) {

        System.out.println("ddddddddddddddddddddddddddddddddddddddddddddddd");
        List<TypeVO> typeList = viewService.selectTypeList(Constants.SRType.SOFTWARE);
        List<SystemVO> systemList = viewService.selectSystemList(Constants.SRType.SOFTWARE);

        mav.addObject("typeList", typeList);
        mav.addObject("systemList", systemList);

        mav.setViewName("sr/detail");

        return mav;


        // 파일 서비스 파일 권한 관련은 어떻게 하나

    }

    @RequestMapping(value = "/sr/regist.do", method = RequestMethod.GET)
    public ModelAndView registView(ModelAndView mav) {

        // SR 구분

        List<TypeVO> typeList = viewService.selectTypeList(Constants.SRType.SOFTWARE);
        List<SystemVO> systemList = viewService.selectSystemList(Constants.SRType.SOFTWARE);

        mav.addObject("typeList", typeList);
        mav.addObject("systemList", systemList);

        mav.setViewName("sr/regist");

        return mav;
    }



    @RequestMapping(value = "/json/searchEmp.json")
    @ResponseBody
    public List<UserVO> selectEmpList(@RequestParam String searchWord) {
        List<UserVO> empList = viewService.selectEmpList(searchWord);
        return empList;
    }


    @RequestMapping(value = "/json/searchITApprovalRule.json")
    @ResponseBody
    public List<ApprovalRuleVO> selectApprovalLine(ApprovalRuleVO ruleVO) {
        System.out.println(ruleVO);
        List<ApprovalRuleVO> approvalLine = approvalService.selectSRApprovalRule(ruleVO);
        return approvalLine;

    }

    @RequestMapping(value = "/sr/getSystemList.json")
    @ResponseBody
    public List<SystemVO> selectSystemListByType(ModelAndView mav) {
        // 등록자 정보
        // SR 구분
        List<SystemVO> systemList = viewService.selectSystemList(Constants.SRType.SOFTWARE);
        return systemList;

    }

    @RequestMapping(value = "/json/test.json")
    @ResponseBody
    public List<TypeVO> selectTypeList(ModelAndView mav) {
        List<TypeVO> systemList = viewService.selectTypeList("SW");
        return systemList;

    }

    @RequestMapping(value = "/sr/registSR.do", method = RequestMethod.POST)
    public void registSR(SRViewVO vo) {

        System.out.println(vo);
        /*
         * 
         * 인풋 SR 정보 결제선 정보 파일 정보
         * 
         * 뒤에 할일 결제 ㄱㄱ 없는거는 바로 파일 저장
         */


        // 파일 서비스 파일 권한 관련은 어떻게 하나

    }



    @RequestMapping("/test.do")
    public String test(ModelAndView mav) {
        return "test/test";
    }

    @RequestMapping("/test2.do")
    public String tes2t() {
        return "test/test2";
    }


    @RequestMapping("/getSRList.do")
    @ResponseBody
    public List<SRViewVO> getSRList() {

        // TODO SR 목록 보여주는 거

        // 자신이 올린거
        // 결제 목록이 온거 조인이 필요

        return null;
    }


    @RequestMapping("/getSRListJson.do")
    @ResponseBody
    public List<SRViewVO> getSRListJson() {

        // TODO SR 목록 보여주는 거


        return null;
    }

}
