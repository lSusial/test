package net.homeplus.offline.sr.view.vo;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

public class SRViewVO2 {
    private String sdId; // Smart Desk ID
    private String reqBizLocCd; // 구분 > 사업장코드
    private String reqBizLoc; // 구분 > 사업장명
    private String reqSvcType; // 서비스구분(Insert시 화면에서 값 받지 않고 ServiceImpl에서 값 세팅해줌)
    private String reqSystemCd;// 구분 > 시스템
    private String reqSystem; // 구분 > 시스템명
    private String reqType; // 구분 > 유형
    private String reqTitle; // 제목
    private String reqName; // 이름
    private String reqTgtDate; // 완료희망일
    private String reqEmail; // 메일
    private String reqDept; // 부서
    private String reqTelno; // 전화번호
    private String reqDesc; // 내용
    private String entName; // 등록자 이름
    private String entDate; // 등록일
    private String appName; // 승인자 이름
    private String appDate; // 승인일
    private String itAppName; // IT 승인자 이름
    private String itAppDate; // IT 승인일
    private String wkName; // 처리자 이름
    private String wkDate; // 처리일
    private String wkDesc; // 처리내용(답변내용)
    private String secTrfYn; // 2차이관 여부
    private String othTrfYn; // 타사이관 여부
    private String rtcProjNm; // 전송대상 RTC 프로젝트명 -> IBM관리여부(TB_SYSMANAGER 테이블의 IBM_YN과 같은 값)

    private String wkStatus; // 진행상태 코드
    private String wkStatusName;// 진행상태 명

    private String fileDir; // 첨부파일 경로
    private String fileCnt; // 첨부파일 갯수
    private String rtcSndCd; // RTC 전송상태 코드
    private String rtcSndDate; // RTC 전송완료 일시
    private String gwSndCd; // GW 전송상태 코드
    private String gwSndDate; // GW 전송완료 일시
    private String gwId; // GW ID
    private String mailYn; // 메일발송여부
    private String etc1; // 예비 1
    private String etc2; // 예비 2
    private String etc3; // 예비 3

    // BaseVo 상속
    // private String reqDate; // 요청일
    // private String regDate; // 생성일시
    // private String updDate; // 수정일시

    // 목록 조회 (검색용)
    private String entDateFrom; // 등록 시작일
    private String entDateTo; // 등록 종료일
    private String wkStatusTab;// 탭 페이지
    private int rowPerPage; // 한 페이지당 데이터 갯수

    // 처리폼
    private String actionStatus; // 조치 상태
    private String fileName; // 파일명

    // 업로드 파일 (일반파일)
    private List<MultipartFile> files;

    // GW 승인 여부 판단
    private String gwYn;

    // 권한그룹
    private String authGroup;

    // 그룹웨어 기안요청 결과 Y:성공, N:취소/실패
    private String gwStatus;

    // 그룹웨어 파일 업로드시 사용 하기 위함
    private String gwSdIdRef;

    public String getSdId() {
        return sdId;
    }

    public void setSdId(String sdId) {
        this.sdId = sdId;
    }

    public String getReqBizLocCd() {
        return reqBizLocCd;
    }

    public void setReqBizLocCd(String reqBizLocCd) {
        this.reqBizLocCd = reqBizLocCd;
    }

    public String getReqBizLoc() {
        return reqBizLoc;
    }

    public void setReqBizLoc(String reqBizLoc) {
        this.reqBizLoc = reqBizLoc;
    }

    public String getReqSvcType() {
        return reqSvcType;
    }

    public void setReqSvcType(String reqSvcType) {
        this.reqSvcType = reqSvcType;
    }

    public String getReqSystemCd() {
        return reqSystemCd;
    }

    public void setReqSystemCd(String reqSystemCd) {
        this.reqSystemCd = reqSystemCd;
    }

    public String getReqSystem() {
        return reqSystem;
    }

    public void setReqSystem(String reqSystem) {
        this.reqSystem = reqSystem;
    }

    public String getReqType() {
        return reqType;
    }

    public void setReqType(String reqType) {
        this.reqType = reqType;
    }

    public String getReqTitle() {
        return reqTitle;
    }

    public void setReqTitle(String reqTitle) {
        this.reqTitle = reqTitle;
    }

    public String getReqName() {
        return reqName;
    }

    public void setReqName(String reqName) {
        this.reqName = reqName;
    }

    public String getReqTgtDate() {
        return reqTgtDate;
    }

    public void setReqTgtDate(String reqTgtDate) {
        this.reqTgtDate = reqTgtDate;
    }

    public String getReqEmail() {
        return reqEmail;
    }

    public void setReqEmail(String reqEmail) {
        this.reqEmail = reqEmail;
    }

    public String getReqDept() {
        return reqDept;
    }

    public void setReqDept(String reqDept) {
        this.reqDept = reqDept;
    }

    public String getReqTelno() {
        return reqTelno;
    }

    public void setReqTelno(String reqTelno) {
        this.reqTelno = reqTelno;
    }

    public String getReqDesc() {
        return reqDesc;
    }

    public void setReqDesc(String reqDesc) {
        this.reqDesc = reqDesc;
    }

    public String getEntName() {
        return entName;
    }

    public void setEntName(String entName) {
        this.entName = entName;
    }

    public String getEntDate() {
        return entDate;
    }

    public void setEntDate(String entDate) {
        this.entDate = entDate;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppDate() {
        return appDate;
    }

    public void setAppDate(String appDate) {
        this.appDate = appDate;
    }

    public String getItAppName() {
        return itAppName;
    }

    public void setItAppName(String itAppName) {
        this.itAppName = itAppName;
    }

    public String getItAppDate() {
        return itAppDate;
    }

    public void setItAppDate(String itAppDate) {
        this.itAppDate = itAppDate;
    }

    public String getWkName() {
        return wkName;
    }

    public void setWkName(String wkName) {
        this.wkName = wkName;
    }

    public String getWkDate() {
        return wkDate;
    }

    public void setWkDate(String wkDate) {
        this.wkDate = wkDate;
    }

    public String getWkDesc() {
        return wkDesc;
    }

    public void setWkDesc(String wkDesc) {
        this.wkDesc = wkDesc;
    }

    public String getSecTrfYn() {
        return secTrfYn;
    }

    public void setSecTrfYn(String secTrfYn) {
        this.secTrfYn = secTrfYn;
    }

    public String getOthTrfYn() {
        return othTrfYn;
    }

    public void setOthTrfYn(String othTrfYn) {
        this.othTrfYn = othTrfYn;
    }

    public String getRtcProjNm() {
        return rtcProjNm;
    }

    public void setRtcProjNm(String rtcProjNm) {
        this.rtcProjNm = rtcProjNm;
    }

    public String getWkStatus() {
        return wkStatus;
    }

    public void setWkStatus(String wkStatus) {
        this.wkStatus = wkStatus;
    }

    public String getWkStatusName() {
        return wkStatusName;
    }

    public void setWkStatusName(String wkStatusName) {
        this.wkStatusName = wkStatusName;
    }

    public String getFileDir() {
        return fileDir;
    }

    public void setFileDir(String fileDir) {
        this.fileDir = fileDir;
    }

    public String getFileCnt() {
        return fileCnt;
    }

    public void setFileCnt(String fileCnt) {
        this.fileCnt = fileCnt;
    }

    public String getRtcSndCd() {
        return rtcSndCd;
    }

    public void setRtcSndCd(String rtcSndCd) {
        this.rtcSndCd = rtcSndCd;
    }

    public String getRtcSndDate() {
        return rtcSndDate;
    }

    public void setRtcSndDate(String rtcSndDate) {
        this.rtcSndDate = rtcSndDate;
    }

    public String getGwSndCd() {
        return gwSndCd;
    }

    public void setGwSndCd(String gwSndCd) {
        this.gwSndCd = gwSndCd;
    }

    public String getGwSndDate() {
        return gwSndDate;
    }

    public void setGwSndDate(String gwSndDate) {
        this.gwSndDate = gwSndDate;
    }

    public String getGwId() {
        return gwId;
    }

    public void setGwId(String gwId) {
        this.gwId = gwId;
    }

    public String getMailYn() {
        return mailYn;
    }

    public void setMailYn(String mailYn) {
        this.mailYn = mailYn;
    }

    public String getEtc1() {
        return etc1;
    }

    public void setEtc1(String etc1) {
        this.etc1 = etc1;
    }

    public String getEtc2() {
        return etc2;
    }

    public void setEtc2(String etc2) {
        this.etc2 = etc2;
    }

    public String getEtc3() {
        return etc3;
    }

    public void setEtc3(String etc3) {
        this.etc3 = etc3;
    }

    public String getEntDateFrom() {
        return entDateFrom;
    }

    public void setEntDateFrom(String entDateFrom) {
        this.entDateFrom = entDateFrom;
    }

    public String getEntDateTo() {
        return entDateTo;
    }

    public void setEntDateTo(String entDateTo) {
        this.entDateTo = entDateTo;
    }

    public String getWkStatusTab() {
        return wkStatusTab;
    }

    public void setWkStatusTab(String wkStatusTab) {
        this.wkStatusTab = wkStatusTab;
    }

    public int getRowPerPage() {
        return rowPerPage;
    }

    public void setRowPerPage(int rowPerPage) {
        this.rowPerPage = rowPerPage;
    }

    public String getActionStatus() {
        return actionStatus;
    }

    public void setActionStatus(String actionStatus) {
        this.actionStatus = actionStatus;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public List<MultipartFile> getFiles() {
        return files;
    }

    public void setFiles(List<MultipartFile> files) {
        this.files = files;
    }

    public String getGwYn() {
        return gwYn;
    }

    public void setGwYn(String gwYn) {
        this.gwYn = gwYn;
    }

    public String getAuthGroup() {
        return authGroup;
    }

    public void setAuthGroup(String authGroup) {
        this.authGroup = authGroup;
    }

    public String getGwStatus() {
        return gwStatus;
    }

    public void setGwStatus(String gwStatus) {
        this.gwStatus = gwStatus;
    }

    public String getGwSdIdRef() {
        return gwSdIdRef;
    }

    public void setGwSdIdRef(String gwSdIdRef) {
        this.gwSdIdRef = gwSdIdRef;
    }

    @Override
    public String toString() {
        return "SRListVO [sdId=" + sdId + ", reqBizLocCd=" + reqBizLocCd + ", reqBizLoc=" + reqBizLoc + ", reqSvcType=" + reqSvcType + ", reqSystemCd="
                + reqSystemCd + ", reqSystem=" + reqSystem + ", reqType=" + reqType + ", reqTitle=" + reqTitle + ", reqName=" + reqName + ", reqTgtDate="
                + reqTgtDate + ", reqEmail=" + reqEmail + ", reqDept=" + reqDept + ", reqTelno=" + reqTelno + ", reqDesc=" + reqDesc + ", entName=" + entName
                + ", entDate=" + entDate + ", appName=" + appName + ", appDate=" + appDate + ", itAppName=" + itAppName + ", itAppDate=" + itAppDate
                + ", wkName=" + wkName + ", wkDate=" + wkDate + ", wkDesc=" + wkDesc + ", secTrfYn=" + secTrfYn + ", othTrfYn=" + othTrfYn + ", rtcProjNm="
                + rtcProjNm + ", wkStatus=" + wkStatus + ", wkStatusName=" + wkStatusName + ", fileDir=" + fileDir + ", fileCnt=" + fileCnt + ", rtcSndCd="
                + rtcSndCd + ", rtcSndDate=" + rtcSndDate + ", gwSndCd=" + gwSndCd + ", gwSndDate=" + gwSndDate + ", gwId=" + gwId + ", mailYn=" + mailYn
                + ", etc1=" + etc1 + ", etc2=" + etc2 + ", etc3=" + etc3 + ", entDateFrom=" + entDateFrom + ", entDateTo=" + entDateTo + ", wkStatusTab="
                + wkStatusTab + ", rowPerPage=" + rowPerPage + ", actionStatus=" + actionStatus + ", fileName=" + fileName + ", files=" + files + ", gwYn="
                + gwYn + ", authGroup=" + authGroup + ", gwStatus=" + gwStatus + ", gwSdIdRef=" + gwSdIdRef + "]";
    }



}
