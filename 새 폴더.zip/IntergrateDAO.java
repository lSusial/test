package net.homeplus.offline.intergrate.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import net.homeplus.offline.common.dao.CommonDAO;
import net.homeplus.offline.intergrate.vo.FilePushVO;
import net.homeplus.offline.intergrate.vo.PushVO;
import net.homeplus.offline.intergrate.vo.RTCResultVO;
import net.homeplus.offline.intergrate.vo.TicketResultVO;

@Repository("IntergrateDAO")
public class IntergrateDAO extends CommonDAO {

    public List<PushVO> selectRTCSRList() {
        return getSqlSession().selectList("Intergrate.selectRTCSRList");
    }

    public List<RTCResultVO> selectRTCResult() {
        return getSqlSession().selectList("Intergrate.selectRTCResult");
    }

    public void updateSRWithRTCInfo(RTCResultVO vo) {
        getSqlSession().update("Intergrate.updateSRWithRTCInfo", vo);
    }



    public List<PushVO> selectTicketSRList() {
        return getSqlSession().selectList("Intergrate.selectTicketSRList");
    }

    public List<TicketResultVO> selectTicketResult() {
        return getSqlSession().selectList("Intergrate.selectTicketResult");
    }

    public void updateSRWithTicketInfo(TicketResultVO vo) {
        getSqlSession().update("Intergrate.updateSRWithTicketInfo", vo);
    }



    public void updateInterfaceYn(PushVO vo) {
        getSqlSession().update("Intergrate.updateInterfaceYn", vo);
    }

    public List<FilePushVO> selectFileListBySrId(String srId) {
        return getSqlSession().selectList("Intergrate.selectFileListBySrId", srId);
    }

}
