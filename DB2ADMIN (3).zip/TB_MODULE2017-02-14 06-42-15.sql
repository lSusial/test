SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_MODULE (
  MOD_ID	VARCHAR(15)	NOT NULL,
  SYS_ID	VARCHAR(20)	NOT NULL,
  MOD_NM	VARCHAR(100),
  MOD_DESC	VARCHAR(300),
  MOD_CHRG_EMP_ID	VARCHAR(100),
  MOD_CHRG_DEPT_ID	VARGRAPHIC(50),
  CRT_ID	VARCHAR(14),
  CRT_DTTM	TIMESTAMP,
  LAST_MOD_ID	VARCHAR(10),
  LAST_MOD_DTTM	TIMESTAMP
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_MODULE
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_MODULE
  ADD PRIMARY KEY
    (MOD_ID, SYS_ID)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_MODULE
	ALLOW WRITE ACCESS;



insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('MOD001','SYS001','모듈1-1',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('MOD002','SYS001','모듈1-2',null,'test12@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('MOD003','SYS001','모듈1-3',null,'test13@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('MOD004','SYS002','모듈2-1',null,'test14@homeplus.co.kr','DEPT_002',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('MOD005','SYS002','모듈2-2',null,'test15@homeplus.co.kr','DEPT_002',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010010','110010','본체',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010020','110010','체커용모니터',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010030','110010','고객용모니터',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010040','110010','키보드',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010050','110010','사인패드',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010060','110010','건스캐너',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010070','110010','고정스캐너',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010080','110010','금전함',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010090','110010','프린터',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110010100','110010','Program Error (S/W)',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110020010','110020','본체',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110020020','110020','건스캐너',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110020030','110020','고정스캐너',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110020040','110020','사인패드',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110020050','110020','금전함',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110020060','110020','Program Error (S/W)',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110030010','110030','NMPOS',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110030020','110030','UMPOS',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110030030','110030','UMPOS2',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110030040','110030','UMPOS3',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110040010','110040','H/W',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('110040020','110040','S/W',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('150010010','150010','본체',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('150010020','150010','모니터',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('150010030','150010','노트북',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('150010040','150010','프린터',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
insert into "TB_MODULE"("MOD_ID","SYS_ID","MOD_NM","MOD_DESC","MOD_CHRG_EMP_ID","MOD_CHRG_DEPT_ID","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('150020010','150020','Window 설정, Program Error',null,'test11@homeplus.co.kr','DEPT_001',null,null,null,null);
