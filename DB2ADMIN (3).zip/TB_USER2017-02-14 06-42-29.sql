SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_USER (
  USER_ID	VARCHAR(100)	NOT NULL,
  USER_NM	VARCHAR(15),
  DEPT_ID	VARCHAR(10),
  LEVEL_CD	VARCHAR(10),
  GUBUN	VARCHAR(10),
  EMAIL	VARCHAR(100),
  CREATE_DATE	VARCHAR(10)
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_USER
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_USER
  ADD PRIMARY KEY
    (USER_ID)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_USER
	ALLOW WRITE ACCESS;



insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test1@homeplus.co.kr','홍길동1','DEPT_001','30000','ST','test1@homeplus.co.kr','');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test2@homeplus.co.kr','홍길동2','DEPT_001','30000','ST','test2@homeplus.co.kr','');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test3@homeplus.co.kr','홍길동3','DEPT_001','30000','ST','test3@homeplus.co.kr','');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test4@homeplus.co.kr','홍길동4','DEPT_002','30000','ST','test4@homeplus.co.kr','');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test5@homeplus.co.kr','홍길동5','DEPT_002','30000','ST','test5@homeplus.co.kr','');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test6@homeplus.co.kr','홍길동6','DEPT_003','30000','ST','test6@homeplus.co.kr','');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test7@homeplus.co.kr','홍길동7','DEPT_002','30000','ST','test7@homeplus.co.kr',null);
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test11@homeplus.co.kr','홍길동11','DEPT_011','30000','ST','test11@homeplus.co.kr','');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test12@homeplus.co.kr','홍길동12','DEPT_011','30000','ST','test12@homeplus.co.kr','');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test13@homeplus.co.kr','홍길동13','DEPT_011','30000','ST','test13@homeplus.co.kr','');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test14@homeplus.co.kr','홍길동14','DEPT_012','30000','ST','test14@homeplus.co.kr','');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test15@homeplus.co.kr','홍길동15','DEPT_012','30000','ST','test15@homeplus.co.kr','');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test16@homeplus.co.kr','홍길동16','DEPT_013','30000','ST','test16@homeplus.co.kr','');
insert into "TB_USER"("USER_ID","USER_NM","DEPT_ID","LEVEL_CD","GUBUN","EMAIL","CREATE_DATE") values ('test17@homeplus.co.kr','홍길동17','DEPT_012','30000','ST','test17@homeplus.co.kr',null);
