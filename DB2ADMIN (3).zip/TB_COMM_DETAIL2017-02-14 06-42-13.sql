SET CURRENT SCHEMA DB2ADMIN;

-- Step 1. Sync
CREATE TABLE DB2ADMIN.TB_COMM_DETAIL (
  CD_GRP_ID	VARCHAR(10)	NOT NULL,
  CD_ID	VARCHAR(10)	NOT NULL,
  CD_NM	VARCHAR(50),
  ATTR1	VARCHAR(10),
  ATTR2	VARCHAR(10),
  ATTR3	VARGRAPHIC(10),
  USE_YN	VARCHAR(10)	NOT NULL,
  CRT_ID	VARCHAR(10),
  CRT_DTTM	TIMESTAMP,
  LAST_MOD_ID	INTEGER,
  LAST_MOD_DTTM	TIMESTAMP
  ) 
  IN USERSPACE1
  ORGANIZE BY ROW;

ALTER TABLE DB2ADMIN.TB_COMM_DETAIL
  DATA CAPTURE NONE
  PCTFREE 0
  LOCKSIZE ROW
  APPEND OFF
  NOT VOLATILE;

-- Step 2. Restoring constraints and indexes
ALTER TABLE DB2ADMIN.TB_COMM_DETAIL
  ADD PRIMARY KEY
    (CD_GRP_ID, CD_ID)
    ENFORCED;

COMMIT;

-- Step 3. Runstats
RUNSTATS ON TABLE DB2ADMIN.TB_COMM_DETAIL
	ALLOW WRITE ACCESS;



insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SRS','010','접수',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SRS','020','결재중',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SRS','030','처리중',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SRS','040','완료',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SRS','042','반려',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('HWCAT','100','POS 운영',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('HWCAT','110','POS 장비',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('HWCAT','120','RtoC',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('HWCAT','130','OA PC',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('HWCAT','140','재고용PDA',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('HWCAT','150','전자저울',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('HWCAT','160','네트워크',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('HWCAT','170','KIOSK',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SWCAT','100','상품',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SWCAT','110','SCM',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SWCAT','120','물류',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SWCAT','130','SRD',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SWCAT','140','재무',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SWCAT','150','리포트',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SWCAT','160','Small Format',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SWCAT','180','점포',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SWCAT','190','재무',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SWCAT','200','마케팅',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SWCAT','210','인사',null,null,null,'Y',null,null,null,null);
insert into "TB_COMM_DETAIL"("CD_GRP_ID","CD_ID","CD_NM","ATTR1","ATTR2","ATTR3","USE_YN","CRT_ID","CRT_DTTM","LAST_MOD_ID","LAST_MOD_DTTM") values ('SWCAT','220','서비스상품',null,null,null,'Y',null,null,null,null);
