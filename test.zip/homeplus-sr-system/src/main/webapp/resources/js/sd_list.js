/**
 * Smart Desk Javascript
 */

/****************************************
 * 글로벌 변수 선언
 ****************************************/
var G_TIMER;

/****************************************
 * 세션 시간 세팅
 ****************************************/
function setTimer(){
	G_TIMER = setTimeout(function () { fnCheckSession() }, G_INTERVAL_TIME);
}

function startTimer() {
	setTimer();
}

function clearTimer() {
	clearTimeout(G_TIMER);
}

/****************************************
 * 세션체크
 ****************************************/
function fnCheckSession(){
	$.ajax({
		type : "post",
		url : "checkSession.sd",
		dataType : "json",
		contentType : "application/json; charset=utf-8",
		data : "",
		success : function(result){
			if(result.status == "9999"){
				alert("세션이 만료되어 로그인 화면으로 이동합니다.");
				
				// redirect 화면으로 이동
				var urlParam = "/redirectlogin.sd";
				window.location = urlParam;
			}
		},
		error : function(result){
			alert("통신 에러가 발생 하였습니다. \n관리자에게 문의 하세요.");
		}
	});
}

/****************************************
 * 페이지 로딩 시 onload 함수 호출
 * 참고 : <body onload=""> 함수와 같이 쓸 수 없음
 ****************************************/
window.onload = function () {
	fnOnload();
}


/****************************************
 * Date range Picker Onload 
 ****************************************/
function fnDateRange(){
	$('#entDate').daterangepicker({
		timePickerIncrement: 1,
	    startDate: getCalcDate(-15, new Date()),
	    endDate: new Date(),
	    opens: "left",
	    drops: "down",
	    buttonClasses: "btn btn-sm",
	    applyClass: "btn-success",
	    cancelClass: "btn-default",
	    locale: {
	    	format: 'YYYY-MM-DD'
	    }
	}, function(start, end, label) {
		console.log("New date range selected: ' + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD') + ' (predefined range: ' + label + ')");
	});
}

/****************************************
 * Form Onload 
 ****************************************/
function fnOnload(){

	fnDateRange();		// 달력 컴포넌트 초기화	
	fnSearchType();		// 공통코드 002 : 유형 조회
	
	// 처음 로딩 시 전체 탭 자동 선택
	document.getElementById("wkStatusTab0").style.color = "#FFFFFF";
	document.getElementById("wkStatusTab0").style.background = "#9D8A69";

	fnBtnOnclick();
}

/****************************************
 * Form to Json 형태 변환 
 ****************************************/
function objToJson(formData){
	var data = formData;
	var obj = {};
	
	$.each(data, function(idx, ele){
		obj[ele.name] = ele.value;
	});

	return obj;
}

/****************************************
 * Form Validation (조회 Form)
 ****************************************/
function fnCheckForm(){
	// 시작 요청일
	if($("#entDateFrom").val() == ""){
		alert("시작 요청일을 입력하세요.");
		$("#entDateFrom").focus();
		return false;
	}

	// 종료 요청일
	if($("#entDateTo").val() == ""){
		alert("종료 요청일을 입력하세요.");
		$("#entDateTo").focus();
		return false;
	}
	
	/**
	 * 필수조건 세팅 
	 */
	// 처리자명 필드에 담기
	document.formSearch.wkName.value = $("#sessionUserName").val();
	// 접속자명 필드에 담기
	document.formSearch.entName.value = $("#sessionUserName").val();

	// 한 페이지당 개수에 값이 없을 경우
	if($("#rowPerPage").val() == ""){
		$("#rowPerPage").val(10);
		document.getElementById("page10").style.color = "#FFFFFF";
		document.getElementById("page10").style.fontWeight = "bold";
		document.getElementById("page10").style.backgroundColor = "#9D8A69";
	}
	
	return true;
}

/****************************************
 * Smart Desk 목록 조회 
 * Button Click 이벤트 처리(조회 초기화)
 ****************************************/
function fnBtnOnclick(){
	$("#selectedPageNum").val(1);				// 첫 페이지로 세팅
	
	// 폼 체크 후 조회
	if(fnCheckForm() == true){
		fnSearch();
	}
}

/****************************************
 * 그리드 위의 상태 탭 클릭
 ****************************************/
function fnStatusTabOnclick(event){
	var statusTabId = (event.target) ? event.target.id : event.srcElement.id;

	var filed = new Array('wkStatusTab0','wkStatusTab1','wkStatusTab2','wkStatusTab3','wkStatusTab4','wkStatusTab5');	
	
	for (i=0; i<filed.length; i++){
		// 선택한 탭
		if(statusTabId == filed[i]){
			document.getElementById(filed[i]).style.color = "#FFFFFF";
			document.getElementById(filed[i]).style.background = "#9D8A69";
		}
		// 선택하지 않은 탭
		else{
			document.getElementById(filed[i]).style.color = "#333333";
			document.getElementById(filed[i]).style.background = "#EEEADB";
		}
	}
	
	// 탭 페이지를 넘김(제일 마지막자리 숫자만)
	$("#wkStatusTab").val(statusTabId.substr(statusTabId.length-1,1));
	
	// 목록 메뉴 클릭 시 또는 등록 후 자동조회
	fnBtnOnclick();
}

/****************************************
 * rowPerPage 값을 form에 담기
 ****************************************/
function fnRowPerPageOnclick(event){
	var rowPerPageId = (event.target) ? event.target.id : event.srcElement.id;
	
	// 선택한 페이지 값 세팅
	$("#rowPerPage").val(rowPerPageId.substring(4,6));
	
	var filed = new Array('page10','page15','page20','page30');	
	
	for (i=0; i<filed.length; i++){
		// 선택한 개수
		if(rowPerPageId == filed[i]){
			document.getElementById(filed[i]).style.color = "#FFFFFF";
			document.getElementById(filed[i]).style.fontWeight = "bold";
			document.getElementById(filed[i]).style.backgroundColor = "#9D8A69";
		}
		// 선택하지 않은 개수
		else{
			document.getElementById(filed[i]).style.color = "#1B0000";
			document.getElementById(filed[i]).style.fontWeight = "bold";
			document.getElementById(filed[i]).style.backgroundColor = "#EEEADB";
		}
	}
	
	fnBtnOnclick();
}

/****************************************
 * Smart Desk 목록 조회 
 * Ajax 처리
 ****************************************/
function fnSearch(){
	var objJson = JSON.stringify(objToJson($("#formSearch").serializeArray()));
	
	$.ajax({
		type : "post",
		url : "listSearch.sd",
		dataType : "json",
		data : objJson,
		contentType : "application/json; charset=utf-8",
		success : function(result){
				if(result.status == "9999"){
					alert("로그인 되어 있지 않습니다. \n로그인 후 이용하세요.");
					var urlParam = "/redirectlogin.sd";
					window.location = urlParam;
					
				}
				else{
					fnPrintGrid(result);
				}
		},
		// 로딩 이미지 출력
		beforeSend : function(){
			// beforeSend, complete 의 경우 async(true) 경우 작동 되는듯 
			// async(false)인 경우 call 안됨(ie, safari)
			$('.wrap-loading').removeClass('display-none');
		},
		// 로딩 이미지 숨김
		complete : function(){
			$('.wrap-loading').addClass('display-none');
		},
		error : function(result){
			alert("통신 에러가 발생 하였습니다. \n관리자에게 문의 하세요.");
		}
	})
	// success 응답을 받은 경우에만 호출
	.done(function(){
		clearTimer();
		startTimer();
	});
}


/****************************************
 * Smart Desk 목록 출력 
 * param : result 결과 Object
 ****************************************/
function fnPrintGrid(result){
	var length = result.sdList.length;
	$("#sdListBody").empty();
	var appendData = "";
	
	// 데이터 조회된 길이를 체크하여 데이터 없는 경우 아래와 같은 메시지를 표에 표시
	// '조회된 데이터가 없습니다.'
	if(parseInt(length) > 0){
		
		for(var i=0 ; i<length ; i++){
			var sdId = result.sdList[i].sdId;					// 요청번호
	        var reqTitle = result.sdList[i].reqTitle;			// 제목
	        var wkStatusName = result.sdList[i].wkStatusName;	// 진행상태
	        var entDate = result.sdList[i].entDate;				// 등록일
	        var entName = result.sdList[i].entName;				// 등록자
	        var wkDate = result.sdList[i].wkDate;				// 처리일
	        var wkName = result.sdList[i].wkName;				// 처리자
	        
	        appendData += "<tr>";
	        appendData += "<td class='text-center'>"+sdId+"</td>";
	        appendData += "<td style='cursor:pointer;' onclick=\"fn_sdModify('"+sdId+"');\">"+reqTitle+"</td>";
	        appendData += "<td class='text-center'>"+wkStatusName+"</td>";
	        appendData += "<td class='text-center'>"+entName+"</td>";
	        appendData += "<td class='text-center'>"+entDate+"</td>";
	        appendData += "<td class='text-center'>"+wkName+"</td>";
	        appendData += "<td class='text-center'>"+wkDate+"</td>";
	        appendData += "</tr>";
		}
		
		// Table에 조회 데이터 입력
	    $("#sdListBody").append(appendData);
	    fnPage(result);
	    
	}else{
		// Paging 처리 초기화(삭제)
		$("#pageNav").empty();
		appendData = "<tr style='background-color:#F9F9F9'>";
		appendData += "<th colspan='7' class='text-center'>";
		appendData += "조회된 데이터가 없습니다.";
		appendData += "</th>";
		appendData += "</tr>";
		
		// 조회된 데이터 없음 메시지 출력
		$("#sdListBody").append(appendData);
		
		// Paging 처리 입력
		$("#pageNav").append("<strong>1</strong>");
		
	}
 }
 
/****************************************
 * Smart Desk 목록 조회 
 * Page 처리
 * param : result 결과 Object
 ****************************************/
function fnPage(result){
	$("#pageNav").empty();					// page 처리 번호 reset
	
	var rowPerPage = $("#rowPerPage").val();
	var appendData = "";					// Table에 그릴 내용 Append Data
	var curPageAppend = "";
	
	var len = result.sdList.length;			// List 길이
	
	var curPage;							// 현재 Page 번호
	
	var prtPageNo = 0;						// 화면에 보여져야 할 Page 번호 (max)
	var tempPageNo =0;						// 현재 보여야 할 page 번호
	var initPageNo = 0;						// 현재 보여야 할 임시 page 번호
	
	// List 길이가 1개라도 있으면 페이지 번호 출력
	if(len > 0){
		curPage = result.tbSdrtcVO.curPageNo;		// 현재 page 번호를 저장
		//alert("curPage : " + curPage);		
		curPageAppend = "<strong>" + curPage  + "</strong>";		// 선택된 페이지 번호는 link 없으며, 굵게 표시
		
		
		if(1 != curPage){											// 이전 페이지 이동 버튼(첫 페이지가 아닐 경우에만)
			appendData = "<a href='#' onclick='prevPage(); return false;'><span class='glyphicon glyphicon-chevron-left'></span></a>";
		}
		
		prtPageNo = result.sdList[0].listTotCnt / rowPerPage;		// 전체 데이터 갯수를 기준으로 출력될 페이지 갯수 구함
		prtPageNo = Math.ceil(prtPageNo);							// ceil 함수를 활용하여 마지막 페이지 추출(올림처리)
		
		tempPageNo = (parseInt(curPage)-1) / 10;					// page 번호는 10개 단위로 보여줌(목록 리스트 단위가 아닌 페이지 번호의 의미)
		tempPageNo = Math.floor(tempPageNo);						// page 번호 내림 처리 하여 보여줘야 할 10의자리 페이지 번호
		initPageNo = (tempPageNo*10)+1 ;							// 페이지 번호 시작의 초기값
		
		for(var i=1; i<=10; i++){
			if(initPageNo == curPage){								// 현재 페이지 번호일 경우 a herf 설정 제거 및 해당 페이지 글꼴 strong 처리
				appendData += curPageAppend;
			}else{
				if(prtPageNo < initPageNo) break;					// 만일 17페이까지 보여줘야 한다면, 11,12,13,14,15,16,17 까지 보여야 하므로 전체 페이지 갯수와 비교 하여 17 이상의 페이지는 숨기기 위함i
				appendData += " <a href='#' onclick='movePage(" + initPageNo + "); return false;'>" + initPageNo + "</a> ";				// 이외 페이지의 경우 해당 페이지의 링크 설정
			}																											// onclick의 return false는 a 태그가 이벤트 발생하면 페이지의 상단으로 이동을 막기 위함
			initPageNo++;
		}
		
		if(curPage < prtPageNo){
			appendData += "<a href='#' onclick='nextPage(); return false;'><span class='glyphicon glyphicon-chevron-right'></span></a>";
		}
		
		$("#pageNav").append(appendData);	
	}
}

 /****************************************
  * Smart Desk 목록 조회 Page 이동 (페이지 번호 클릭)
  * param : page 번호
  ****************************************/
function movePage(page){
	$("#selectedPageNum").val(page);						// 지정된 페이지로 이동
	fnSearch();
}

/****************************************
 * Smart Desk 목록 조회 Page 이동 (페이지 번호 클릭)
 ****************************************/
function nextPage(){
	movePage(Number($("#selectedPageNum").val())+1);		// hidden으로 지정된 페이지 값을 보고 다음 페이지로 이동
}

/****************************************
 * Smart Desk 목록 조회 Page 이동 (페이지 번호 클릭)
 ****************************************/
function prevPage(){
	movePage(Number($("#selectedPageNum").val())-1);		// hidden으로 지정된 페이지 값을 보고 이전 페이지로 이동
}

/****************************************
 * Smart Desk 내용 조회
 ****************************************/
function fn_sdModify(sdId){
	$("#sdViewSdId").val(sdId);
	$("#sdViewPage").submit(); 
}

/****************************************
 * 공통코드 004 : 서비스구분 조회 
 ****************************************/
function fnSearchType(){
	$("#hiddenCmcd").val('004');	// 공통코드 : 서비스구분
	
	$.ajax({
		type : "post",
		url : "searchCmcd.sd",
		dataType : "json",
		data : $("#formSearch").serialize(),
		success : function(result){
			for(var i=0; i<result.infoCmcdList.length; i++){
				$('#reqSvcType').append("<option value='" + result.infoCmcdList[i].sdCd + "'>" + result.infoCmcdList[i].sdCdName +"</option>");
			}
		},
		// 에러 출력
		error : function(result){
			Debugger.log(result);
			Debugger.log("Error");
		}
	});
	
	$("#hiddenCmcd").val('');
}
