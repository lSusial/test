/**
 * Smart Desk Javascript
 */

/****************************************
 * 글로벌 변수 선언
 ****************************************/
G_SD_MAP = new HashMap();	// Map

G_REQ_SYSTEM_CD = "";		// 시스템코드
G_REQ_TYPE = "";			// 유형코드
G_REQ_DESC = "";			// 내용
G_RTC_PROJ_NM = "";			// IBM SCOPE여부

G_WK_DESC = "";				// 처리내용
G_GW_ID = "";				// GW ID
G_ACTION_STATUS = "";		// 조치상태

G_FILE_CNT = 0;				// 파일개수
G_FILE_FIELD_SEQ = 0;		// 파일SEQ

G_GW_YN = "N";				// 결재 여부

var G_TIMER;

/****************************************
 * 세션 시간 세팅
 ****************************************/
function setTimer(){
	G_TIMER = setTimeout(function () { fnCheckSession() }, G_INTERVAL_TIME);
}

function startTimer() {
	setTimer();
}

function clearTimer() {
	clearTimeout(G_TIMER);
}

/****************************************
 * 세션체크
 ****************************************/
function fnCheckSession(){
	$.ajax({
		type : "post",
		url : "checkSession.sd",
		dataType : "json",
		contentType : "application/json; charset=utf-8",
		data : "",
		success : function(result){
			if(result.status == "9999"){
				alert("세션이 만료되어 로그인 화면으로 이동합니다.");
				
				// clear
				clearInterval(G_TIMER);
				
				// redirect 화면으로 이동
				var urlParam = "/redirectlogin.sd";
				window.location = urlParam;
			}
		},
		error : function(result){
			alert("통신 에러가 발생 하였습니다. \n관리자에게 문의 하세요.");
		}
	});
}

/****************************************
 * 페이지 로딩 시 onload 함수 호출
 * 호출순서
 * 1 : $(document).ready(function()
 * 2 : window.onload = function ()
   <body onload=""> 함수와 같이 쓸 수 없음
 ****************************************/
$(document).ready(function() {
	// 로딩 이미지 출력
	$('.wrap-loading').removeClass('display-none');
});

window.onload = function () {
	fnOnload();
	
	// 로딩 이미지 숨김
	$('.wrap-loading').addClass('display-none');
}



/****************************************
 * Form Validation (등록)
 ****************************************/	
function fnCheckRegisterForm(){
	/******************************** 
	 * 등록 시 필수 체크
	 ********************************/
	// 이름
	if($.trim($("#reqName").val()) == ""){
		$("#reqName").val('');
		alert("이름을 입력하세요.");
		$("#reqName").focus();
		return false;
	}
	
	// 전화
	if($.trim($("#reqTelno").val()) == ""){
		$("#reqTelno").val('');
		alert("전화를 입력하세요.");
		$("#reqTelno").focus();
		return false;
	}
	
	// 메일
	if($.trim($("#reqEmail").val()) == ""){
		$("#reqEmail").val('');
		alert("메일을 입력하세요.");
		$("#reqEmail").focus();
		return false;
	}
	
	// 메일 형식 체크
	if($.trim($("#reqEmail").val()) != ""){
		var mailformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;  
		if( !$.trim($("#reqEmail").val()).match(mailformat) ){  
			alert("메일 형식이 올바르지 않습니다.");  
			$("#reqEmail").focus();
			return false;  
		}
	}
	
	// 완료희망일
	if($.trim($("#reqTgtDate").val()) == ""){
		$("#reqTgtDate").val('');
		alert("완료희망일을 입력하세요.");
		$("#reqTgtDate").focus();
		return false;
	}
	
	// 날짜 형식 체크
	if($.trim($("#reqTgtDate").val()) != ""){
		var dateformat = /^(19[7-9][0-9]|20\d{2})-(0[0-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1])$/;
		if( !$.trim($("#reqTgtDate").val()).match(dateformat) ){  
			alert("날짜 형식이 올바르지 않습니다.");  
			$("#reqTgtDate").focus();
			return false;  
		}
	}
	
	// 사업장(선택하지 않은 경우 undifined로 나타남)
	if( !$("#reqBizLocCd > option:selected").val() ){
		alert("구분>사업장을 선택하세요.");
		$("#reqBizLocCd").focus();
		return false;
	}
	
	// 시스템(선택하지 않은 경우 undifined로 나타남)
	if( !$("#reqSystemCd > option:selected").val() ){
		alert("구분>시스템을 선택하세요.");
		$("#reqSystemCd").focus();
		return false;
	}
	else{
		// 유형(서비스유형이 AP(application)인 경우에만 유형선택)
		if($("#reqSystemCd option:selected").val().substring(4,6) == "AP"){
			// 유형(선택하지 않은 경우 undifined로 나타남)
			if( !$("#reqType > option:selected").val() ){
				alert("구분>유형을 선택하세요.");
				$("#reqType").focus();
				return false;
			}
		}
	}
	
	// 제목
	if($.trim($("#reqTitle").val()) == ""){
		$("#reqTitle").val('');
		alert("제목을 입력하세요.");
		$("#reqTitle").focus();
		return false;
	}
	
	// 내용
	if(oEditors.getById["reqDesc"].getIR().length >= 1500){
		alert("입력하신 내용의 길이가 초과되었습니다. ");
		oEditors.getById["reqDesc"].exec("FOCUS"); 
		return false;
	}
	
	/******************************** 
	 * GW결재를 타는 경우
	 * (초기 GW 결재인 경우는 유형(reqType) 선택에 따라 정해졌으나,
	 * 이후 요청으로 인해
	 * 진행상태가 012 결재요청중 이고 GW결재여부가 Y인 경우 GW 결재를 탐)
	 ********************************/
	// 진행상태 : 012 결재요청중 이고 gwYn(GW결재여부) 값이 Y인 경우
	if($("#wkStatus option:selected").val() == "012" &&
			G_SD_MAP.get($("#reqSystemCd > option:selected").val()) == "Y"){
		// 확인 Alert
		if(confirm("GW결재가 필요합니다. 계속 진행하시겠습니까?")){
			G_GW_YN = "Y";
			return true;
		}
		else{
			return false;
		}
	}
	
	// 숨겨진 처리자명 필드에 담기
	if($("#sessionUserName").val() == ""){
		document.formRegister.entName.value = $("#sessionUserName").val();
		return true;
	}
	
	return true;
}

/****************************************
 * 1 구분 > 유형   선택에 따라 진행상태 변경
 * 2 구분 > 시스템 선택에 따라 진행상태 변경
 
 <등록시>
 문의						011 : HelpDesk 접수중
 기능개선,데이터,권한요청	012 : 결재요청중
 N/W,PC,Server,장애오류		010 : 담당자접수중

 <GW연계시>
 021 : 결재중
 030 : 결재완료
 032 : 결재반려
 
 <HelpDesk>
 040 : 담당자이관(2차 이관)
 
 <RTC연계시>
 050 : 담당자이관(RTC 이관)
 100 : 처리완료
 090 : 담당자이관(타사 이관) 
 099 : 반려
 098 : 취소
 ****************************************/
function fnChangeWkStatus(){
	/*
	 * 1 구분 > 유형   선택에 따라 진행상태 변경
	 */
	if($("#reqSystemCd option:selected").val().substring(4,6) == "AP"){
		// 10 프로그램개발 -> 012 결재요청중
		if($("#reqType option:selected").val() == "10"){
			$("#wkStatus").val('012');
		}
		// 11 문의 -> 011 HelpDesk 접수중 
		else if($("#reqType option:selected").val() == "11"){
			$("#wkStatus").val('011');
		}
		// 12 장애/오류 -> 010 담당자접수중
		else if($("#reqType option:selected").val() == "12"){
			$("#wkStatus").val('010');
		}
		// 13 데이터제공/수정 -> 012 결재요청중
		else if($("#reqType option:selected").val() == "13"){
			$("#wkStatus").val('012');
		}
		// 15 권한요청 -> 012 결재요청중
		else if($("#reqType option:selected").val() == "15"){
			$("#wkStatus").val('012');
		}
	}
	 
	/*
	 * 2 구분 > 시스템 선택에 따라 진행상태 변경
	 */
	 else if($("#reqSystemCd option:selected").val().substring(4,6) != "AP"){
		// PC -> 011 HelpDesk 접수중 
		if($("#reqSystemCd option:selected").val().substring(4,6) == "PC"){
			$("#wkStatus").val('011');
		}
		// 그외 -> 010 담당자접수중
		else{
			$("#wkStatus").val('010');
		}
	}

	/*
	 * 3 그외
	 */
	else{
		$("#wkStatus").val('');
	}
}

/****************************************
 * 조회 화면에서 넘어 온 경우
 * SD_ID로 조회
 ****************************************/ 
function fnSearchBySdId(){
	$.ajax({
		type : "post",
	    url : "info.sd",
	    dataType : "json",
	    data : $("#formRegister").serialize(),
	    async : false,
	    success : function(result){
			// 값 바인딩 : 등록폼
	        $("#reqName").val(result.infoSelectOne.reqName);
	        $("#wkStatus").val(result.infoSelectOne.wkStatus);
	        $("#reqDept").val(result.infoSelectOne.reqDept);
	        $("#reqTelno").val(result.infoSelectOne.reqTelno);
	        $("#reqEmail").val(result.infoSelectOne.reqEmail);
	        $("#reqTgtDate").val(result.infoSelectOne.reqTgtDate);
	        $("#reqBizLocCd").val(result.infoSelectOne.reqBizLocCd);
			G_REQ_SYSTEM_CD	= result.infoSelectOne.reqSystemCd;
	        G_REQ_TYPE		= result.infoSelectOne.reqType;
			$("#reqTitle").val(result.infoSelectOne.reqTitle);
			G_REQ_DESC		= result.infoSelectOne.reqDesc;
			G_FILE_CNT		= result.infoSelectOne.fileCnt;
			G_RTC_PROJ_NM	= result.infoSelectOne.rtcProjNm;
			
	        // 값 바인딩 : 처리폼
			G_GW_ID = result.infoSelectOne.gwId;
	        G_ACTION_STATUS	= result.infoSelectOne.actionStatus;
	        
	        $("#wkDesc").val(result.infoSelectOne.wkDesc);
	        G_WK_DESC = result.infoSelectOne.wkDesc;	// 변경여부를 체크하기 위함
	        $("#appName").val(result.infoSelectOne.appName);
	        $("#appDate").val(result.infoSelectOne.appDate);
	        $("#wkName").val(result.infoSelectOne.wkName);
	        $("#wkDate").val(result.infoSelectOne.wkDate);
	        $("#entName").val(result.infoSelectOne.entName);
	        $("#entDate").val(result.infoSelectOne.entDate);	        
		},
		error : function(result){
			//Debugger.log("Error");
			alert("오류가 발생 하였습니다. \n다시 확인 하시기 바랍니다.");
			window.location = "/list.sd";
			
		}
	});
	
	// 저장해 둔 글로벌 변수에서 가져와 세팅
	$("#divReqDesc").append(G_REQ_DESC);
}

// 리스트로 들어 온 경우 disabled가 필요한 컴포넌트들 처리 
function fnDisabledComponent(){
	// 등록폼 Enable
	var filed = new Array('reqName','wkStatus','reqDept','reqTelno','reqEmail','reqTgtDate',
			'sectionIe8','reqBizLocCd','reqSystemCd',
			'reqTitle','reqDesc',
			'appName','appDate','wkName','wkDate','entName','entDate');	
	
	for (i=0; i<filed.length; i++){
		$("#"+filed[i]).attr("disabled",true);
	}
}

// Submit 하기 전 disabled 되어있던 컴포넌트를 abled로 바꿈
// disabled 되어 있는 경우 Submit 시 전송되지 않음
function fnAbledComponent(){
	// 등록폼 Enable
	var filed = new Array('reqName','wkStatus','reqDept','reqTelno','reqEmail','reqTgtDate',
			'sectionIe8','reqBizLocCd','reqSystemCd','reqType',
			'reqTitle','reqDesc',
			'appName','appDate','wkName','wkDate','entName','entDate');	
	
	for (i=0; i<filed.length; i++){
		$("#"+filed[i]).attr("disabled",false);
	}
}

/****************************************
 * 공통코드 001 : 진행상태 조회
 ****************************************/ 
function fnSearchWkStatus(){
	$("#hiddenCmcd").val('001');	// 공통코드 : 진행상태
	
	$.ajax({
		type : "post",
		url : "searchCmcd.sd",
		dataType : "json",
		data : $("#formRegister").serialize(),
		async : false,
		success : function(result){
			for(var i=0; i<result.infoCmcdList.length; i++){
				$('#wkStatus').append("<option class='select-option-font' value='" + result.infoCmcdList[i].sdCd + "'>" + result.infoCmcdList[i].sdCdName +"</option>");
			}
		},
		error : function(result){
			Debugger.log(result);
			Debugger.log("Error");
		}
	});
	
	$("#hiddenCmcd").val('');
}

/****************************************
 * 처음 로드 시 사업장 조회
 ****************************************/ 
function fnSearchBizLoc(){
	// 사업장 초기화
	$('#reqBizLocCd').find('option').each(function(){
		$(this).remove();
	});
	// 시스템 초기화 
	$('#reqSystemCd').find('option').each(function(){
		$(this).remove();
	});
	// 유형 초기화
	$('#reqType').find('option').each(function(){
		$(this).remove();
	});
	
	$.ajax({
		type : "post",
		url : "searchBizLoc.sd",
		dataType : "json",
		data : $("#formRegister").serialize(),
		async : false,
		success : function(result){
			for(var i=0; i<result.infoBizLocList.length; i++){
				$('#reqBizLocCd').append("<option class='select-option-font' value='" + result.infoBizLocList[i].bizLocCd + "'>" + result.infoBizLocList[i].bizLoc +"</option>");
			}
		},
		error : function(result){
			Debugger.log(result);
			Debugger.log("Error");
		}
	})
	// success 응답을 받은 경우에만 호출
	.done(function(){
		clearTimer();
		startTimer();
	});
	
	// 사업장 변경시 시스템 조회 
	$("#reqBizLocCd").change(function(){
		// 시스템 셀렉트 박스 보이기
		document.getElementById("reqSystemCd").style.visibility = "visible";
		
		// 유형 셀렉트 박스 숨기기
		document.getElementById("reqType").style.visibility = "hidden";
		
		fnSearchSystem();
	});
	
	// 시스템 변경시 서비스구분에 따라 유형을 선택 유무를 판단 
	$("#reqSystemCd").change(function(){
		// 유형 초기화
		$('#reqType').find('option').each(function(){
			$(this).remove();
		});
		
		// 진행상태 초기화 
		$("#wkStatus").val('');
		
		fnVisibleType();	// 시스템 선택에 따라 유형 셀렉트 박스 visible 처리
		fnChangeWkStatus();	// 유형을 변경하지 않고 시스템만 변경할 수 있으므로
	});
	
	// 유형 변경시 진행상태 변경
	$('#reqType').change(function(){
		fnChangeWkStatus();
	});
}

/****************************************
 * 시스템 선택에 따라 유형 셀렉트 박스 visible 처리
 ****************************************/ 
function fnVisibleType(){
	// SVC_TYPE가 Application 인 경우, 이벤트를 타도록 함  
	if($("#reqSystemCd option:selected").val().substring(4,6) == "AP"){
		// 유형 셀렉트 박스 보이기
		document.getElementById("reqType").style.visibility = "visible";
		
		// 조회 화면을 통해 들어 온 경우 유형 셀렉트박스 disabled/enabled 처리
		if($("#sdId").val() != ""){
			 $("#reqType").attr("disabled",true);			// 선택불가
			 
			 // 조치상태 값을 10 2차이관 또는 20 타사이관을 선택하고,
			 // 진행상태가 040 2차이관 또는 090 타사이관이 아닌 경우
			 if(($("#actionStatus option:selected").val() == "10" || $("#actionStatus option:selected").val() == "20")){
				 if($("#wkStatus option:selected").val() == "040" || $("#wkStatus option:selected").val() == "090"){
					 $("#reqType").attr("disabled",true);	// 선택불가
				 }
				 else{
					 // 공통코드 002 : 유형 조회
					 fnSearchType();
						
					 $("#reqType").attr("disabled",false);	// 선택가능
				 }
			 }
		}
		// 등록 화면을 통해 들어 온 경우
		else{
			// 공통코드 002 : 유형 조회
			fnSearchType();
			
			$("#reqType").attr("disabled",false);			// 선택가능
		}
	}
	else{
		// 유형 셀렉트 박스 숨기기
		document.getElementById("reqType").style.visibility = "hidden";
		
		// 등록화면인 경우에만 진행상태를 자동으로 변경하고,
		// 목록화면에서 들어 온 경우 기존에 선택되어 진 진행상태를 변경하면 안됨
		/*if($("#sdId").val() == ""){
			//  진행상태 변경
			fnChangeWkStatus();
		}*/
	}
}

/****************************************
 * 사업장 변경시 시스템 조회
 ****************************************/ 
function fnSearchSystem(){
	// 시스템 초기화 
	$('#reqSystemCd').find('option').each(function(){
		$(this).remove();
	});
	// 유형 초기화
	$('#reqType').find('option').each(function(){
		$(this).remove();
	});
	
	$.ajax({
		type : "post",
		url : "searchSystem.sd",
		dataType : "json",
		data : $("#formRegister").serialize(),
		async : false,
		success : function(result){
			for(var i=0; i<result.infoSystemList.length; i++){
				$('#reqSystemCd').append("<option class='select-option-font' value='" + result.infoSystemList[i].systemCd + "'>" + result.infoSystemList[i].system +"</option>");
				G_SD_MAP.put(result.infoSystemList[i].systemCd, result.infoSystemList[i].gwYn);
			}
		},
		error : function(result){
			Debugger.log(result);
			Debugger.log("Error");
		}
	})
	// success 응답을 받은 경우에만 호출
	.done(function(){
		clearTimer();
		startTimer();
	});
}

/****************************************
 * 공통코드 002 : 유형 조회 
 ****************************************/
function fnSearchType(){
	$("#hiddenCmcd").val('002');	// 공통코드 : 유형
	
	$.ajax({
		type : "post",
		url : "searchCmcd.sd",
		dataType : "json",
		data : $("#formRegister").serialize(),
		async : false,
		success : function(result){
			for(var i=0; i<result.infoCmcdList.length; i++){
				$('#reqType').append("<option class='select-option-font' value='" + result.infoCmcdList[i].sdCd + "'>" + result.infoCmcdList[i].sdCdName +"</option>");
			}
			
			// 유형에 값이 있으면 그 값을 세팅해줌
			if( !isNull(G_REQ_TYPE) ){
				$("#reqType").val(G_REQ_TYPE);
			}
		},
		error : function(result){
			Debugger.log(result);
			Debugger.log("Error");
		}
	})
	// success 응답을 받은 경우에만 호출
	.done(function(){
		clearTimer();
		startTimer();
	});
	
	$("#hiddenCmcd").val('');
}


/****************************************
 * 공통코드 003 : 조치 상태 조회 
 ****************************************/
function fnSearchactionStatus(){
	$("#hiddenCmcd").val('003');	// 공통코드 : 조치 상태
	
	$.ajax({
		type : "post",
		url : "searchCmcd.sd",
		dataType : "json",
		data : $("#formRegister").serialize(),
		async : false,
		success : function(result){
			for(var i=0; i<result.infoCmcdList.length; i++){
				$('#actionStatus').append("<option class='select-option-font' value='" + result.infoCmcdList[i].sdCd + "'>" + result.infoCmcdList[i].sdCdName +"</option>");
			}
		},
		error : function(result){
			Debugger.log(result);
			Debugger.log("Error");
		}
	});
	
	$("#hiddenCmcd").val('');
	
	// 조치상태 변경시 구분의 시스템, 유형 제어 
	$("#actionStatus").change(function(){
		// 조치상태 값을 10 2차이관 또는 20 타사이관을 선택 한 경우
		if($("#actionStatus option:selected").val() == "10" || $("#actionStatus option:selected").val() == "20"){
			$("#reqSystemCd").attr("disabled",false);
			$("#reqType").attr("disabled",false);
		}
		else{
			// 구분의 시스템 또는 유형 값을 바꾸었을 수도 있으므로
			// 처음 조회 되었을때 가지고 있었던 값으로 바꿈
			$("#reqSystemCd").val(G_REQ_SYSTEM_CD);
			$("#reqType").val(G_REQ_TYPE);
			
			// 다른 경우에는 바꾸면 안되므로
			// 시스템은 disabled 시킴 
			$("#reqSystemCd").attr("disabled",true);
			
			// 유형은 시스템 선택에 따라 제어 
			fnVisibleType();
		}
	});
}

/****************************************
 * 처리상태 바 세팅 
 ****************************************/
function fnSettingWkStatusBar(){
	var bgColor = "#9D8A69";
	var color = "#FFFFFF";
	
	// 조회화면에서 넘어 온 경우
	if($("#sdId").val() != ""){
		document.getElementById("wkStatusBar").style.display = "";
		
		// 접수중
		if($("#wkStatus").val() == "011" || $("#wkStatus").val() == "010"){
			document.getElementById("wkStatusBar1").style.background = bgColor;
			document.getElementById("wkStatusBar1").style.color = color;
		}
		// 결재중
		else if($("#wkStatus").val() == "012" || $("#wkStatus").val() == "021" || $("#wkStatus").val() == "030"){
			document.getElementById("wkStatusBar2").style.background = bgColor;
			document.getElementById("wkStatusBar2").style.color = color;
		}
		// 처리중
		else if($("#wkStatus").val() == "040" || $("#wkStatus").val() == "050" || $("#wkStatus").val() == "090"){
			document.getElementById("wkStatusBar3").style.background = bgColor;
			document.getElementById("wkStatusBar3").style.color = color;
		}
		// 완료
		else if($("#wkStatus").val() == "100"){
			document.getElementById("wkStatusBar4").style.background = bgColor;
			document.getElementById("wkStatusBar4").style.color = color;
		}
		// 반려/취소
		else if($("#wkStatus").val() == "099" || $("#wkStatus").val() == "098" || $("#wkStatus").val() == "032"){
			document.getElementById("wkStatusBar5").style.background = bgColor;
			document.getElementById("wkStatusBar5").style.color = color;
		}
	}
	else{
		// 처리상태 바 숨김
		document.getElementById("wkStatusBar").style.display="none";
	}
}

// 그룹웨어 결재 링크 visible 처리
function fnVisibleGw(){
	if( isNull(G_GW_ID) ){
		// 결재를 받지 않은 경우, 그룹웨어 결재 링크 숨김
		document.getElementById("gw").style.display="none";
		
		document.getElementById("divGw").style.border = "1px solid #f4f4f4";
		document.getElementById("divGw").style.backgroundColor = "#f4f4f4";
	}
	else{
		// 결재를 받은 경우, 그룹웨어 결재 링크 보여줌
		document.getElementById("gw").style.display="";
		var gwLink = "<a href='/viewGwResult.sd?sdId="+ $('#sdId').val() +"' target='_blank'>결재문서 </a>";
		$("#divGw").append(gwLink);
		
		document.getElementById("divGw").style.border = "1px solid #c0c0c0";
		document.getElementById("divGw").style.width = "89%";
		document.getElementById("divGw").style.margin = "5px 0px 0px 15px";
		document.getElementById("divGw").style.padding = "0px 0px 0px 9px";
	}
}

/****************************************
 * Form Onload 
 ****************************************/
function fnOnload(){
	// 발송된 이메일에 존재하는 URL로 접속시 로그인 되어 있지 않을 경우 로그인 페이지로 이동
	// RTC에서 접근하는 경우는 모든 권한 dsiable 처리
	if($("#rtcView").val() != "Y"){
		if( isNull($("#sessionUserName").val()) ){
			alert("로그인 후 확인이 가능합니다.");
			
			var urlParam = "/redirectlogin.sd?redirect="+window.location.pathname + "&sdId="+getURLParameter("sdId");
			window.location = urlParam;
			
			return false;
		}
	}
	
	fnSearchWkStatus();		// 공통코드 001 : 진행상태 조회
	fnSearchactionStatus();	// 공통코드 003 : 조치 상태 조회 
	
	// 조회 화면에서 넘어 온 경우 
	if($("#sdId").val() != ""){
		document.getElementById("reqSystemCd").style.visibility = "visible";
		document.getElementById("reqType").style.visibility = "visible";
		
		// 사업장 조회
		fnSearchBizLoc();
		
		// 조회 화면에서 넘어 온 경우 SD_ID로 조회
		fnSearchBySdId();
	
		// 조회 화면에서 넘어 왔을 경우 SD_ID로 파일정보 조회
		fnSearchFileBySdId();
		
		// 시스템, 유형을 조회
		fnSearchSystem();
		fnSearchType();
		
		// 시스템, 유형 데이터를 조회 후 저장해 둔 글로벌 변수에서 가져와 세팅
		$("#reqSystemCd").val(G_REQ_SYSTEM_CD);
		$("#reqType").val(G_REQ_TYPE);
		
		// 처리내용 세팅
		$("#reqDesc").val(G_REQ_DESC);
		
		// selectbox에 선택된 값이 보이도록 스크롤 조정
		fnAutoScroll(document.formRegister.reqBizLocCd);
		fnAutoScroll(document.formRegister.reqSystemCd); 
		
		// 시스템 선택에 따라 유형 셀렉트 박스 visible 처리
		fnVisibleType();

		// IE8인 경우 구분 : TEXT, 아닌 경우 구분 : 콤보박스
		fnCheckInternetBrowser();
		
		// 리스트로 들어 온 경우 disabled가 필요한 컴포넌트들 처리
		fnDisabledComponent();

		// 그룹웨어 결재 링크 visible 처리
		fnVisibleGw();
		
		// 처리폼 보여줌
		document.getElementById("workFormDiv").style.display="";
		
		// 등록 시 첨부파일을 넣지 않은 경우 보이지 않게 함
		if( isNull(G_FILE_CNT) || G_FILE_CNT == 0 ){
			document.getElementById("fileFormDiv1").style.display="none";
		}
		
		// 권한에 따른 컴포넌트 제어
		fnControlAuthGroup();
	}
	// 등록 화면으로 바로 들어온 경우
	else{
		// 등록시에는 구분 TEXT 숨기기
		document.getElementById("divSectionIe8").style.display="none";	// divSectionIe8 숨김		
		
		// 시스템, 유형 셀렉트 박스 숨기기
		document.getElementById("reqSystemCd").style.visibility = "hidden";
		document.getElementById("reqType").style.visibility = "hidden";

		// 처음 로드 시 사업장 조회
		fnSearchBizLoc();
		
		// 처리폼 숨김
		document.getElementById("workFormDiv").style.display="none";
	}
	
	// 처리상태 바 세팅
	fnSettingWkStatusBar();
}

/****************************************
 * 조회 화면에서 넘어 온 경우
 * 모든 컴포넌트가 disabled 되기 때문에
 * selectbox에 선택된 값이 보이도록 스크롤 조정
 ****************************************/
function fnAutoScroll(selectBox){
	if ((selectBox.options.length > 1)&&(selectBox.selectedIndex != -1)){
		selectBox.focus();
		i = selectBox.selectedIndex;

		if (selectBox.options.length-1 != i){ 
			selectBox.selectedIndex=selectBox.options.length-1;
		}
		else{
			selectBox.selectedIndex = i-1;
		}
		selectBox.selectedIndex = i;
	}
}

/****************************************
 * Form Validation (수정)
 ****************************************/
function fnCheckUpdateForm(){
	// 시스템(선택하지 않은 경우 undifined로 나타남)
	if( !$("#reqSystemCd > option:selected").val() ){
		alert("구분>시스템을 선택하세요.");
		$("#reqSystemCd").focus();
		return false;
	}
	else{
		// 유형(서비스유형이 AP(application)인 경우에만 유형선택)
		if($("#reqSystemCd option:selected").val().substring(4,6) == "AP"){
			// 유형(선택하지 않은 경우 undifined로 나타남)
			if( !$("#reqType > option:selected").val() ){
				alert("구분>유형을 선택하세요.");
				$("#reqType").focus();
				return false;
			}
		}
	}
	
	// 유형이 12 장애/오류이고 2차이관을 하는 경우
	if($("#reqType option:selected").val() == "12" && 
			$("#actionStatus option:selected").val() == "10"){
		alert("장애/오류인 경우 2차이관을 할 수 없습니다.");
		return false;
	}
	
	// 조치상태 값을 20 타사이관을 선택 하였는데
	// 시스템이 바뀌지 않은 경우 체크
	if($("#actionStatus option:selected").val() == "20"){
		if(($("#reqSystemCd option:selected").val() == G_REQ_SYSTEM_CD)){
			alert("타사이관시 이관할 대상으로 구분을 변경하세요.");
			
			// 시스템과 유형을 선택할 수 있도록
			$("#reqSystemCd").attr("disabled",false);
			$("#reqType").attr("disabled",false);
			
			// 시스템으로 포커스 이동
			$("#reqSystemCd").focus();
			return false;
		}
	}
	
	// 조치상태 값을 임시저장으로 선택 한 경우 확인창
	if($("#actionStatus option:selected").val() == ""){
		// 확인 Alert
		if(confirm("임시저장하시겠습니까?")){
			return true;
		}
		else{
			return false;
		}
	}
	
	// 처리내용(조치상태를 2차이관 또는 타사이관을 선택 한 경우)
	if(($("#actionStatus option:selected").val() == "10" || $("#actionStatus option:selected").val() == "20")){
		// 처리내용에 내용이 없는 경우
		if( isNull($("#wkDesc").val()) ){
			alert($("#actionStatus option:selected").text() + " 할 경우 처리내용에 이관사유를 입력하세요.");
			$("#wkDesc").focus();
			return false;
		}
		
		// 내용이 있으나 이전 내용과 같은 경우
		if(G_WK_DESC == $.trim($("#wkDesc").val())){
			alert($("#actionStatus option:selected").text() + " 할 경우 처리내용에 이관사유를 변경하세요.");
			$("#wkDesc").focus();
			return false;
		}
	}
	
	return true;
}


/****************************************
 * 조치 상태 제어
 ****************************************/
function fnInitActionStatus(){
	$("#actionStatus").find("option").remove();							// 전체 삭제
	$('#actionStatus').append("<option value=''>임시저장</option>");	// Default
	fnSearchactionStatus();												// 처음 상태로 조회
}

/****************************************
 * 권한에 따른 컴포넌트 제어
 * 
 * 1) 권한에 따라 조치상태 값 다르게 Select,
 * 2) 일반사용자의 경우 처리내용, 조치상태, 저장버튼 제어
 * 3) wkStatus에 따라 처리내용, 조치상태, 저장버튼 제어
 * "" 임시저장
 * 00 완료(이관없음)
 * 10 2차이관
 * 20 타사이관
 ****************************************/
function fnControlAuthGroup(){
	fnInitActionStatus();
	
	// 조치상태를 선택할 수 있는 경우 권한에 따라 다르게 보이도록
	// IT담당자
	if($("#sessionAuthGroup").val() == "I"){
	}
	// HelpDesk 직원
	else if($("#sessionAuthGroup").val() == "H"){
		$("#actionStatus option:eq(3)").remove(); // 타사이관 삭제
		
		// 2차이관 된 경우
		// 조치상태, 처리내용, 저장버튼 수정 불가
		if(G_ACTION_STATUS == "10"){
			$("#wkDesc").attr("disabled",true);			// 처리내용 수정불가
			$("#actionStatus").attr("disabled",true);	// 조치상태 선택불가
			$("#btnSave").attr("disabled",true);		// 저장버튼 선택불가
		}
	}
	// 처리자
	else if($("#sessionAuthGroup").val() == "W"){
		$("#actionStatus option:eq(2)").remove(); // 2차이관 삭제 
	}
	// 일반사용자
	else if($("#sessionAuthGroup").val() == "P"){
		$("#wkDesc").attr("disabled",true);			// 처리내용 수정불가
		$("#actionStatus").attr("disabled",true);	// 조치상태 선택불가
		$("#btnSave").attr("disabled",true);		// 저장버튼 선택불가
	}
	// RTC에서 접근한 경우
	else if($("#rtcView").val() == "Y"){
		$("#wkDesc").attr("disabled",true);			// 처리내용 수정불가
		$("#actionStatus").attr("disabled",true);	// 조치상태 선택불가
		$("#btnSave").attr("disabled",true);		// 저장버튼 선택불가
		$("#btnList").attr("disabled",true);		// 목록버튼 선택불가
	}
	
	/*
	 * 아래는 권한에 상관없이 업무 로직에 의해
	 * 조치상태, 처리내용, 저장버튼이 제어 되어야 함
	 */
	// 진행상태가 099 반려, 100 처리완료, 012 결재요청중, 021 결재중, 032 결재반려 인 경우
	// 조치상태, 처리내용, 저장버튼 수정 불가
	if(($("#wkStatus option:selected").val() == "099") ||
			($("#wkStatus option:selected").val() == "100") ||
			($("#wkStatus option:selected").val() == "012") ||
			($("#wkStatus option:selected").val() == "021") ||
			($("#wkStatus option:selected").val() == "032")){
		
		$("#wkDesc").attr("readonly",true);			// 처리내용 수정불가
		$("#actionStatus").attr("disabled",true);	// 조치상태 선택불가
		$("#btnSave").attr("disabled",true);		// 저장버튼 선택불가
	}
	
	// 진행상태가 040 담당자이관(2차 이관), 050 담당자이관(RTC 이관), 090 담당자이관(타사 이관) 이고
	// IBM 관리 여부인 경우
	// 조치상태, 처리내용, 저장버튼 수정 불가
	if( (($("#wkStatus option:selected").val() == "040") ||
			($("#wkStatus option:selected").val() == "050") ||
			($("#wkStatus option:selected").val() == "090")) &&
			(G_RTC_PROJ_NM == "Y")){
		
		$("#wkDesc").attr("readonly",true);			// 처리내용 수정불가
		$("#actionStatus").attr("disabled",true);	// 조치상태 선택불가
		$("#btnSave").attr("disabled",true);		// 저장버튼 선택불가
	}
	
	// 권한에 따라 조치상태 값을 다르게 가져 온 후, 조회 된 값을 세팅
	// HelpDesk 직원인 경우 조치상태에 타사이관이 삭제 되었기 때문에
	// 처리자인 경우 조치상태에 2차이관이 삭제 되었기 때문에
    // 이 경우 임시저장으로 선택되도록 함
	if($("#sessionAuthGroup").val() == "H" && G_ACTION_STATUS == "20"){
    	$("#actionStatus").get(0).selectedIndex = 0;
    }
	else if($("#sessionAuthGroup").val() == "W" && G_ACTION_STATUS == "10"){		// 처리자일 경우 2차 이관시 조치상태 임시저장으로 설정 - choch
    	$("#actionStatus").get(0).selectedIndex = 0;
    }
	else{
		$("#actionStatus").val(G_ACTION_STATUS);
	}
}



/****************************************
 * SD_ID를 통해 파일 정보 조회
 ****************************************/ 
function fnSearchFileBySdId(){
	// 기본 1개 존재하는 파일 폼 삭제
	$("#field_1").remove();
	
	$.ajax({
		type : "post",
	    url : "fileList.sd",
	    dataType : "json",
	    data : $("#formRegister").serialize(),
	    async : false,
	    success : function(result){
	    	
	        var fileCnt = G_FILE_CNT;
			
	        // 파일 갯수만큼 링크 생성
	        for(var i=0; i<fileCnt; i++){
	        	var appendFileLink = "";
	        	
	        	// 파일의 쉼표 추가 (마지막 파일의 경우 쉼표 안넣음
	        	if(i == (fileCnt-1)){
	        		appendFileLink = fnFileLink(result.tbFileList[i].fileName);
	        	}else{
	        		appendFileLink = fnFileLink(result.tbFileList[i].fileName)+" ,  ";
	        	}
				
				$("#divFile1_1").append(appendFileLink);
	        }
		},
		error : function(result){
			Debugger.log(result);
			Debugger.log("Error");
		}
	});
}

/****************************************
 * File Link 함수
 ****************************************/
function fnFileLink(fileName){
	var linkStr = "";
	
	linkStr = "<a href='/fileDownload.sd?fileName="+fileName+"&sdId="+$("#sdId").val()+"'>"+fileName+"</a>";
	return linkStr;
	
}

/****************************************
 * File Selection Event
 * inParam : file Field ID
 ****************************************/
function fnFileOnchange(fieldId){
	// alert(fieldId.substring(fieldId.length-1));
	// File 명 중복 체크
	if(!fnIsDuplicate(fieldId)){					// 파일명 중복이 아닐경우
		// File Field 추가
		fnAddFileField(fieldId, fieldId.substring(fieldId.length-1));		
	}
}

/****************************************
 * File Field 추가
 * File 선택이 되었을때마다 File Field 추가 (선택된 파일 옆에는 삭제 버튼 추가)
 * inParam : file Field ID, input file field 위치
 ****************************************/
function fnAddFileField(fieldId, curSeq){
	var appendField = "";
	
	// File Field 추가
	nextSeq = parseInt(curSeq)+1;
	onchangeFn = "fnFileOnchange(\"field_"+nextSeq+"\")";
	
	appendField = "<div class='form-group form-group-sm' id='fileFormDiv"+ nextSeq +"'>";
	appendField += "	<label class='col-sm-1 control-label' for='formGroupInputSmall'>첨부파일</label>";
	appendField += "	<div class='col-sm-4' id='divFile"+ nextSeq +"_1'>";
	appendField += "		<input class='form-control' type='file' id='field_"+ nextSeq +"' name='files' onchange='"+onchangeFn+";'/>";
	appendField += "	</div>";
	appendField += "</div>";	
	// alert(appendField);
	$("#fileFormDiv"+curSeq).after(appendField);
	
	
	// 선택된 파일 Field 의 삭제 버튼 추가
	var appendFileDelBtn = "";
	appendFileDelBtn  = "<div class='col-sm-1' id='divFileDel"+curSeq+"_1'>";
	appendFileDelBtn += "	<button type='button' onclick='fnFileFieldDel(\"fileFormDiv"+curSeq+"\")' class='btn btn-paradise-del' style='margin-left:-28px;'>";
	appendFileDelBtn += "		<span class='glyphicon glyphicon-remove' aria-hidden='true'></span>";
	appendFileDelBtn += "	</button>";
	appendFileDelBtn += "</div>";
	// alert(appendFileDelBtn);
	$("#divFile"+ curSeq +"_1").after(appendFileDelBtn);
	
	// 파일 선택 수정 못하도록 readonly 처리
	$("#field_"+ curSeq).attr("readonly", "true");

	G_FILE_FIELD_SEQ = nextSeq;
}

/****************************************
 * File Fiel 삭제 버튼 이벤트 처리 
 ****************************************/
function fnFileFieldDel(divId){
	// alert('fieldDel ' + divId );
	$("#"+divId).remove();
}

/****************************************
 * File duplicate check
 * inParam : file Field ID
 ****************************************/
function fnIsDuplicate(fieldId){
	// alert(fieldId.substring(fieldId.length-1));
	// alert(fieldId);
	// File 명 중복 체크
	var fieldCnt = parseInt(G_FILE_FIELD_SEQ) - 1;
	var orgFileNm = "";
	var newFileNm = fnGetFileNameInPath($("#"+fieldId).val());
	var rtnResult = false;
	
	for(var i=1; i<=fieldCnt; i++){
		orgFileNm = fnGetFileNameInPath($("#field_"+i).val());
		// alert(orgFileNm + newFileNm);
		if(newFileNm == orgFileNm){
			alert("파일명이 중복 됩니다 다른 파일을 선택해 하십시오.");
			rtnResult = true;
			$("#"+fieldId).val("");
			// IE10인 경우 Input type File 초기화 달라짐
			if (/(MSIE|Trident)/.test(navigator.userAgent)) { 
			    // ie 일때 input[type=file] init.
				$("#"+fieldId).replaceWith( $("#"+fieldId).clone(true) );
			} else {
			    // other browser 일때 input[type=file] init.
				$("#"+fieldId).val("");
			}

			break;
		}
	}
	return rtnResult;
}


/****************************************
 * get File Name 
 * inParam : file Name with Path
 ****************************************/
function fnGetFileNameInPath(filePath){
	return filePath.substr(filePath.lastIndexOf('\\') + 1);
}


/****************************************
 * 그룹웨어 결재 요청 ajax 
 * 1. 그룹웨어 결재 요청전 SDesk 등록(ajax)
 * 2. 등록 완료 후 그룹웨어 결재 팝업 호출
 * 3. 팝업의 결재 요청/취소에 따라 다음 화면 이동 처리
 * 4. 결재요청 : list.sd 리스트 화면으로 이동 , 결재취소 : SDesk 등록된(1번항목) 내용 삭제 또는 취소 건으로 update 처리
 ****************************************/
function fnSdeskRegandGwReq(){
	
	
//	$("#formRegister").ajaxForm({
//	    url : "registerwithgw.sd",
//	    dataType:'script',
//	    forceSync : true,
//	    success : function(result){
//	    	alert(result);
//	    	$("#gwSdIdRef").val(result.sdId);
//	    	//fnModalessPopup(result.sdId);
//	    	//window.location = "/list.sd";
//
//		},
//		error : function(result){
//			// TODO 에러 로직 처리
//			Debugger.log("Error");
//		}
//
//	}).submit();

//	var dataForm = new FormData($("#formRegister"))
//	alert(dataForm);
	
	
	$.ajax({
		type : "post",
	    url : "registerwithgw.sd",
	    dataType : "json",
	    data : $("#formRegister").serialize(),
	    async : false,
	    success : function(result){
	    	$("#gwSdIdRef").val(result.sdId);
	    	if(G_FILE_FIELD_SEQ > 0){
	    		fnFileUploadForGW();
	    	}else{
	    		fnModalessPopup(result.sdId);
		    	window.location = "/list.sd";
	    	}
		},
		error : function(result){
			// TODO 에러 로직 처리
			Debugger.log("Error");
		}
	});
}

/****************************************
 * 그룹웨어 결재 대상건은 먼저 등록 후
 * 파일을 등록한다.
 ****************************************/
function fnFileUploadForGW(){
	var fileForm = new FormData();
	fileForm.append("files", document.getElementsByName('files'));
	fileForm.append("sdId", $("#gwSdIdRef").val());

	//return false;
	$("#formRegister").ajaxForm({
    url : "registerwithgwfile.sd",
    forceSync : true,
    success : function(result){
    	fnModalessPopup($("#gwSdIdRef").val());
    	window.location = "/list.sd";
	},
	error : function(result){
		// TODO 에러 로직 처리
		Debugger.log("Error");
	}

}).submit();

}
	

/****************************************
 * 그룹웨어 결재요청 팝업(모달) 
 ****************************************/
function opendialog(sdId) {
	var $dialog = $('#popDiv')
	.html('<iframe style="border: 0px;" id="popIframe" width="100%" height="100%"></iframe>')
	.dialog({
		title: "Smart Desk - GroupWare",
		autoOpen: false,
		dialogClass: 'dialog_fixed,ui-widget-header',
		modal: true,
		height: 760,
		minWidth: 1200,
		minHeight: 400,
		draggable:true,
		/*close: function () { $(this).remove(); },*/
		buttons: { "Ok": function () {         $(this).dialog("close"); } },
		// 아래는 src url이 지정되면 해당 url을 두번 호출하게 되어 close 처리 입력
	    close : function (event, ui){
	    	$("#popIframe").prop("src","about:blank");
	    },
	    open  : function (event, ui){
	    	$("#popIframe").prop("src","/requestgw.sd?sdId="+ sdId);
	    }
	});
	$dialog.dialog('open');
} 


/****************************************
 * Modal 팝업 미사용
 ****************************************/
function fnModalPopup(idVal, frmBd, frmPf, sdId, sdTitle) {
	
	var sharedObject = {};
	sharedObject.idVal = idVal;
	sharedObject.frmBd = frmBd;
	sharedObject.frmPf = frmPf;
	sharedObject.sdId = sdId;
	sharedObject.sdTitle = sdTitle;
	var retValue = showModalDialog("/requestgw.sd", sharedObject, "resizable:yes; scroll:yes; status:yes; dialogWidth:100px; dialogHeight720px; center:yes;");
	alert(reValue);
	return retValue;
    
}


/****************************************
 * Modaless 팝업 사용중
 ****************************************/
function fnModalessPopup(sdId) {
	
	var retValue = window.open("/requestgw.sd?sdId="+sdId, "그룹웨어 결재요청 팝업", "resizable:yes; scroll:yes; status:yes; dialogWidth:1000px; dialogHeight720px; center:yes;");
	return retValue;
    
}


/****************************************
 * Get 방식 URL Parameter 가져오기
 ****************************************/
function getURLParameter(name) {
  return decodeURIComponent((new RegExp('[?|&]' + name + '=' + '([^&;]+?)(&|#|;|$)').exec(location.search)||[,""])[1].replace(/\+/g, '%20'))||null
}


/****************************************
 * IE8 이하인 경우 콤보박스의 선택된 값이 보이지 않아 버전에 따라 다르게 체크
 * IE8 이하인 경우 구분	: TEXT
 * 아닌 경우 구분		: 콤보박스
 ****************************************/
var client = function(keyword, spliter){  
	var agent = navigator.userAgent.toLowerCase();  
	return agent.indexOf(keyword)>-1 ? parseFloat(agent.split(spliter || keyword).pop().replace(/^[^\w;]+/, '')) : null;  
}; 

function fnCheckInternetBrowser(){
	var ie = client('msie') || client('trident', 'rv:'); 

 	// 인터넷 익스플로러 && 버전 8 이하 인지 확인
	if( ie && ie <= 8){ 
		document.getElementById("divSectionIe8").style.display="";	// divSectionIe8 보임		
		document.getElementById("divSection").style.display="none";	// divSection 숨김
		
		// sectionIe8 Text에 값 넣기
		var reqBizLocNm = $("#reqBizLocCd option:selected").text();
		var reqSystemNm = $("#reqSystemCd option:selected").text();
		var reqTypeNm = $("#reqType option:selected").text();
	
		// sectionIe8 Text에 값 넣기
		if($("#reqSystemCd option:selected").val().substring(4,6) == "AP"){
			document.getElementById("sectionIe8").value = reqBizLocNm + " > " + reqSystemNm + " > " + reqTypeNm;
		}
		else{
			document.getElementById("sectionIe8").value = reqBizLocNm + " > " + reqSystemNm;
		}
	}
	else{
		document.getElementById("divSectionIe8").style.display="none";	// divSectionIe8 숨김		
		document.getElementById("divSection").style.display="";			// divSection 보임
    }
}
