package net.homeplus.offline.sr.list.dao;

import org.springframework.stereotype.Repository;

import net.homeplus.offline.common.dao.CommonDAO;

@Repository("SRListDAO")
public class SRListDAO extends CommonDAO {
	
	public void test(){
		
		getSqlSession().selectList("test.test");
		
	}
	

}
