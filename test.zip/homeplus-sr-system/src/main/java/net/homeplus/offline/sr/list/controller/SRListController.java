package net.homeplus.offline.sr.list.controller;

import net.homeplus.offline.common.mail.EmailSender;
import net.homeplus.offline.sr.list.service.SRListService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class SRListController {
	
	@Autowired
	private SRListService srListService;
	@Autowired
	private EmailSender emailSender;
	
	@RequestMapping("/test.do")
	public String test(){
		
		
		srListService.test();
		emailSender.send();
		
		
		return "test/test";
	}
	
}
