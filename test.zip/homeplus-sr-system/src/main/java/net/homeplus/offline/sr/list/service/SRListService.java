package net.homeplus.offline.sr.list.service;

public interface SRListService {
	public void test();
}
