package net.homeplus.offline.sr.list.service.impl;

import net.homeplus.offline.sr.list.dao.SRListDAO;
import net.homeplus.offline.sr.list.service.SRListService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("SRListService")
public class SRListServiceImpl implements SRListService{
	
	
	@Autowired
	private SRListDAO srListDAO;

	@Override
	public void test() {
		srListDAO.test();
	}
	
}
