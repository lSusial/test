package net.homeplus.offline.sr.list.vo;

public class SRListVO {

}
