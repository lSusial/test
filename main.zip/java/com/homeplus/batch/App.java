package com.homeplus.batch;

import java.sql.SQLException;

import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

public class App {
    public static void main(String[] args) {
        // String[] springConfig = {"C:\\temp2\\test.xml"};


        ApplicationContext context = new FileSystemXmlApplicationContext("C:\\temp2\\test.xml");

        JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
        Job job = (Job) context.getBean("testJob");

        try {

            JobExecution execution = jobLauncher.run(job, new JobParameters());
            System.out.println("Exit Status : " + execution.getStatus());

        } catch (Exception e) {
            e.printStackTrace();

            SQLException ex = ((SQLException) e).getNextException();
            while (ex != null) {
                System.err.println("SQL exception:");
                System.err.println(" Message: " + ex.getMessage());
                System.err.println(" SQLSTATE: " + ex.getSQLState());
                System.err.println(" Error code: " + ex.getErrorCode());
                ex = ex.getNextException();
            }

        }



        System.out.println("Done");

    }
}
