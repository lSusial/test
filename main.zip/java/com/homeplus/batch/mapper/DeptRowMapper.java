package com.homeplus.batch.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.homeplus.batch.model.DeptVO;


public class DeptRowMapper implements RowMapper<DeptVO> {

    @Override
    public DeptVO mapRow(ResultSet rs, int rowNum) throws SQLException {

        DeptVO dept = new DeptVO();
        dept.setDeptId(rs.getString("UNIT_CODE"));
        dept.setDeptNm(rs.getString("UNIT_NAME"));
        return dept;
    }

}
