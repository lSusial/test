package net.homeplus.offline.intergrate.vo;


public class TicketResultVO {

    private String seq;
    private String srId;
    private String ticketId;
    private String statusCd;
    private String workNm;
    private String workDate;
    private String resultDesc;
    private String ticketRcv;
    private String ticketRcvDate;
    private String srUpdDate;

    private String status;


    public String getSeq() {
        return seq;
    }

    public void setSeq(String seq) {
        this.seq = seq;
    }

    public String getSrId() {
        return srId;
    }

    public void setSrId(String srId) {
        this.srId = srId;
    }

    public String getStatusCd() {
        return statusCd;
    }

    public void setStatusCd(String statusCd) {
        this.statusCd = statusCd;
    }

    public String getWorkNm() {
        return workNm;
    }

    public void setWorkNm(String workNm) {
        this.workNm = workNm;
    }

    public String getWorkDate() {
        return workDate;
    }

    public void setWorkDate(String workDate) {
        this.workDate = workDate;
    }

    public String getResultDesc() {
        return resultDesc;
    }

    public void setResultDesc(String resultDesc) {
        this.resultDesc = resultDesc;
    }

    public String getSrUpdDate() {
        return srUpdDate;
    }

    public void setSrUpdDate(String srUpdDate) {
        this.srUpdDate = srUpdDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTicketRcvDate() {
        return ticketRcvDate;
    }

    public void setTicketRcvDate(String ticketRcvDate) {
        this.ticketRcvDate = ticketRcvDate;
    }

    public String getTicketRcv() {
        return ticketRcv;
    }

    public void setTicketRcv(String ticketRcv) {
        this.ticketRcv = ticketRcv;
    }

    public String getTicketId() {
        return ticketId;
    }

    public void setTicketId(String ticketId) {
        this.ticketId = ticketId;
    }



}
