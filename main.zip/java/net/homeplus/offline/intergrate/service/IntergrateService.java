package net.homeplus.offline.intergrate.service;


public interface IntergrateService {

    public void insertSRInfoToRTC();

    public void insertSRInfoToTicket();

    public void updateSRInfoFromRTC();

    public void updateSRInfoFromTicket();

}
