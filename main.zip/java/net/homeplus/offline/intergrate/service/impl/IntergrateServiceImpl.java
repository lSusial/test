package net.homeplus.offline.intergrate.service.impl;

import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import net.homeplus.offline.intergrate.dao.IntergrateDAO;
import net.homeplus.offline.intergrate.dao.IntergrateRTCDAO;
import net.homeplus.offline.intergrate.dao.IntergrateTicketDAO;
import net.homeplus.offline.intergrate.service.IntergrateService;
import net.homeplus.offline.intergrate.vo.FilePushVO;
import net.homeplus.offline.intergrate.vo.PushVO;
import net.homeplus.offline.intergrate.vo.RTCResultVO;
import net.homeplus.offline.intergrate.vo.TicketResultVO;


@Service("IntergrateService")
public class IntergrateServiceImpl implements IntergrateService {

    @Autowired
    IntergrateDAO intergrateDAO;
    @Autowired
    IntergrateRTCDAO intergrateRTCDAO;
    @Autowired
    IntergrateTicketDAO intergrateTicketDAO;


    @Override
    public void insertSRInfoToRTC() {

        // 1. 결제가 끝나고, 인터페이스 되지 않는 SR을 불러옴
        List<PushVO> srList = intergrateDAO.selectRTCSRList();
        // 2-1. 해당 정보를 INSERT 해줌
        // 2-2. INSERT SR은 업데이트 함

        for (PushVO vo : srList) {
            intergrateRTCDAO.insertSRtoRTCDB(vo);

            List<FilePushVO> fileList = intergrateDAO.selectFileListBySrId(vo.getSrId());

            for (FilePushVO file : fileList) {
                intergrateRTCDAO.insertFileInfoToRTCDB(file);
            }

            intergrateDAO.updateInterfaceYn(vo);

        }

    }

    @Override
    public void insertSRInfoToTicket() {

        // 1. 결제가 끝나고, 인터페이스 되지 않는 SR을 불러옴
        List<PushVO> srList = intergrateDAO.selectTicketSRList();
        // 2-1. 해당 정보를 INSERT 해줌
        // 2-2. INSERT SR은 업데이트 함

        for (PushVO vo : srList) {
            intergrateTicketDAO.insertSRtoTicketDB(vo);

            intergrateDAO.updateInterfaceYn(vo);

        }

    }

    @Override
    public void updateSRInfoFromRTC() {
        List<RTCResultVO> test = intergrateDAO.selectRTCResult();
        for (RTCResultVO vo : test) {

            String rtcStatusCd = StringUtils.defaultString(vo.getStatusCd());

            if (rtcStatusCd.equals("30")) {
                vo.setStatus("COMPLETE");
            } else if (rtcStatusCd.equals("91")) {
                vo.setStatus("REJECT");
            } else if (rtcStatusCd.equals("92")) {
                vo.setStatus("CANCEL");
            }

            intergrateDAO.updateSRWithRTCInfo(vo);
            intergrateDAO.updateRTCResult(vo);
        }
    }

    @Override
    public void updateSRInfoFromTicket() {
        List<TicketResultVO> test = intergrateDAO.selectTicketResult();
        for (TicketResultVO vo : test) {

            String rtcStatusCd = StringUtils.defaultString(vo.getStatusCd());

            if (rtcStatusCd.equals("10")) {
                vo.setStatus("COMPLETE");
            } else if (rtcStatusCd.equals("20")) {
                vo.setStatus("REJECT");
            }

            intergrateDAO.updateSRWithTicketInfo(vo);
        }

    }


}
