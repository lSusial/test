package net.homeplus.offline.crontab.schedule;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import net.homeplus.offline.intergrate.service.IntergrateService;

@Component
public class Scheduler {

    @Autowired
    private IntergrateService intergrateService;


    /** * 1. 오후 05:50:00에 호출이 되는 스케쥴러 */
    @Scheduled(cron = "*/10 * * * * *")
    public void cronTest1() {
        intergrateService.insertSRInfoToRTC();
        intergrateService.updateSRInfoFromRTC();

        intergrateService.insertSRInfoToTicket();
        intergrateService.updateSRInfoFromTicket();
    }

}
