package net.homeplus.offline.common.code.vo;

import net.homeplus.offline.common.vo.BaseVO;

public class CodeVO extends BaseVO {

    private String cdGrpId;
    private String cdId;
    private String cdNm;
    private String attr1;
    private String attr2;
    private String attr3;
    private String useYn;

    public String getCdGrpId() {
        return cdGrpId;
    }

    public void setCdGrpId(String cdGrpId) {
        this.cdGrpId = cdGrpId;
    }

    public String getCdId() {
        return cdId;
    }

    public void setCdId(String cdId) {
        this.cdId = cdId;
    }

    public String getCdNm() {
        return cdNm;
    }

    public void setCdNm(String cdNm) {
        this.cdNm = cdNm;
    }

    public String getAttr1() {
        return attr1;
    }

    public void setAttr1(String attr1) {
        this.attr1 = attr1;
    }

    public String getAttr2() {
        return attr2;
    }

    public void setAttr2(String attr2) {
        this.attr2 = attr2;
    }

    public String getAttr3() {
        return attr3;
    }

    public void setAttr3(String attr3) {
        this.attr3 = attr3;
    }

    public String getUseYn() {
        return useYn;
    }

    public void setUseYn(String useYn) {
        this.useYn = useYn;
    }



}
