package net.homeplus.offline.common.util;

import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class ResourceUtils {


    public enum PropType {
        XML {
            @Override
            public Properties loadProperties(InputStream is) {
                Properties properties = new Properties();
                try {

                    properties.loadFromXML(is);
                } catch (IOException e) {
                    return null;
                }
                return properties;
            }
        },
        TEXT {
            @Override
            public Properties loadProperties(InputStream is) {
                Properties properties = new Properties();
                try {

                    properties.load(is);
                } catch (IOException e) {
                    return null;
                }
                return properties;
            }
        };

        public abstract Properties loadProperties(InputStream is);
    }

    /**
     * 프로퍼티 파일을 리턴한다.
     *
     * @param propsFileName
     * @return
     */
    public static Properties getProperties(final String propsName) {
        return getProperties(propsName, PropType.TEXT);
    }

    /**
     *
     * <pre>
     *
     * </pre>
     *
     * @param propsName
     * @param propType
     * @return
     */
    public static Properties getProperties(final String propsName, PropType propType) {
        ClassLoader classLoader = getClassLoader();
        InputStream inStream = classLoader.getResourceAsStream(propsName);

        if (inStream == null) {
            return null;
        }

        try {
            Properties properties = null;
            properties = getProperties(inStream, propType);

            return properties;
        } finally {
            close(inStream);
        }
    }

    /**
     *
     * <pre>
     *
     * </pre>
     *
     * @param inStream
     * @param propType
     * @return
     */
    public static Properties getProperties(InputStream inStream, PropType propType) {
        return propType.loadProperties(inStream);
    }

    /**
     *
     * <pre>
     * Closeable 구현한 클래스를 close한다.
     * </pre>
     *
     * @param closeables
     */
    public static void close(Closeable... closeables) {
        if (closeables != null) {
            for (Closeable closeable : closeables) {
                try {
                    if (closeable != null) {
                        closeable.close();
                    }
                } catch (IOException e) {
                }
            }
        }
    }

    /**
     *
     * <pre>
     * classLoader반환.
     * </pre>
     *
     * @return
     */
    public static ClassLoader getClassLoader() {
        ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
        if (classLoader == null) {
            classLoader = ClassLoader.getSystemClassLoader();
        }
        return classLoader;
    }

    /**
     *
     * <pre>
     * reflection 을 이용한 toString
     * </pre>
     *
     * @param obj
     * @return toString
     */
    public static String reflectToString(Object obj) {
        return reflectToString(obj, ToStringStyle.DEFAULT_STYLE);
    }

    /**
     *
     * <pre>
     * reflection 을 이용한 toString
     * </pre>
     *
     * @param obj
     * @return toString
     */
    public static String reflectToString(Object obj, ToStringStyle toStringStyle) {
        return ReflectionToStringBuilder.toString(obj, toStringStyle);
    }

    /**
     *
     * <pre>
     * array to set
     * </pre>
     *
     * @param t array
     * @return HashSet
     */
    public static <T> Set<T> asSet(T... t) {
        return new HashSet<T>(Arrays.asList(t));
    }

}
