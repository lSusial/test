package net.homeplus.offline.common.mail;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Component;

import freemarker.template.Configuration;
import net.homeplus.offline.sr.proc.vo.EmailVO;

@Component("EmailSender")
public class EmailSender {

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private Configuration freemarkerConfiguration;

    public boolean send(final EmailVO emailVO) {
        boolean retVal = false;

        final String emailFrom = "sangminl@homeplus.co.kr";
        final String subject = "test subject";
        System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA");
        /*
         * javaMailSender.send(new MimeMessagePreparator() {
         * 
         * @Override public void prepare(MimeMessage paramMimeMessage) throws Exception {
         * MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(paramMimeMessage, true,
         * "UTF-8");
         * 
         * mimeMessageHelper.setTo(emailVO.getToAddress()); mimeMessageHelper.setFrom(emailFrom);
         * System.out.println("DDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD"
         * ); String text = ""; if ("REJECT".equals(emailVO.getStatus())) {
         * mimeMessageHelper.setSubject("[NSR-승인요청] NEW SR에 " + emailVO.getSrNo() + "이 반려 되었습니다.");
         * text =
         * FreeMarkerTemplateUtils.processTemplateIntoString(freemarkerConfiguration.getTemplate(
         * "informReject.ftl", "UTF-8"), emailVO); } else {
         * mimeMessageHelper.setSubject("[NSR-승인요청] NEW SR에 " + emailVO.getSrNo() +
         * " 승인 요청이 있습니다."); text =
         * FreeMarkerTemplateUtils.processTemplateIntoString(freemarkerConfiguration.getTemplate(
         * "requestApproval.ftl", "UTF-8"), emailVO); }
         * 
         * mimeMessageHelper.setText(text, true);
         * 
         * }; });
         */


        retVal = true;
        return retVal;
    }
}
