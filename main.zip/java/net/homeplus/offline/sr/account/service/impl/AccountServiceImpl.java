package net.homeplus.offline.sr.account.service.impl;

import java.util.List;

import net.homeplus.offline.common.vo.UserVO;
import net.homeplus.offline.sr.account.dao.AccountDAO;
import net.homeplus.offline.sr.account.service.AccountService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("AccountService")
public class AccountServiceImpl implements AccountService {

    @Autowired
    private AccountDAO accountDAO;

    @Override
    public UserVO selectUserInfo(String userId) {
        return accountDAO.selectUserInfo(userId);
    }

    @Override
    public List<UserVO> selectAllUserInfo() {
        return accountDAO.selectAllUserInfo();
    }



}
