package net.homeplus.offline.sr.file.service.impl;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import net.homeplus.offline.sr.file.dao.FileDAO;
import net.homeplus.offline.sr.file.service.FileService;
import net.homeplus.offline.sr.file.vo.FileVO;

import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;


@Service("FileService")
public class FileServiceImpl implements FileService {

    @Autowired
    private FileDAO fileDAO;

    @Override
    public void registFile(List<MultipartFile> files, String srId) throws IllegalStateException, IOException {

        for (MultipartFile file : files) {
            if (!file.isEmpty()) {
                String orginFileNm = file.getOriginalFilename();

                String serverFileNm =
                        FilenameUtils.getBaseName(orginFileNm) + new SimpleDateFormat("MMddHHmm").format(new Date()) + "."
                                + FilenameUtils.getExtension(orginFileNm);

                String today = new SimpleDateFormat("yyyyMMddHHmm").format(new Date());

                FileVO saveFile = new FileVO(srId, orginFileNm, serverFileNm);

                String fileDir = StringUtils.substring(today, 0, 4) + "\\" + StringUtils.substring(today, 4, 6) + "\\" + srId + "\\";
                saveFile.setFiledir(fileDir);
                fileDAO.registFile(saveFile);
                File targetFile = new File("E:\\NSR\\attach\\" + fileDir + orginFileNm);
                targetFile.getParentFile().mkdirs();
                file.transferTo(targetFile);
            }
        }
    }

    @Override
    public List<FileVO> selectFileListBySrId(String srId) {

        return fileDAO.selectFileListBySrId(srId);
    }

    @Override
    public FileVO selectFileWithDir(FileVO vo) {
        FileVO returnVO = fileDAO.selectFile(vo);
        if (returnVO != null && returnVO.getFileNm() != null) {
            returnVO.setFileNm("E:\\NSR\\attach\\" + returnVO.getFiledir() + "\\" + returnVO.getOrgFileNm());
        }
        return returnVO;
    }

    @Override
    public List<FileVO> selectPDSFileList() {

        String PDS_FILE_ID = "TEMPLATE";

        return fileDAO.selectFileListBySrId(PDS_FILE_ID);
    }

}
