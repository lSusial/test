package net.homeplus.offline.sr.file.service;

import java.io.IOException;
import java.util.List;

import net.homeplus.offline.sr.file.vo.FileVO;

import org.springframework.web.multipart.MultipartFile;

public interface FileService {

    public void registFile(List<MultipartFile> files, String srId) throws IllegalStateException, IOException;

    public List<FileVO> selectFileListBySrId(String srId);

    public List<FileVO> selectPDSFileList();

    public FileVO selectFileWithDir(FileVO vo);

}
