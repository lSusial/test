package net.homeplus.offline.sr.view.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.homeplus.offline.common.vo.UserVO;
import net.homeplus.offline.sr.account.service.AccountService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class CommonController {

    @Autowired
    private AccountService accountService;



    @RequestMapping(value = "/login/login.do", method = RequestMethod.GET)
    public ModelAndView registView(HttpServletRequest request, ModelAndView mav) {

        List<UserVO> userList = accountService.selectAllUserInfo();

        mav.addObject("userList", userList);
        mav.setViewName("login/login");
        return mav;
    }

    @RequestMapping(value = "/login/login.do", method = RequestMethod.POST)
    public String login(HttpServletRequest request, HttpServletResponse response, ModelAndView mav, UserVO vo) {

        HttpSession session = request.getSession();
        UserVO userVO = accountService.selectUserInfo(vo.getUserId());
        session.setAttribute("userInfo", userVO);

        return "redirect:/sr/list.do";

    }

    @RequestMapping(value = "/login/logout.do")
    public String logout(HttpServletRequest request, HttpServletResponse response, ModelAndView mav, UserVO vo) {

        HttpSession session = request.getSession();
        session.invalidate();

        return "redirect:/login/login.do";

    }


}
