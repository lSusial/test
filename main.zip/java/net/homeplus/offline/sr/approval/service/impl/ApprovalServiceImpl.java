package net.homeplus.offline.sr.approval.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import net.homeplus.offline.common.mail.EmailSender;
import net.homeplus.offline.common.util.CommonUtil;
import net.homeplus.offline.common.vo.UserVO;
import net.homeplus.offline.sr.account.dao.AccountDAO;
import net.homeplus.offline.sr.approval.dao.ApprovalDAO;
import net.homeplus.offline.sr.approval.service.ApprovalService;
import net.homeplus.offline.sr.approval.vo.AlternativeVO;
import net.homeplus.offline.sr.approval.vo.ApprovalHistVO;
import net.homeplus.offline.sr.approval.vo.ApprovalRuleVO;
import net.homeplus.offline.sr.approval.vo.IndividualApprovalLineVO;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service("ApprovalService")
public class ApprovalServiceImpl implements ApprovalService {

    @Autowired
    private ApprovalDAO approvalDAO;

    @Autowired
    private AccountDAO accountDAO;

    @Autowired
    private EmailSender emailSender;

    @Override
    public List<ApprovalHistVO> selectSRApprovalHistListBySRId(String srId) {
        List<ApprovalHistVO> approvalHist = approvalDAO.selectSRApprovalHistListBySRId(srId);
        for (ApprovalHistVO histVO : approvalHist) {
            histVO.setAprvDt(CommonUtil.dateToStr(histVO.getAprvDttm()));
        }
        return approvalHist;

    }

    @Override
    public List<ApprovalRuleVO> selectSRApprovalRule(ApprovalRuleVO vo) {
        return approvalDAO.selectSRApprovalRule(vo);
    }

    @Override
    public ApprovalHistVO approveSR(ApprovalHistVO vo) {
        updateApprovalHist(vo);
        return null;
    }

    @Override
    public ApprovalHistVO disapproveSR(ApprovalHistVO vo) {
        updateApprovalHist(vo);

        return null;
    }

    private void updateApprovalHist(ApprovalHistVO vo) {
        approvalDAO.updateApprovalHistStatus(vo);
    }

    @Override
    public void updateAlternative(AlternativeVO alterVO) {

        if (StringUtils.isNotEmpty(alterVO.getAlterEmpId())) {
            approvalDAO.insertAlternative(alterVO);
            approvalDAO.updateApprovalHistToAlternative(alterVO);
            // 대결자 설정 이메일
            sendAlternativeSettingEmail(alterVO);
        } else {

            AlternativeVO oldVO = approvalDAO.selectAlternative(alterVO.getUserId());

            approvalDAO.deleteAlternative(alterVO);
            approvalDAO.restoreApprovalHistToOrgin(alterVO);
            // 대결자 해제 이메일
            sendAlternativeReleaseEmail(oldVO);
        }
    }

    private void sendAlternativeReleaseEmail(AlternativeVO vo) {
        HashMap<String, Object> mailMap = setEmailInfo(vo);
        try {
            emailSender.sendAlternativeReleaseEmail(mailMap);
        } catch (Exception e) {
        }
    }

    private void sendAlternativeSettingEmail(AlternativeVO vo) {

        HashMap<String, Object> mailMap = setEmailInfo(vo);

        try {
            emailSender.sendAlternativeSettingEmail(mailMap);
        } catch (Exception e) {
        }
    }


    private HashMap<String, Object> setEmailInfo(AlternativeVO vo) {
        UserVO userVO = accountDAO.selectUserInfo(vo.getUserId());
        UserVO alterVO = accountDAO.selectUserInfo(vo.getAlterEmpId());

        HashMap<String, Object> mailMap = new HashMap<String, Object>();
        /**
         * 세팅자 : 이름, 아이디? 직급, 부서
         */
        mailMap.put("orginEmpId", userVO.getUserId());
        mailMap.put("orginEmpNm", userVO.getUserNm());
        mailMap.put("orginEmpDeptNm", userVO.getDeptNm());

        mailMap.put("alterEmpNm", alterVO.getUserNm());
        mailMap.put("alterEmpDeptNm", userVO.getDeptNm());

        Date date = new Date();
        mailMap.put("crtDttm", CommonUtil.dateToStr(date));

        // TODO 플러스넷에서 이메일 정보를 받아와야 함
        String toAddress = alterVO.getUserId();
        if (!StringUtils.contains(toAddress, "@homeplus.co.kr")) {
            toAddress = toAddress + "@homeplus.co.kr";
        } else {

        }
        mailMap.put("alterEmpEmail", toAddress);

        return mailMap;
    }


    @Override
    public AlternativeVO selectAlternative(String userId) {
        return approvalDAO.selectAlternative(userId);
    }

    @Override
    public List<IndividualApprovalLineVO> selectIndividualApprovalLine(String userId) {
        return approvalDAO.selectIndividualApprovalLine(userId);
    }

    @Override
    public int updateIndividualApprovalLine(List<IndividualApprovalLineVO> list, String userId) {

        approvalDAO.deleteIndividualApprovalLine(userId);
        for (IndividualApprovalLineVO vo : list) {
            vo.setUserId(userId);
            approvalDAO.insertIndividualApprovalLine(vo);
        }
        return 0;
    }


}
