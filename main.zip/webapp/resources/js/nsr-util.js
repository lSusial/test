//<![CDATA[

(function(win, doc,$){
var NSRUtil = (function (){
    
    function _init(){
        _NSRindexOf();
    }
    
    function _NSRindexOf() {
        console.log('11111111111111');
        if (!Array.prototype.indexOf) {
            Array.prototype.indexOf = function (obj, fromIndex) {
              if (fromIndex == null) {
                  fromIndex = 0;
              } else if (fromIndex < 0) {
                  fromIndex = Math.max(0, this.length + fromIndex);
              }
              for (var i = fromIndex, j = this.length; i < j; i++) {
                  if (this[i] === obj)
                      return i;
              }
              return -1;
            };
          }
    }
    
    
    return {
        init : _init
    };
    
    })();
    
    $(doc).ready(function(){
        NSRUtil.init();
    });
    
    if(!win.targetMarketEvent) win.NSRUtil = NSRUtil;
})(window, document,jQuery);


var SR_CONST =  {
    SR_TYPE : {
        INQUIRY : {CODE: 'US', NAME: '문의'},
        DATA : {CODE : 'UD', NAME : ' 데이터 추출'},
        REPAIR: {CODE : 'RP', NAME : ' 점검 / 수리'}
    },
    APPR_TYPE : {
        REQUEST  : {CODE: 'RD', NAME: '문의'},
        INCHARGE : {CODE: 'CD', NAME: '문의'}
    },
    
    NO_APPRVAL_SR_ARR : ['US','RP','ES']
}



var DateUtil = function (){
    
    var getTime = function (paramDate){                                                                                                                                                                                                                                                                                                                                                                                                                                     
        var targetDate = paramDate || ''
        if(targetDate == ''){
            var date = new Date();
        }else{
            var date = new Date(paramDate);
        }
        return date;
    }
    
    var getYear = function (paramDate){
        var mm = getTime(paramDate).getFullYear();
        return mm;
    }
    
    var getMonth = function (paramDate){
        var mm = getTime(paramDate).getMonth() + 1;
        return mm;
    }
    var getDate = function (paramDate){
        var dd = getTime(paramDate).getDate();
        return dd;
    }

    var getTimeJson = function(paramDate){
         var targetDate = getTime(paramDate);
         return timeToJson(targetDate);
    }
    
    var timeToJson =  function(time){
        
        if(time === 'undefined'){
            time = getTime();
        }
        var jSonDate = {};
        jSonDate['year'] = time.getFullYear();
        jSonDate['month'] = time.getMonth() + 1;
        jSonDate['day'] = time.getDate();

        return jSonDate;
    }
    
    var caculateTimeJson = function(paramDate, day){
        var targetDate = paramDate || '' ;
        var daysToAdd = day || 0;

        targetDate = getTime(targetDate);
        var calDate = new Date(targetDate.setDate(targetDate.getDate() + daysToAdd));

        return timeToJson(calDate);
   }
    
    var caculateDateByday = function (day){
        var currentDate = getTime();
        var targetDate = new Date(currentDate.setDate(currentDate.getDate() + day));
        return targetDate;
    }
    
    var caculateYearByday = function (day){
        var yyyy = caculateDateByday(day).getFullYear();
        return yyyy;
    }
    
    var caculateMonthByday = function (day){
        var mm = caculateDateByday(day).getMonth() + 1;
        return mm;
    }
    var caculateDayByday = function (day){
        var dd = caculateDateByday(day).getDate();
        return dd;
    }
    
    return {
        getYear : getYear,
        getMonth : getMonth,
        getDate : getDate,
        caculateDateByday : caculateDateByday,
        caculateYearByday : caculateYearByday,
        caculateMonthByday : caculateMonthByday,
        caculateDayByday : caculateDayByday,
        getTimeJson : getTimeJson,
        caculateTimeJson : caculateTimeJson
    };
    
}();



//]]>